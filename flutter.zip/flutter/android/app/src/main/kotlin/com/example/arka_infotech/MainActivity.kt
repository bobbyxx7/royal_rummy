package com.example.arka_infotech

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
