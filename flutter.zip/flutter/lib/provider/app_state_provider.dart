import 'dart:async';
import 'package:flutter/foundation.dart';
import '../model/user_model.dart';
import '../services/secure_storage_service.dart';
import '../frontend/Socket/socket_service.dart';
import 'auth_view_model.dart';

class AppStateProvider extends ChangeNotifier {
  final AuthViewModel _authViewModel;
  final SocketService _socketService;
  final SecureStorageService _secureStorage = SecureStorageService();

  bool _isInitialized = false;
  bool _isSocketConnecting = false;
  Timer? _reconnectionTimer;

  AppStateProvider(this._authViewModel, this._socketService) {
    _initializeApp();
  }

  bool get isInitialized => _isInitialized;
  bool get isSocketConnecting => _isSocketConnecting;
  bool get isAuthenticated => _authViewModel.user != null;
  bool get isSocketConnected => _socketService.isConnected;
  UserModel? get currentUser => _authViewModel.user;

  /// Initialize app state - check for stored user data and auto-login
  Future<void> _initializeApp() async {
    try {
      // Check if user data exists in secure storage
      final userData = await _secureStorage.getUserData();
      if (userData['user_id'] != null && userData['token'] != null) {
        print('Found stored user data, auto-login enabled');
        
        // Convert Map to UserModel
        final user = UserModel(
          id: userData['user_id']!,
          name: userData['name'] ?? '',
          mobile: userData['mobile'] ?? '',
          token: userData['token']!,
          wallet: userData['wallet'] ?? '0',
          gender: userData['gender'] ?? '',
          referralCode: userData['referral_code'] ?? '',
          userType: userData['user_type'] ?? '',
        );
        
        _authViewModel.setUser(user);
        
        // Auto-connect socket if user is authenticated
        if (_authViewModel.user != null) {
          await _connectSocketIfNeeded();
        }
      }
    } catch (e) {
      print('Error initializing app state: $e');
    } finally {
      _isInitialized = true;
      notifyListeners();
    }
  }

  /// Handle successful login
  Future<void> handleSuccessfulLogin(UserModel user) async {
    _authViewModel.setUser(user);
    await _connectSocketIfNeeded();
    notifyListeners();
  }

  /// Handle logout
  Future<void> handleLogout() async {
    await _disconnectSocket();
    await _authViewModel.logout();
    notifyListeners();
  }

  /// Connect socket if user is authenticated and socket is not connected
  Future<void> _connectSocketIfNeeded() async {
    if (_authViewModel.user == null) {
      print('No user authenticated, skipping socket connection');
      return;
    }

    if (_socketService.isConnected) {
      print('Socket already connected');
      return;
    }

    if (_isSocketConnecting) {
      print('Socket connection already in progress');
      return;
    }

    await _connectSocket();
  }

  /// Connect socket with current user
  Future<void> _connectSocket() async {
    if (_authViewModel.user == null) {
      print('Cannot connect socket: no user authenticated');
      return;
    }

    setSocketConnecting(true);

    try {
      await _socketService.connect();
      print('Socket connected successfully');
      
      // Start reconnection monitoring
      _startReconnectionMonitoring();
    } catch (e) {
      print('Failed to connect socket: $e');
      // Schedule retry after delay
      _scheduleReconnection();
    } finally {
      setSocketConnecting(false);
    }
  }

  /// Disconnect socket
  Future<void> _disconnectSocket() async {
    _stopReconnectionMonitoring();
    await _socketService.disconnect();
    notifyListeners();
  }

  /// Set socket connecting state
  void setSocketConnecting(bool connecting) {
    _isSocketConnecting = connecting;
    notifyListeners();
  }

  /// Start monitoring for socket disconnections and auto-reconnect
  void _startReconnectionMonitoring() {
    _stopReconnectionMonitoring();
    
    // Listen to socket connection changes
    _socketService.addListener(() {
      if (!_socketService.isConnected && _authViewModel.user != null) {
        print('Socket disconnected, scheduling reconnection...');
        _scheduleReconnection();
      }
    });
  }

  /// Stop reconnection monitoring
  void _stopReconnectionMonitoring() {
    _reconnectionTimer?.cancel();
    _reconnectionTimer = null;
  }

  /// Schedule socket reconnection
  void _scheduleReconnection() {
    _stopReconnectionMonitoring();
    _reconnectionTimer = Timer(const Duration(seconds: 5), () {
      if (_authViewModel.user != null && !_socketService.isConnected) {
        print('Attempting socket reconnection...');
        _connectSocketIfNeeded().catchError((error) {
          print('Reconnection failed: $error');
        });
      }
    });
  }

  /// Manual socket reconnection (for user-triggered reconnection)
  Future<void> reconnectSocket() async {
    if (_authViewModel.user == null) {
      print('Cannot reconnect: no user authenticated');
      return;
    }

    await _disconnectSocket();
    await Future.delayed(const Duration(seconds: 1));
    await _connectSocket();
  }

  /// Handle app lifecycle changes
  void handleAppLifecycleChange(String state) {
    switch (state) {
      case 'resumed':
        if (_authViewModel.user != null && !_socketService.isConnected) {
          print('App resumed, reconnecting socket...');
          _connectSocketIfNeeded().catchError((error) {
            print('Resume reconnection failed: $error');
          });
        }
        break;
      case 'paused':
      case 'detached':
        print('App paused/detached, disconnecting socket...');
        _disconnectSocket().catchError((error) {
          print('Disconnect failed: $error');
        });
        break;
    }
  }

  @override
  void dispose() {
    _stopReconnectionMonitoring();
    super.dispose();
  }
}
