// import 'dart:async';
//
// import 'package:flutter/foundation.dart';
// import 'package:arka_infotech/frontend/Socket/socket_service.dart';
//
// // AuthProvider to manage user authentication and socket connection
// class AuthProvider with ChangeNotifier {
//   String? _userId; // Store the user ID after login
//   SocketService? _socketService; // Socket service instance
//   bool _isLoggedIn = false; // Track login status
//   String? _errorMessage; // Store error message for failed login
//
//   String? get userId => _userId;
//   bool get isLoggedIn => _isLoggedIn;
//   SocketService? get socketService => _socketService;
//   String? get errorMessage => _errorMessage;
//
//   // Login by sending phone and password to the backend via socket
//   Future<bool> login(String phone, String password) async {
//     // Clear any previous error message
//     _errorMessage = null;
//
//     // Initialize socket service (without connecting yet)
//     _socketService = SocketService(backendUrl: 'URL'); // Replace with your backend URL
//
//     // Create a future to wait for the backend response
//     final loginCompleter = Completer<bool>();
//
//     // Connect the socket for login communication
//     // Note: The identifier here is just for logging; authentication happens via the 'login' event
//     _socketService?.connect('temp-user'); // Use a generic identifier instead of phone
//
//     // Listen for login response from the backend
//     _socketService?.onEvent('loginResponse', (data) {
//       if (data != null && data is Map<String, dynamic>) {
//         bool success = data['success'] ?? false;
//         if (success) {
//           _userId = data['userId']?.toString() ?? phone; // Use userId from backend, fallback to phone
//           _isLoggedIn = true;
//           // Socket is already connected, no need to reconnect
//           loginCompleter.complete(true);
//         } else {
//           _errorMessage = data['message']?.toString() ?? 'Login failed';
//           _socketService?.disconnect(); // Disconnect on failure
//           _socketService = null;
//           loginCompleter.complete(false);
//         }
//       } else {
//         _errorMessage = 'Invalid response from server';
//         _socketService?.disconnect();
//         _socketService = null;
//         loginCompleter.complete(false);
//       }
//       notifyListeners();
//     });
//
//     // Emit login event to the backend with phone and password
//     // Backend must verify both phone and password for authentication
//     _socketService?.sendMessage('login', {
//       'phone': phone,
//       'password': password,
//     });
//
//     // Wait for the login response or timeout after 5 seconds
//     bool success = await loginCompleter.future.timeout(
//       const Duration(seconds: 5),
//       onTimeout: () {
//         _errorMessage = 'Login timed out';
//         _socketService?.disconnect();
//         _socketService = null;
//         notifyListeners();
//         return false;
//       },
//     );
//
//     return success;
//   }
//
//   // Logout the user and disconnect the socket
//   void logout() {
//     _userId = null;
//     _isLoggedIn = false;
//     _errorMessage = null;
//     _socketService?.disconnect();
//     _socketService = null;
//     notifyListeners();
//   }
// }