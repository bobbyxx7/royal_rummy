import 'dart:async';
import 'dart:math';

import 'package:arka_infotech/frontend/Screens/Game_Screen/Game_Lobby/point_game/Model/Cards_Model.dart';
import 'package:flutter/material.dart' hide Card;

/// Main state management for the entire point game (UI state, animations, game phases, player management, etc.).

// Define enums here as single source of truth
enum GamePhase { waiting, loading, dealing, playing, result }
enum AnimationAction { none, draw, discard }

class PointGameProvider extends ChangeNotifier {
  // ---- Game State ----
  GamePhase _gamePhase = GamePhase.waiting;
  bool _showLoading = false;
  double _loadingProgress = 0.0;
  bool _showRealWildcard = false;
  bool _useGroupSort = false;
  int? _gameId;
  int? _tableId;
  bool _isDealing = false;
  bool _isTurnAdvancing = false;
  bool _hasTransitionedFromWaiting = false;
  bool _isCheckingPlayersJoined = false;
  DateTime? _waitingStartTime;
  int _expectedPlayerCount = 2;
  int _entryLevel = 0;
  Map<int, Map<String, dynamic>> _playersBySeat = {};
  dynamic _cachedUser;

  // ---- Turn/Player State ----
  int _currentTurnIndex = 0;
  String? _currentChaalUserId;
  bool _canDeclare = false;

  // ---- Hand/Card Groups ----
  Set<Card> _selectedCards = {};
  List<List<Card>> _cardGroups = [];
  List<String> _groupLabels = [];
  List<Offset> _cachedPositions = [];
  int? _tossWinner;

  // ---- Animation/Dealing State ----
  bool _isDealingNotifier = false;
  int _dealingCurrentCardIndexNotifier = 0;
  List<dynamic> _dealingAnimatedCards = [];
  bool _isCardReceiving = false;

  // ---- Reveal/Hand state ----
  List<List<Card>> _cardGroupsNotifier = [];
  List<bool> _mainHandRevealStatusNotifier = [];
  Set<Card> _selectedCardsNotifier = {};
  bool _myCardReceivedNotifier = false;
  AnimationAction _animationAction = AnimationAction.none;
  Card? _draggingCard;
  Offset? _draggingCardOffset;
  Offset? _animationStart;
  Offset? _animationEnd;

  // ---- Timer/Status ----
  int _turnTimerSeconds = 0;
  Timer? _statusTimer;
  Timer? _dealingTimer;

  // ---- Game Model/Hand/Points ----
  double _pointValue = 100.0;
  List<List<Card>> _playersHands = [];

  // ---- Additional State Variables ----
  bool _waitingForPlayers = true;
  dynamic _pendingMyCardData;
  int? _discardSourceGroupIndex;
  int? _discardSourceCardIndex;
  int? _dragTargetIndex;

  // ---- Getters ----
  GamePhase get gamePhase => _gamePhase;
  bool get showLoading => _showLoading;
  double get loadingProgress => _loadingProgress;
  bool get showRealWildcard => _showRealWildcard;
  bool get useGroupSort => _useGroupSort;
  int? get gameId => _gameId;
  int? get tableId => _tableId;
  bool get isDealing => _isDealing;
  bool get isTurnAdvancing => _isTurnAdvancing;
  bool get hasTransitionedFromWaiting => _hasTransitionedFromWaiting;
  bool get isCheckingPlayersJoined => _isCheckingPlayersJoined;
  DateTime? get waitingStartTime => _waitingStartTime;
  int get expectedPlayerCount => _expectedPlayerCount;
  int get entryLevel => _entryLevel;
  Map<int, Map<String, dynamic>> get playersBySeat => _playersBySeat;
  dynamic get cachedUser => _cachedUser;
  int get currentTurnIndex => _currentTurnIndex;
  String? get currentChaalUserId => _currentChaalUserId;
  bool get canDeclare => _canDeclare;
  Set<Card> get selectedCards => _selectedCards;
  List<List<Card>> get cardGroups => _cardGroups;
  List<String> get groupLabels => _groupLabels;
  List<Offset> get cachedPositions => _cachedPositions;
  int? get tossWinner => _tossWinner;
  bool get isDealingNotifier => _isDealingNotifier;
  int get dealingCurrentCardIndexNotifier => _dealingCurrentCardIndexNotifier;
  List<dynamic> get dealingAnimatedCards => _dealingAnimatedCards;
  bool get isCardReceiving => _isCardReceiving;
  List<List<Card>> get cardGroupsNotifier => _cardGroupsNotifier;
  List<bool> get mainHandRevealStatusNotifier => _mainHandRevealStatusNotifier;
  Set<Card> get selectedCardsNotifier => _selectedCardsNotifier;
  bool get myCardReceivedNotifier => _myCardReceivedNotifier;
  AnimationAction get animationAction => _animationAction;
  Card? get draggingCard => _draggingCard;
  Offset? get draggingCardOffset => _draggingCardOffset;
  Offset? get animationStart => _animationStart;
  Offset? get animationEnd => _animationEnd;
  int get turnTimerSeconds => _turnTimerSeconds;
  double get pointValue => _pointValue;
  List<List<Card>> get playersHands => _playersHands;
  bool get waitingForPlayers => _waitingForPlayers;
  dynamic get pendingMyCardData => _pendingMyCardData;
  int? get discardSourceGroupIndex => _discardSourceGroupIndex;
  int? get discardSourceCardIndex => _discardSourceCardIndex;
  int? get dragTargetIndex => _dragTargetIndex;

  // ---- Basic Setters ----
  void setGamePhase(GamePhase value) { _gamePhase = value; notifyListeners(); }
  void setShowLoading(bool value) { _showLoading = value; notifyListeners(); }
  void setLoadingProgress(double value) { _loadingProgress = value; notifyListeners(); }
  void setShowRealWildcard(bool value) { _showRealWildcard = value; notifyListeners(); }
  void setUseGroupSort(bool value) { _useGroupSort = value; notifyListeners(); }
  void setGameId(int? value) { _gameId = value; notifyListeners(); }
  void setTableId(int? value) { _tableId = value; notifyListeners(); }
  void setIsDealing(bool value) { _isDealing = value; notifyListeners(); }
  void setIsTurnAdvancing(bool value) { _isTurnAdvancing = value; notifyListeners(); }
  void setHasTransitionedFromWaiting(bool value) { _hasTransitionedFromWaiting = value; notifyListeners(); }
  void setIsCheckingPlayersJoined(bool value) { _isCheckingPlayersJoined = value; notifyListeners(); }
  void setWaitingStartTime(DateTime? value) { _waitingStartTime = value; notifyListeners(); }
  void setExpectedPlayerCount(int value) { _expectedPlayerCount = value; notifyListeners(); }
  void setEntryLevel(int value) { _entryLevel = value; notifyListeners(); }
  void setPlayersBySeat(Map<int, Map<String, dynamic>> value) { _playersBySeat = value; notifyListeners(); }
  void setCachedUser(dynamic value) { _cachedUser = value; notifyListeners(); }
  void setCurrentTurnIndex(int value) { _currentTurnIndex = value; notifyListeners(); }
  void setCurrentChaalUserId(String? value) { _currentChaalUserId = value; notifyListeners(); }
  void setCanDeclare(bool value) { _canDeclare = value; notifyListeners(); }
  void setSelectedCards(Set<Card> value) { _selectedCards = value; notifyListeners(); }
  void setCardGroups(List<List<Card>> value) { _cardGroups = value; notifyListeners(); }
  void setGroupLabels(List<String> value) { _groupLabels = value; notifyListeners(); }
  void setCachedPositions(List<Offset> value) { _cachedPositions = value; notifyListeners(); }
  void setTossWinner(int? value) { _tossWinner = value; notifyListeners(); }
  void setIsDealingNotifier(bool value) { _isDealingNotifier = value; notifyListeners(); }
  void setDealingCurrentCardIndexNotifier(int value) { _dealingCurrentCardIndexNotifier = value; notifyListeners(); }
  void setDealingAnimatedCards(List<dynamic> value) { _dealingAnimatedCards = value; notifyListeners(); }
  void setIsCardReceiving(bool value) { _isCardReceiving = value; notifyListeners(); }
  void setCardGroupsNotifier(List<List<Card>> value) { _cardGroupsNotifier = value; notifyListeners(); }
  void setMainHandRevealStatusNotifier(List<bool> value) { _mainHandRevealStatusNotifier = value; notifyListeners(); }
  void setSelectedCardsNotifier(Set<Card> value) { _selectedCardsNotifier = value; notifyListeners(); }
  void setMyCardReceivedNotifier(bool value) { _myCardReceivedNotifier = value; notifyListeners(); }
  void setAnimationAction(AnimationAction value) { _animationAction = value; notifyListeners(); }
  void setDraggingCard(Card? value) { _draggingCard = value; notifyListeners(); }
  void setDraggingCardOffset(Offset? value) { _draggingCardOffset = value; notifyListeners(); }
  void setAnimationStart(Offset? value) { _animationStart = value; notifyListeners(); }
  void setAnimationEnd(Offset? value) { _animationEnd = value; notifyListeners(); }
  void setTurnTimerSeconds(int value) { _turnTimerSeconds = value; notifyListeners(); }
  void setPointValue(double value) { _pointValue = value; notifyListeners(); }
  void setPlayersHands(List<List<Card>> value) { _playersHands = value; notifyListeners(); }
  void setWaitingForPlayers(bool value) { _waitingForPlayers = value; notifyListeners(); }
  void setPendingMyCardData(dynamic value) { _pendingMyCardData = value; notifyListeners(); }
  void setDiscardSourceGroupIndex(int? value) { _discardSourceGroupIndex = value; notifyListeners(); }
  void setDiscardSourceCardIndex(int? value) { _discardSourceCardIndex = value; notifyListeners(); }
  void setDragTargetIndex(int? value) { _dragTargetIndex = value; notifyListeners(); }

  // ---- Timer Management ----
  void setStatusTimer(Timer? timer) { _statusTimer = timer; notifyListeners(); }
  void setDealingTimer(Timer? timer) { _dealingTimer = timer; notifyListeners(); }

  // ---- Card Selection Methods ----
  void clearSelectedCards() {
    _selectedCards.clear();
    _selectedCardsNotifier.clear();
    notifyListeners();
  }

  void addSelectedCard(Card card) {
    _selectedCards.add(card);
    _selectedCardsNotifier.add(card);
    notifyListeners();
  }

  void removeSelectedCard(Card card) {
    _selectedCards.remove(card);
    _selectedCardsNotifier.remove(card);
    notifyListeners();
  }

  void toggleSelectedCard(Card card) {
    if (_selectedCards.contains(card)) {
      removeSelectedCard(card);
    } else {
      addSelectedCard(card);
    }
  }

  // ---- Game State Management ----
  void resetGameState() {
    _gamePhase = GamePhase.waiting;
    _showLoading = false;
    _loadingProgress = 0.0;
    _showRealWildcard = false;
    _useGroupSort = false;
    _gameId = null;
    _tableId = null;
    _isDealing = false;
    _isTurnAdvancing = false;
    _hasTransitionedFromWaiting = false;
    _currentTurnIndex = 0;
    _currentChaalUserId = null;
    _canDeclare = false;
    _selectedCards.clear();
    _cardGroups.clear();
    _groupLabels.clear();
    _cachedPositions.clear();
    _tossWinner = null;
    _isDealingNotifier = false;
    _dealingCurrentCardIndexNotifier = 0;
    _dealingAnimatedCards.clear();
    _isCardReceiving = false;
    _cardGroupsNotifier.clear();
    _mainHandRevealStatusNotifier.clear();
    _selectedCardsNotifier.clear();
    _myCardReceivedNotifier = false;
    _animationAction = AnimationAction.none;
    _draggingCard = null;
    _draggingCardOffset = null;
    _animationStart = null;
    _animationEnd = null;
    _turnTimerSeconds = 0;
    _pointValue = 100.0;
    _playersHands.clear();
    _waitingForPlayers = true;
    _pendingMyCardData = null;
    _discardSourceGroupIndex = null;
    _discardSourceCardIndex = null;
    _dragTargetIndex = null;
    
    // Clear timers
    _statusTimer?.cancel();
    _dealingTimer?.cancel();
    _statusTimer = null;
    _dealingTimer = null;
    
    notifyListeners();
  }

  void initializeGame() {
    resetGameState();
    _gamePhase = GamePhase.waiting;
    notifyListeners();
  }

  // ---- Player and Hand Management ----
  void updatePlayerHand(int playerIndex, List<Card> hand) {
    if (playerIndex < _playersHands.length) {
      _playersHands[playerIndex] = List.from(hand);
    } else {
      while (_playersHands.length <= playerIndex) {
        _playersHands.add([]);
      }
      _playersHands[playerIndex] = List.from(hand);
    }
    notifyListeners();
  }

  void updateCardGroups(List<List<Card>> groups) {
    _cardGroups = List.from(groups);
    _cardGroupsNotifier = List.from(groups);
    notifyListeners();
  }

  void updateGroupLabels(List<String> labels) {
    _groupLabels = List.from(labels);
    notifyListeners();
  }

  void updateCachedPositions(List<Offset> positions) {
    _cachedPositions = List.from(positions);
    notifyListeners();
  }

  // ---- Animation Management ----
  void startDealingAnimation(List<Card> cards) {
    _isDealingNotifier = true;
    _dealingCurrentCardIndexNotifier = 0;
    _dealingAnimatedCards = cards.map((card) => {
      'card': card,
      'startPosition': const Offset(0, 0),
      'targetPosition': const Offset(0, 0),
      'isDistributed': false,
    }).toList();
    notifyListeners();
  }

  void stopDealingAnimation() {
    _isDealingNotifier = false;
    _dealingCurrentCardIndexNotifier = 0;
    _dealingAnimatedCards.clear();
    notifyListeners();
  }

  void updateDealingProgress(int currentIndex) {
    _dealingCurrentCardIndexNotifier = currentIndex;
    notifyListeners();
  }

  // ---- Timer Management ----
  void startTurnTimer() {
    _turnTimerSeconds = 0;
    _statusTimer?.cancel();
    _statusTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      _turnTimerSeconds++;
      notifyListeners();
    });
  }

  void stopTurnTimer() {
    _statusTimer?.cancel();
    _statusTimer = null;
  }

  void resetTurnTimer() {
    _turnTimerSeconds = 0;
    notifyListeners();
  }

  // ---- Animation State Management ----
  void updateAnimationState(AnimationAction action, {Offset? start, Offset? end}) {
    _animationAction = action;
    if (start != null) _animationStart = start;
    if (end != null) _animationEnd = end;
    notifyListeners();
  }

  void clearAnimationState() {
    _animationAction = AnimationAction.none;
    _animationStart = null;
    _animationEnd = null;
    notifyListeners();
  }

  // ---- Dragging State Management ----
  void updateDraggingState(Card? card, Offset? offset) {
    _draggingCard = card;
    _draggingCardOffset = offset;
    notifyListeners();
  }

  void clearDraggingState() {
    _draggingCard = null;
    _draggingCardOffset = null;
    notifyListeners();
  }

  // ---- Player Management ----
  void addPlayer(int seat, Map<String, dynamic> playerData) {
    _playersBySeat[seat] = Map.from(playerData);
    notifyListeners();
  }

  void removePlayer(int seat) {
    _playersBySeat.remove(seat);
    notifyListeners();
  }

  void updatePlayer(int seat, Map<String, dynamic> playerData) {
    if (_playersBySeat.containsKey(seat)) {
      _playersBySeat[seat]!.addAll(playerData);
      notifyListeners();
    }
  }

  // ---- Utility Methods ----
  bool isCurrentPlayer(String userId) {
    return _currentChaalUserId == userId;
  }

  bool isMyTurn() {
    return _cachedUser != null && _currentChaalUserId == _cachedUser.id.toString();
  }

  int getPlayerCount() {
    return _playersBySeat.length;
  }

  bool isGameInProgress() {
    return _gamePhase == GamePhase.playing;
  }

  bool canMakeMove() {
    return isGameInProgress() && isMyTurn() && !_isDealing;
  }

  @override
  void dispose() {
    _statusTimer?.cancel();
    _dealingTimer?.cancel();
    super.dispose();
  }
}