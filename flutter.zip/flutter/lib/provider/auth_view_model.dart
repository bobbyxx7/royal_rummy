import 'dart:async';
import 'package:flutter/foundation.dart';
import '../model/user_model.dart';
import '../services/api_service.dart';
import '../services/secure_storage_service.dart';

class AuthViewModel extends ChangeNotifier {
  final ApiService _apiService = ApiService();
  final SecureStorageService _secureStorage = SecureStorageService();

  bool _isLoading = false;
  String? _errorMessage;
  String? _otpId;
  UserModel? _user;
  // bool  _isSocketConnected =  false;

  AuthViewModel();

  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  UserModel? get user => _user;
  // bool get isSocketConnected => _isSocketConnected;

  //
  // set isSocketConnectedFlag(bool value) {
  //   _isSocketConnected = value;
  //   notifyListeners();
  // }

  Future<bool> loginWithPassword(String mobile, String password) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      print('Initiating login for mobile: $mobile');
      final response = await _apiService.login(mobile, password);
      print('Processed login response: $response');

      if (response['code'] == 200 && response['user_data'] != null) {
        _user = UserModel.fromJson(response['user_data'][0]);
        await _secureStorage.saveUserData(_user!);
        print('User data saved to secure storage: ${_user!.toJson()}');
        _isLoading = false;
        notifyListeners();
        return true;
      } else {
        _errorMessage = response['message'] ?? 'Login failed';
        print('Login failed with message: $_errorMessage');
        _isLoading = false;
        notifyListeners();
        return false;
      }
    } catch (e) {
      _errorMessage = 'Something went wrong: $e';
      print('Login error: $e');
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<bool> sendOtp(String mobile, String type) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      print('Initiating OTP send for mobile: $mobile, type: $type');
      final response = await _apiService.sendOtp(mobile, type);
      print('Processed OTP response: $response');

      if (response['code'] == 200 && response['otp_id'] != null) {
        _otpId = response['otp_id'].toString();
        _isLoading = false;
        notifyListeners();
        return true;
      } else {
        _errorMessage = response['message'] ?? 'Failed to send OTP';
        print('OTP send failed with message: $_errorMessage');
        _isLoading = false;
        notifyListeners();
        return false;
      }
    } catch (e) {
      _errorMessage = 'Something went wrong: $e';
      print('OTP send error: $e');
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<bool> verifyOtp({
    required String otp,
    required String mobile,
    required String type,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      // Temporary default OTP check for demo
      if (otp == '666666') {
        _user = UserModel(
          id: 'temp_id',
          name: '',
          mobile: mobile,
          token: '',
        );
        await _secureStorage.saveUserData(_user!);
        _isLoading = false;
        notifyListeners();
        return true;
      } else {
        _errorMessage = 'Invalid OTP';
        _isLoading = false;
        notifyListeners();
        return false;
      }
    } catch (e) {
      _errorMessage = 'Something went wrong: $e';
      print('OTP verification error: $e');
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<bool> register(String name, String phone, String password, String gender, String referralCode) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      if (_otpId == null) {
        _errorMessage = 'OTP ID is missing. Please request an OTP first.';
        print('Registration failed: OTP ID is missing');
        _isLoading = false;
        notifyListeners();
        return false;
      }

      final response = await _apiService.register(
        name: name,
        mobile: phone,
        otpId: _otpId!,
        password: password,
        gender: gender,
        referralCode: referralCode.isNotEmpty ? referralCode : null,
      );
      print('Processed registration response: $response');

      if (response['code'] == 200 && response['message'] == 'Success') {
        _user = UserModel(
          id: response['user_id']?.toString() ?? 'temp_id_${phone}',
          name: name,
          mobile: phone,
          token: response['token']?.toString() ?? '',
          gender: gender,
          wallet: '0',
          referralCode: referralCode,
          userType: '',
        );
        await _secureStorage.saveUserData(_user!);
        print('User data saved to secure storage: ${_user!.toJson()}');
        _otpId = null; // Clear OTP ID after successful registration
        _isLoading = false;
        notifyListeners();
        return true;
      } else {
        _errorMessage = response['message'] ?? 'Registration failed';
        print('Registration failed with message: $_errorMessage');
        _isLoading = false;
        notifyListeners();
        return false;
      }
    } catch (e) {
      _errorMessage = 'Something went wrong: $e';
      print('Registration error: $e');
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }


  Future<bool> updateUserData({
    String? name,
    String? gender,
    String? referralCode,
    String? userType,
    double? walletAmount, // For adding/subtracting wallet balance
  }) async {
    if (_user == null) {
      _errorMessage = 'No user data available';
      notifyListeners();
      return false;
    }

    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      // Prepare updated fields
      final updatedFields = {
        if (name != null) 'name': name,
        if (gender != null) 'gender': gender,
        if (referralCode != null) 'referral_code': referralCode,
        if (userType != null) 'user_type': userType,
        if (walletAmount != null) 'amount': walletAmount.toString(),
      };

      // Call API to update user data
      final response = await _apiService.updateUserData(_user!.id, updatedFields);

      if (response['code'] == 200) {
        // Calculate new wallet value if updating wallet
        String newWallet = _user!.wallet;
        if (walletAmount != null) {
          final currentWallet = double.tryParse(_user!.wallet) ?? 0.0;
          newWallet = (currentWallet + walletAmount).toStringAsFixed(2);
        }

        // Update UserModel with new values
        _user = _user!.copyWith(
          name: name,
          gender: gender,
          referralCode: referralCode,
          userType: userType,
          wallet: walletAmount != null ? newWallet : null,
        );

        // Save to secure storage
        await _secureStorage.saveUserData(_user!);
        print('Updated user data saved: ${_user!.toJson()}');
        _isLoading = false;
        notifyListeners();
        return true;
      } else {
        _errorMessage = response['message'] ?? 'Failed to update user data';
        print('Update failed: $_errorMessage');
        _isLoading = false;
        notifyListeners();
        return false;
      }
    } catch (e) {
      _errorMessage = 'Something went wrong: $e';
      print('Update error: $e');
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  /// Update wallet from socket/status event and notify listeners (no API call)
  void updateWalletFromSocket(String newWallet) {
    if (_user != null && _user!.wallet != newWallet) {
      _user = _user!.copyWith(wallet: newWallet);
      notifyListeners();
    }
  }

  

  Future<bool> checkLoginStatus() async {
    try {
      final userData = await _secureStorage.getUserData();
      if (userData['token'] != null && userData['user_id'] != null) {
        _user = UserModel(
          id: userData['user_id'] ?? '',
          name: userData['name'] ?? '',
          mobile: userData['mobile'] ?? '',
          token: userData['token'] ?? '',
          wallet: userData['wallet'] ?? '0',
          gender: userData['gender'] ?? '',
          referralCode: userData['referral_code'] ?? '',
          userType: userData['user_type'] ?? '',
        );
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      print('Error checking login status: $e');
      return false;
    }
  }

  /// Set user data (for app state management)
  void setUser(UserModel user) {
    _user = user;
    notifyListeners();
  }

  Future<void> logout() async {
    _user = null;
    _otpId = null;
    await _secureStorage.clearUserData();
    notifyListeners();
  }

  @override
  void dispose() {
    _apiService.dispose();
    super.dispose();
  }
}