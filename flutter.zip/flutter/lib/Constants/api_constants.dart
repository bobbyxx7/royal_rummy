export '../Constants/api_constants.dart';

// lib/constants/api_constants.dart
import 'dart:io' show Platform;
import 'package:flutter/foundation.dart' show kIsWeb;

class ApiConstants {
  static String get apiUrl {
    if (kIsWeb) return 'http://localhost:6969/';
    if (Platform.isAndroid) return 'http://10.0.2.2:6969/';
    return 'http://localhost:6969/';
  }

  // Socket.IO namespace used by the app
  static String get socketUrl => '${apiUrl}rummy';

  /// Login and Registration
  static String get Login => '${apiUrl}api/user/login';
  static String get sendOtp => '${apiUrl}api/user/send_otp';
  static String get register => '${apiUrl}api/user/register';
  static String get updateUserData => '${apiUrl}api/user/update_user_data';

  /// Rummy Game APIs
  static String get getTable => '${apiUrl}api/rummy/get_table';
  static String get rummyJoinTable => '${apiUrl}rummy/join_table';
  static String get priRummyGame => '${apiUrl}Rummy/get_private_table';
  static String get startGame => '${apiUrl}Rummy/start_game';
  static String get packGame => '${apiUrl}Rummy/pack_game';
  static String get leaveTable => '${apiUrl}Rummy/leave_table';
  static String get myCard => '${apiUrl}Rummy/my_card';
  static String get status => '${apiUrl}Rummy/status';
  static String get cardValue => '${apiUrl}Rummy/card_value';
  static String get dropCard => '${apiUrl}Rummy/drop_card';
  static String get getCard => '${apiUrl}Rummy/get_card';
  static String get getDropCard => '${apiUrl}Rummy/get_drop_card';
  static String get declare => '${apiUrl}Rummy/declare';
  static String get declareBack => '${apiUrl}Rummy/declare_back';
  static String get shareWallet => '${apiUrl}rummy/share_wallet';
  static String get joinTable => '${apiUrl}Rummy/join_table';
  static String get joinPrivate => '${apiUrl}Rummy/join_table_with_code';
  static String get doShareWallet => '${apiUrl}rummy/do_share_wallet';
  static String get doStartGame => '${apiUrl}Rummy/do_start_game';
  static String get askStartGame => '${apiUrl}Rummy/ask_start_game';
  static String get rejoinGame => '${apiUrl}Rummy/rejoin_game';
  static String get rejoinGameAmount => '${apiUrl}Rummy/rejoin_game_amount';
  static String get rummyPointUserGameHistory => '${apiUrl}rummy/user_game_history';

  static const String token = 'c7d3965d49d4a59b0da80e90646aee77548458b3377ba3c0fb43d5ff91d54ea28833080e3de6ebd4fde36e2fb7175cddaf5d8d018ac1467c3d15db21c11b6909';
  static const String cookie = 'ci_session=ql4u3d0569peintlo3clko0vftbg0ni2;ci_session=mmo9qqjgcpk00r04ll9dcqaohrir95pe';
}
