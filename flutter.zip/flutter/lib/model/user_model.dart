class UserModel {
  final String id;
  final String name;
  final String mobile;
  final String token;
  final String wallet;
  final String gender;
  final String referralCode;
  final String userType;

  UserModel({
    required this.id,
    required this.name,
    required this.mobile,
    required this.token,
    this.wallet = '0',
    this.gender = '',
    this.referralCode = '',
    this.userType = '',
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id']?.toString() ?? '',
      name: json['name'] ?? '',
      mobile: json['mobile'] ?? '',
      token: json['token'] ?? '',
      wallet: json['wallet']?.toString() ?? '0',
      gender: json['gender'] ?? '',
      referralCode: json['referral_code'] ?? '',
      userType: json['user_type'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'mobile': mobile,
      'token': token,
      'wallet': wallet,
      'gender': gender,
      'referral_code': referralCode,
      'user_type': userType,
    };
  }

  UserModel copyWith({
    String? id,
    String? name,
    String? mobile,
    String? token,
    String? wallet,
    String? gender,
    String? referralCode,
    String? userType,
  }) {
    return UserModel(
      id: id ?? this.id,
      name: name ?? this.name,
      mobile: mobile ?? this.mobile,
      token: token ?? this.token,
      wallet: wallet ?? this.wallet,
      gender: gender ?? this.gender,
      referralCode: referralCode ?? this.referralCode,
      userType: userType ?? this.userType,
    );
  }
}