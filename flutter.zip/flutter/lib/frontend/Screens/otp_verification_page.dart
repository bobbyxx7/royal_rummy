import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:provider/provider.dart';
import '../../provider/auth_view_model.dart';
import 'components/animations.dart';
import 'components/reusable_buttons.dart';
import 'register_page.dart';

class OtpVerificationDialog extends StatefulWidget {
  final String mobile;
  final String type;
  final Function(bool) onOtpVerified; // Callback to update _isOtpVerified

  const OtpVerificationDialog({
    super.key,
    required this.mobile,
    required this.type,
    required this.onOtpVerified,
  });

  @override
  State<OtpVerificationDialog> createState() => _OtpVerificationDialogState();
}

class _OtpVerificationDialogState extends State<OtpVerificationDialog> with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  late List<TextEditingController> _otpControllers;
  late List<FocusNode> _otpFocusNodes;
  final ValueNotifier<int> _resendTimer = ValueNotifier<int>(30);
  final ValueNotifier<bool> _canResend = ValueNotifier<bool>(false);
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _otpControllers = List.generate(6, (_) => TextEditingController());
    _otpFocusNodes = List.generate(6, (_) => FocusNode());
    _otpFocusNodes[0].requestFocus();
    _startResendTimer();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final authViewModel = context.read<AuthViewModel>();
      if (authViewModel?.errorMessage == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('OTP sent to ${widget.mobile}')),
        );
      }
    });
  }

  void _startResendTimer() {
    _canResend.value = false;
    _resendTimer.value = 30;
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_resendTimer.value > 0) {
        _resendTimer.value--;
      } else {
        _canResend.value = true;
        timer.cancel();
      }
    });
  }

  @override
  void dispose() {
    for (var controller in _otpControllers) controller.dispose();
    for (var focusNode in _otpFocusNodes) focusNode.dispose();
    _timer?.cancel();
    _resendTimer.dispose();
    _canResend.dispose();
    super.dispose();
  }

  void _showAlertDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Error'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  Future<void> _handleVerifyOtp() async {
    if (_formKey.currentState!.validate()) {
      final authViewModel = context.read<AuthViewModel>();
      if (authViewModel == null) {
        _showAlertDialog('Authentication service unavailable.');
        return;
      }
      final otp = _otpControllers.map((c) => c.text).join();
      print('Entered OTP: $otp'); // Debug print to check the OTP value
      final success = await authViewModel.verifyOtp(
        otp: otp,
        mobile: widget.mobile,
        type: widget.type,
      );
      if (success) {
        widget.onOtpVerified(true);
        Navigator.of(context).pop();
      } else {
        _showAlertDialog(authViewModel.errorMessage ?? 'Invalid OTP');
      }
    } else {
      _showAlertDialog('Please enter a valid 6-digit OTP');
    }
  }

  Future<void> _handleResendOtp() async {
    final authViewModel = context.read<AuthViewModel>();
    if (authViewModel == null) {
      _showAlertDialog('Authentication service unavailable.');
      return;
    }
    final success = await authViewModel.sendOtp(widget.mobile, widget.type);
    if (success) {
      _startResendTimer();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('OTP resent to ${widget.mobile}')),
      );
      _otpControllers.forEach((controller) => controller.clear());
      _otpFocusNodes[0].requestFocus();
    } else {
      _showAlertDialog(authViewModel.errorMessage ?? 'Failed to resend OTP');
    }
  }

  void _moveToNextField(int index, String value) {
    if (value.length == 1 && index < 5) {
      _otpFocusNodes[index + 1].requestFocus();
    } else if (value.isEmpty && index > 0) {
      _otpFocusNodes[index - 1].requestFocus();
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 40),
      child: Consumer<AuthViewModel>(
        builder: (context, authViewModel, child) {
          return AnimatedOpacity(
            opacity: authViewModel.isLoading ? 0.7 : 1.0,
            duration: const Duration(milliseconds: 500),
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.amber.withOpacity(0.9),
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: Colors.white, width: 2),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 10,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: Form(
                key: _formKey, // Attach the form key here
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      'Verify OTP',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                    SizedBox(height: screenHeight * 0.02),
                    Text(
                      'Enter the 6-digit code sent to ${widget.mobile}',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.black,
                      ),
                    ),
                    SizedBox(height: screenHeight * 0.03),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(6, (index) {
                        return Container(
                          width: screenWidth * 0.08,
                          height: screenHeight * 0.06,
                          margin: const EdgeInsets.symmetric(horizontal: 8),
                          decoration: BoxDecoration(
                            color: Colors.amber[100],
                            border: Border.all(color: Colors.white, width: 2),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: TextFormField(
                            controller: _otpControllers[index],
                            focusNode: _otpFocusNodes[index],
                            keyboardType: TextInputType.number,
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: Colors.black87, fontSize: 18),
                            inputFormatters: [
                              FilteringTextInputFormatter.digitsOnly,
                              LengthLimitingTextInputFormatter(1),
                            ],
                            decoration: const InputDecoration(
                              border: InputBorder.none,
                              contentPadding: EdgeInsets.all(8),
                            ),
                            onChanged: (value) => _moveToNextField(index, value),
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Enter all digits';
                              }
                              return null;
                            },
                          ),
                        );
                      }),
                    ),
                    SizedBox(height: screenHeight * 0.04),
                    LoginRegisterBtn(
                      text: 'Verify OTP',
                      outerContainerColor: const Color(0xFF9E0606),
                      gradientColors: const [
                        Color(0xFFE89090),
                        Color(0xFFED3131),
                        Color(0xFFED3131),
                      ],
                      onPressed: authViewModel.isLoading ? () {} : _handleVerifyOtp,
                    ),
                    SizedBox(height: screenHeight * 0.02),
                    ValueListenableBuilder<bool>(
                      valueListenable: _canResend,
                      builder: (context, canResend, child) {
                        return ValueListenableBuilder<int>(
                          valueListenable: _resendTimer,
                          builder: (context, timer, child) {
                            return LoginRegisterBtn(
                              text: canResend
                                  ? 'Resend OTP'
                                  : 'Resend OTP ($timer s)',
                              outerContainerColor: canResend ? const Color(0xFF9E7006) : Colors.grey,
                              gradientColors: canResend
                                  ? const [
                                Color(0xFF6A4A3A),
                                Color(0xFF321907),
                                Color(0xFF121205),
                              ]
                                  : const [Colors.grey, Colors.grey],
                              onPressed: (canResend && !authViewModel.isLoading) ? _handleResendOtp : () {},
                            );
                          },
                        );
                      },
                    ),
                    if (authViewModel.isLoading)
                      Padding(
                        padding: const EdgeInsets.only(top: 20),
                        child: SpinKitCircle(
                          color: Colors.amber,
                          size: 40.0,
                          duration: const Duration(seconds: 1),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

void showOtpVerificationDialog(BuildContext context, String mobile, String type, Function(bool) onOtpVerified) {
  showDialog(
    context: context,
    barrierDismissible: true,
    builder: (context) => OtpVerificationDialog(
      mobile: mobile,
      type: type,
      onOtpVerified: onOtpVerified,
    ),
  );
}