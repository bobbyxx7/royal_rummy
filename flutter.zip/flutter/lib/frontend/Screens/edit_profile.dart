import 'package:arka_infotech/frontend/Screens/user_profile.dart';
import 'package:flutter/material.dart';

import 'components/Animations.dart';
import 'components/splash_Screen.dart';
import 'dashboard_page.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      body: Column(
        children: [
          // Header Section
          Container(
            decoration: const BoxDecoration(
              color: Color(0xFFB71C1C),
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(20),
                bottomRight: Radius.circular(20),
              ),
            ),
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
                          onPressed: () {
                            Navigator.pushReplacement(
                              context,
                              // customSlideTransition(SplashScreen(
                              //   backgroundImagePath: 'assets/dashboard_bg.png',
                              //   onLoad: simulateLoading,
                              //   nextPage: const UserProfilePage(),
                              // )),

                                customSlideTransition(const UserProfilePage()),
                            );
                          }
                        ),
                        const Spacer(),
                      ],
                    ),
                    const SizedBox(height: 20),
                    // Profile Picture
                    Stack(
                      children: [
                        CircleAvatar(
                          radius: 50,
                          backgroundColor: Colors.white,
                          child: CircleAvatar(
                            radius: 45,
                            backgroundImage: NetworkImage(
                              'https://via.placeholder.com/150', // Replace with actual image
                            ),
                          ),
                        ),
                        Positioned(
                          bottom: 0,
                          right: 0,
                          child: Container(
                            decoration: const BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle,
                            ),
                            padding: const EdgeInsets.all(4),
                            child: const Icon(
                              Icons.edit,
                              size: 16,
                              color: Colors.grey,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Rajshekhar',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
          
          // Content Section
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Personal Information Section
                  const Text(
                    'Personal Information',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 16),
                  
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.1),
                          spreadRadius: 1,
                          blurRadius: 5,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        _buildInfoItem(
                          icon: Icons.person,
                          iconColor: Colors.orange,
                          title: 'Your Name',
                          value: 'Rajshekhar Harendara Bhagat',
                          hasCheck: true,
                        ),
                        const Divider(height: 1),
                        _buildInfoItem(
                          icon: Icons.phone,
                          iconColor: Colors.grey,
                          title: 'Mobile Number',
                          value: '8356028991',
                          badge: 'Verified',
                          badgeColor: Colors.green,
                          hasAction: true,
                          actionText: 'Change',
                        ),
                        const Divider(height: 1),
                        _buildInfoItem(
                          icon: Icons.email,
                          iconColor: Colors.orange,
                          title: 'Email',
                          value: 'Not added',
                          badge: 'Pending',
                          badgeColor: Colors.orange,
                          hasAction: true,
                          actionText: 'Add',
                        ),
                        const Divider(height: 1),
                        _buildInfoItem(
                          icon: Icons.location_on,
                          iconColor: Colors.red,
                          title: 'Address',
                          value: 'Room No.1 Chandrika\nGupta Chawl Rani Sati\nMarg Mal',
                          hasCheck: true,
                        ),
                        const Divider(height: 1),
                        _buildInfoItem(
                          icon: Icons.calendar_today,
                          iconColor: Colors.red,
                          title: 'Date of Birth',
                          value: '17 February, 2003',
                          hasCheck: true,
                        ),
                        const Divider(height: 1),
                        _buildInfoItem(
                          icon: Icons.transgender,
                          iconColor: Colors.red,
                          title: 'Gender',
                          value: 'Not added',
                          badge: 'Pending',
                          badgeColor: Colors.orange,
                          hasAction: true,
                          actionText: 'Add',
                        ),
                      ],
                    ),
                  ),
                  
                  const SizedBox(height: 32),
                  
                  // Preferences Section
                  const Text(
                    'Preferences',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 16),
                  
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.1),
                          spreadRadius: 1,
                          blurRadius: 5,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        _buildPreferenceItem(
                          icon: Icons.email,
                          iconColor: Colors.orange,
                          title: 'Email & Subscriptions',
                          hasArrow: true,
                        ),
                        const Divider(height: 1),
                        _buildPreferenceItem(
                          icon: Icons.lock,
                          iconColor: Colors.orange,
                          title: 'Password',
                          hasAction: true,
                          actionText: 'Create',
                        ),
                        const Divider(height: 1),
                        _buildPreferenceItem(
                          icon: Icons.language,
                          iconColor: Colors.orange,
                          title: 'Choose your language',
                          hasAction: true,
                          actionText: 'हिंदी',
                        ),
                        const Divider(height: 1),
                        _buildPreferenceItem(
                          icon: Icons.sports_esports,
                          iconColor: Colors.orange,
                          title: 'Responsible Gaming',
                          hasArrow: true,
                        ),
                        const Divider(height: 1),
                        _buildPreferenceItem(
                          icon: Icons.settings,
                          iconColor: Colors.orange,
                          title: 'Settings',
                          hasArrow: true,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoItem({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String value,
    String? badge,
    Color? badgeColor,
    bool hasCheck = false,
    bool hasAction = false,
    String? actionText,
  }) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: iconColor.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: iconColor, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 14,
                        color: Colors.grey,
                      ),
                    ),
                    if (badge != null) ...[
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: badgeColor?.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          badge,
                          style: TextStyle(
                            fontSize: 12,
                            color: badgeColor,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          if (hasCheck)
            Container(
              padding: const EdgeInsets.all(4),
              decoration: const BoxDecoration(
                color: Colors.green,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.check, color: Colors.white, size: 16),
            ),
          if (hasAction)
            TextButton(
              onPressed: () {},
              child: Text(
                actionText!,
                style: const TextStyle(
                  color: Colors.grey,
                  fontSize: 14,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildPreferenceItem({
    required IconData icon,
    required Color iconColor,
    required String title,
    bool hasArrow = false,
    bool hasAction = false,
    String? actionText,
  }) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: iconColor.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: iconColor, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          if (hasArrow)
            const Icon(Icons.arrow_forward_ios, color: Colors.grey, size: 16),
          if (hasAction)
            TextButton(
              onPressed: () {},
              child: Text(
                actionText!,
                style: const TextStyle(
                  color: Colors.grey,
                  fontSize: 14,
                ),
              ),
            ),
        ],
      ),
    );
  }
}