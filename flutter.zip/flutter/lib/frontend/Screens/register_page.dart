import 'dart:async';
import 'package:arka_infotech/frontend/Screens/login_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../provider/auth_view_model.dart';
import '../../provider/app_state_provider.dart';
import 'components/custom_textFormField.dart';
import 'components/reusable_buttons.dart';
import 'otp_verification_page.dart';

PageRouteBuilder _customSlideTransition(Widget page) {
  return PageRouteBuilder(
    pageBuilder: (context, animation, secondaryAnimation) => page,
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      const begin = Offset(1.0, 0.0);
      const end = Offset.zero;
      const curve = Curves.easeInOut;

      var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
      var offsetAnimation = animation.drive(tween);

      return SlideTransition(
        position: offsetAnimation,
        child: child,
      );
    },
    transitionDuration: const Duration(milliseconds: 300),
  );
}

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final _formKey = GlobalKey<FormState>();
  final _fullNameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _passwordController = TextEditingController();
  final _referCodeController = TextEditingController();

  final _fullNameFocusNode = FocusNode();
  final _phoneFocusNode = FocusNode();
  final _passwordFocusNode = FocusNode();
  final _referCodeFocusNode = FocusNode();

  final ValueNotifier<bool> _isOtpSent = ValueNotifier<bool>(false);
  final ValueNotifier<bool> _isOtpVerified = ValueNotifier<bool>(false);
  final ValueNotifier<bool> _isPasswordVisible = ValueNotifier<bool>(false);
  final ValueNotifier<String?> _selectedGender = ValueNotifier<String?>(null);

  @override
  void dispose() {
    _fullNameController.dispose();
    _phoneController.dispose();
    _passwordController.dispose();
    _referCodeController.dispose();

    _fullNameFocusNode.dispose();
    _phoneFocusNode.dispose();
    _passwordFocusNode.dispose();
    _referCodeFocusNode.dispose();

    _isOtpSent.dispose();
    _isOtpVerified.dispose();
    _isPasswordVisible.dispose();
    _selectedGender.dispose();

    super.dispose();
  }

  void _showAlertDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Error'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  Future<void> _sendOtp(AuthViewModel authViewModel) async {
    if (_phoneController.text.isNotEmpty) {
      final success = await authViewModel.sendOtp(_phoneController.text, 'register');
      if (success) {
        _isOtpSent.value = true;
        showOtpVerificationDialog(
          context,
          _phoneController.text,
          'register',
              (verified) => _isOtpVerified.value = verified,
        );
      } else {
        _showAlertDialog(authViewModel.errorMessage ?? 'Failed to send OTP');
      }
    } else {
      _showAlertDialog('Please enter a valid phone number.');
    }
  }

  Future<void> _createAccount(AuthViewModel authViewModel) async {
    if (_formKey.currentState!.validate()) {
      if (_selectedGender.value == null) {
        _showAlertDialog('Please select your gender.');
      } else if (!_isOtpVerified.value) {
        print('OTP not verified'); // Debug print
        _showAlertDialog('Please verify your OTP first.');
      } else {
        print('Proceeding with registration'); // Debug print
        final success = await authViewModel.register(
          _fullNameController.text,
          _phoneController.text,
          _passwordController.text,
          _selectedGender.value!,
          _referCodeController.text,
        );
        if (success) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Registration Success')),
          );
          Navigator.pushReplacement(
            context,
            _customSlideTransition(const LoginPage()),
          );
        } else {
          _showAlertDialog(authViewModel.errorMessage ?? 'Registration failed.');
        }
      }
    } else {
      _showAlertDialog('Please fill all required fields.');
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;
    final padding = screenWidth * 0.06;

    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SizedBox(
        height: screenHeight,
        width: screenWidth,
        child: Stack(
          children: [
            Positioned.fill(
              child: Image.asset(
                'assets/img.png',
                fit: BoxFit.cover,
                alignment: Alignment.center,
              ),
            ),
            SingleChildScrollView(
              padding: EdgeInsets.all(padding),
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  minHeight: screenHeight - (padding * 2),
                ),
                child: Consumer<AuthViewModel>(
                  builder: (context, authViewModel, child) {
                    return Form(
                      key: _formKey,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Center(
                            child: Image.asset(
                              'assets/login_logo.png',
                              width: screenWidth * 0.4,
                              height: screenHeight * 0.2,
                              fit: BoxFit.contain,
                            ),
                          ),
                          SizedBox(height: screenHeight * 0.015),
                          const Text(
                            'Register',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 24,
                              fontStyle: FontStyle.italic,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: screenHeight * 0.03),

                          /// Full Name TextFormField
                          CustomTextFormField(
                            controller: _fullNameController,
                            focusNode: _fullNameFocusNode,
                            labelText: 'Full Name',
                            keyboardType: TextInputType.name,
                            icon: Icons.person,
                            validator: (value) =>
                            value == null || value.isEmpty ? 'Please enter your full name' : null,
                          ),
                          SizedBox(height: screenHeight * 0.03),

                          /// Phone Number TextFormField with Send OTP
                          CustomTextFormField(
                            controller: _phoneController,
                            focusNode: _phoneFocusNode,
                            labelText: 'Phone Number',
                            keyboardType: TextInputType.phone,
                            icon: Icons.phone,
                            inputFormatters: [
                              FilteringTextInputFormatter.digitsOnly,
                              LengthLimitingTextInputFormatter(10),
                            ],
                            suffix: ValueListenableBuilder<bool>(
                              valueListenable: _isOtpSent,
                              builder: (context, isSent, child) {
                                return GestureDetector(
                                  onTap: isSent || authViewModel.isLoading
                                      ? null
                                      : () => _sendOtp(authViewModel),
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 8.0),
                                    child: Text(
                                      'Send OTP',
                                      style: TextStyle(
                                        color: isSent || authViewModel.isLoading
                                            ? Colors.grey
                                            : Colors.amber,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                            validator: (value) =>
                            value == null || value.isEmpty ? 'Please enter your phone number' : null,
                          ),
                          SizedBox(height: screenHeight * 0.03),

                          /// Password TextFormField
                          CustomTextFormField(
                            controller: _passwordController,
                            focusNode: _passwordFocusNode,
                            labelText: 'Password',
                            keyboardType: TextInputType.visiblePassword,
                            icon: Icons.key,
                            inputFormatters: [
                              FilteringTextInputFormatter.singleLineFormatter,
                              LengthLimitingTextInputFormatter(20),
                            ],
                            obscureText: _isPasswordVisible,
                            suffixIcon: ValueListenableBuilder<bool>(
                              valueListenable: _isPasswordVisible,
                              builder: (context, isVisible, child) {
                                return IconButton(
                                  icon: Icon(
                                    isVisible ? Icons.visibility : Icons.visibility_off,
                                    color: _passwordFocusNode.hasFocus
                                        ? Colors.amber
                                        : Colors.white70,
                                  ),
                                  onPressed: () {
                                    _isPasswordVisible.value = !isVisible;
                                  },
                                );
                              },
                            ),
                            validator: (value) =>
                            value == null || value.isEmpty ? 'Please enter your password' : null,
                          ),
                          SizedBox(height: screenHeight * 0.03),

                          /// Gender Radio Buttons
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: padding),
                            child: ValueListenableBuilder<String?>(
                              valueListenable: _selectedGender,
                              builder: (context, gender, child) {
                                return Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    const Text('Gender: ', style: TextStyle(color: Colors.white, fontSize: 16)),
                                    Row(
                                      children: [
                                        Radio<String>(
                                          value: 'male',
                                          groupValue: gender,
                                          onChanged: (value) => _selectedGender.value = value,
                                          activeColor: Colors.amber,
                                        ),
                                        const Text('Male', style: TextStyle(color: Colors.white)),
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        Radio<String>(
                                          value: 'female',
                                          groupValue: gender,
                                          onChanged: (value) => _selectedGender.value = value,
                                          activeColor: Colors.amber,
                                        ),
                                        const Text('Female', style: TextStyle(color: Colors.white)),
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        Radio<String>(
                                          value: 'other',
                                          groupValue: gender,
                                          onChanged: (value) => _selectedGender.value = value,
                                          activeColor: Colors.amber,
                                        ),
                                        const Text('Other', style: TextStyle(color: Colors.white)),
                                      ],
                                    ),
                                  ],
                                );
                              },
                            ),
                          ),
                          SizedBox(height: screenHeight * 0.03),

                          /// ReferCode TextFormField (Optional)
                          CustomTextFormField(
                            controller: _referCodeController,
                            focusNode: _referCodeFocusNode,
                            labelText: 'Refer Code (Optional)',
                            keyboardType: TextInputType.text,
                            icon: Icons.local_offer_outlined,
                            inputFormatters: [
                              FilteringTextInputFormatter.singleLineFormatter,
                              LengthLimitingTextInputFormatter(10),
                            ],
                          ),
                          SizedBox(height: screenHeight * 0.03),

                          /// Create Account Button
                          LoginRegisterBtn(
                            text: 'Create Account',
                            outerContainerColor: const Color(0xFF9E0606),
                            gradientColors: const [
                              Color(0xFFE89090),
                              Color(0xFFED3131),
                              Color(0xFFED3131),
                            ],
                            onPressed: _isOtpVerified.value ? () => _createAccount(authViewModel) : () {},
                          ),
                          SizedBox(height: screenHeight * 0.03),

                          /// Login Button
                          LoginRegisterBtn(
                            text: 'Login',
                            outerContainerColor: const Color(0xFF9E7006),
                            gradientColors: const [
                              Color(0xFF6A4A3A),
                              Color(0xFF321907),
                              Color(0xFF121205),
                            ],
                            onPressed: () {
                              Navigator.pushReplacement(
                                context,
                                _customSlideTransition(const LoginPage()),
                              );
                            },
                          ),
                          SizedBox(height: screenHeight * 0.1),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}