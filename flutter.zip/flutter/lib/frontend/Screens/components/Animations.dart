import 'dart:math';

import 'package:flutter/material.dart';

PageRouteBuilder customSlideTransition(Widget page) {
  return PageRouteBuilder(
    pageBuilder: (context, animation, secondaryAnimation) => page,
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      const begin = Offset(1.0, 0.0); // Start from the right
      const end = Offset.zero; // End at the center
      const curve = Curves.easeInOut; // Smooth easing curve

      var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
      var offsetAnimation = animation.drive(tween);

      return SlideTransition(
        position: offsetAnimation,
        child: child,
      );
    },
    transitionDuration: const Duration(milliseconds: 300), // Smooth duration
  );
}

class RotatingIconsLoader extends StatefulWidget {
  final double size; // Controls the size of each icon
  final double spacing; // Controls the spacing between icons

  const RotatingIconsLoader({
    super.key,
    this.size = 60.0,
    this.spacing = 20.0,
  });

  @override
  State<RotatingIconsLoader> createState() => _RotatingIconsLoaderState();
}

class _RotatingIconsLoaderState extends State<RotatingIconsLoader>
    with TickerProviderStateMixin {
  late final List<AnimationController> _controllers;

  final List<String> _iconPaths = [
    'assets/card_logo/spade.png',
    'assets/card_logo/diamond.png',
    'assets/card_logo/club.png',
    'assets/card_logo/heart.png',
  ];

  @override
  void initState() {
    super.initState();
    _controllers = List.generate(_iconPaths.length, (index) {
      final controller = AnimationController(
        vsync: this,
        duration: const Duration(seconds: 1),
      )..repeat();
      return controller;
    });
  }

  @override
  void dispose() {
    for (final controller in _controllers) {
      controller.dispose();
    }
    super.dispose();
  }

  Widget _buildRotatingIcons() {
    return Wrap(
      spacing: widget.spacing,
      runSpacing: widget.spacing,
      alignment: WrapAlignment.center,
      children: List.generate(_iconPaths.length, (index) {
        return SizedBox(
          width: widget.size,
          height: widget.size,
          child: AnimatedBuilder(
            animation: _controllers[index],
            builder: (_, child) {
              return Transform.rotate(
                angle: _controllers[index].value * 2 * pi,
                child: child,
              );
            },
            child: Image.asset(_iconPaths[index]),
          ),
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Center(child: _buildRotatingIcons());
  }
}