import 'package:flutter/material.dart';
import 'dart:math';

class SplashScreen extends StatefulWidget {
  final String backgroundImagePath;
  final Future<void> Function() onLoad;
  final Widget nextPage;

  const SplashScreen({
    super.key,
    required this.backgroundImagePath,
    required this.onLoad,
    required this.nextPage,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late final List<AnimationController> _controllers;

  final List<String> _iconPaths = [
    'assets/card_logo/spade.png',
    'assets/card_logo/diamond.png',
    'assets/card_logo/club.png',
    'assets/card_logo/heart.png',
  ];

  @override
  void initState() {
    super.initState();

    _controllers = List.generate(_iconPaths.length, (index) {
      final controller = AnimationController(
        vsync: this,
        duration: const Duration(seconds: 1),
      )..repeat();
      return controller;
    });

    _handleLoad();
  }

  Future<void> _handleLoad() async {
    await widget.onLoad();
    if (mounted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => widget.nextPage),
      );
    }
  }

  @override
  void dispose() {
    for (final controller in _controllers) {
      controller.dispose();
    }
    super.dispose();
  }

  Widget _buildRotatingIcons() {
    return Wrap(
      spacing: 20,
      runSpacing: 20,
      alignment: WrapAlignment.center,
      children: List.generate(_iconPaths.length, (index) {
        return SizedBox(
          width: 60,
          height: 60,
          child: AnimatedBuilder(
            animation: _controllers[index],
            builder: (_, child) {
              return Transform.rotate(
                angle: _controllers[index].value * 2 * pi,
                child: child,
              );
            },
            child: Image.asset(_iconPaths[index]),
          ),
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Background image
          Image.asset(
            widget.backgroundImagePath,
            fit: BoxFit.cover,
          ),

          // Optional dark overlay
          Container(color: Colors.black.withOpacity(0.3)),

          // Loader (rotating cards)
          Center(child: _buildRotatingIcons()),
        ],
      ),
    );
  }
}

/// Temp function...
Future<void> simulateLoading() async {
  await Future.delayed(const Duration(seconds: 1)); // Simulate any async task
}