import 'package:flutter/material.dart';

class LoginRegisterBtn extends StatefulWidget {
  final String text;
  final Color outerContainerColor;
  final List<Color> gradientColors;
  final VoidCallback? onPressed; // Made nullable to handle disabled state
  final double? widthSize1;
  final double? widthSize2;
  final Color? textColor;

  const LoginRegisterBtn({
    super.key,
    required this.text,
    required this.outerContainerColor,
    required this.gradientColors,
    this.onPressed,
    this.widthSize1,
    this.widthSize2,
    this.textColor,
  });

  @override
  State<LoginRegisterBtn> createState() => _LoginRegisterBtnState();
}

class _LoginRegisterBtnState extends State<LoginRegisterBtn> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
    );
    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.95).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeInOut,
      ),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _onTapDown(TapDownDetails details) {
    if (widget.onPressed != null) {
      _animationController.forward();
    }
  }

  void _onTapUp(TapUpDetails details) {
    if (widget.onPressed != null) {
      _animationController.reverse();
      widget.onPressed!();
    }
  }

  void _onTapCancel() {
    if (widget.onPressed != null) {
      _animationController.reverse();
    }
  }

  @override
  Widget build(BuildContext context) {
    List<double> stops = widget.gradientColors.length > 1
        ? List<double>.generate(widget.gradientColors.length, (index) => index / (widget.gradientColors.length - 1))
        : [0.0, 1.0];

    return Stack(
      children: [
        Center(
          child: Container(
            width: widget.widthSize1 ?? 339,
            height: 50,
            decoration: BoxDecoration(
              color: widget.outerContainerColor,
              border: Border.all(color: widget.outerContainerColor, width: 2),
              borderRadius: BorderRadius.circular(30.0),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.3),
                  blurRadius: 5,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
          ),
        ),
        Center(
          child: ScaleTransition(
            scale: _scaleAnimation,
            child: GestureDetector(
              onTapDown: _onTapDown,
              onTapUp: _onTapUp,
              onTapCancel: _onTapCancel,
              child: Container(
                width: widget.widthSize2 ?? 336,
                height: 47,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: widget.gradientColors,
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    stops: stops,
                    tileMode: TileMode.clamp,
                  ),
                  border: Border.all(color: Colors.white70, width: 2),
                  borderRadius: BorderRadius.circular(30.0),
                ),
                child: Center(
                  child: Text(
                    widget.text,
                    style: TextStyle(
                      fontStyle: FontStyle.italic,
                      color: widget.textColor ?? Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                      fontFamily: 'Arial',
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}