import 'package:flutter/material.dart';

class GameCard extends StatefulWidget {
  final String imagePath;
  final String title;
  final String minPlayers;
  final String maxPlayers;
  final VoidCallback? onTap;
  final double? width;
  final double? height;

  const GameCard({
    Key? key,
    required this.imagePath,
    required this.title,
    required this.minPlayers,
    required this.maxPlayers,
    this.onTap,
    this.width,
    this.height,
  }) : super(key: key);

  @override
  State<GameCard> createState() => _GameCardState();
}

class _GameCardState extends State<GameCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;
  bool _isPressed = false;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 150),
      vsync: this,
    );
    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.95).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _onTapDown(TapDownDetails details) {
    setState(() {
      _isPressed = true;
    });
    _animationController.forward();
  }

  void _onTapUp(TapUpDetails details) {
    setState(() {
      _isPressed = false;
    });
    _animationController.reverse();
    if (widget.onTap != null) {
      widget.onTap!();
    }
  }

  void _onTapCancel() {
    setState(() {
      _isPressed = false;
    });
    _animationController.reverse();
  }

  // Calculate responsive dimensions based on screen size
  double _getCardWidth(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final screenWidth = size.width;
    final screenHeight = size.height;
    final pixelRatio = MediaQuery.of(context).devicePixelRatio;

    // Use provided width if available, but make it responsive
    if (widget.width != null) {
      double adjustedWidth = widget.width!;
      if (pixelRatio > 3.0) {
        adjustedWidth *= 0.95;
      } else if (pixelRatio < 2.0) {
        adjustedWidth *= 1.05;
      }
      return adjustedWidth;
    }

    // Determine if we're in landscape mode
    bool isLandscape = screenWidth > screenHeight;

    double baseWidth;
    if (isLandscape) {
      // In landscape, base on available height to maintain consistent visual size
      baseWidth = screenHeight * 0.35; // 35% of screen height
    } else {
      // In portrait, base on screen width
      baseWidth = screenWidth * 0.42; // 42% of screen width
    }

    // Adjust for different screen densities to maintain consistent visual size
    if (pixelRatio > 3.0) {
      baseWidth *= 0.95; // Slightly smaller on very high density screens
    } else if (pixelRatio < 2.0) {
      baseWidth *= 1.05; // Slightly larger on low density screens
    }

    // Clamp between reasonable bounds
    return baseWidth.clamp(160.0, 250.0);
  }

  double _getCardHeight(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final screenWidth = size.width;
    final screenHeight = size.height;
    final pixelRatio = MediaQuery.of(context).devicePixelRatio;

    // Use provided height if available, but make it responsive
    if (widget.height != null) {
      double adjustedHeight = widget.height!;
      if (pixelRatio > 3.0) {
        adjustedHeight *= 0.95;
      } else if (pixelRatio < 2.0) {
        adjustedHeight *= 1.05;
      }
      return adjustedHeight;
    }

    // Determine if we're in landscape mode
    bool isLandscape = screenWidth > screenHeight;

    double baseHeight;
    if (isLandscape) {
      // In landscape, use percentage of screen height
      baseHeight = screenHeight * 0.65; // 65% of screen height
    } else {
      // In portrait, maintain aspect ratio (4:3)
      baseHeight = _getCardWidth(context) * 1.33;
    }

    // Adjust for pixel density
    if (pixelRatio > 3.0) {
      baseHeight *= 0.95;
    } else if (pixelRatio < 2.0) {
      baseHeight *= 1.05;
    }

    // Clamp between reasonable bounds
    return baseHeight.clamp(200.0, 400.0);
  }

  // Calculate responsive padding
  double _getResponsivePadding(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final screenWidth = size.width;
    final screenHeight = size.height;
    final pixelRatio = MediaQuery.of(context).devicePixelRatio;

    // Use the smaller dimension to maintain consistency
    final baseDimension = screenWidth < screenHeight ? screenWidth : screenHeight;
    double padding = baseDimension * 0.025; // 2.5% of smaller dimension

    // Adjust for pixel density
    if (pixelRatio > 3.0) {
      padding *= 0.95;
    } else if (pixelRatio < 2.0) {
      padding *= 1.05;
    }

    return padding.clamp(12.0, 20.0);
  }

  // Calculate responsive font sizes
  double _getTitleFontSize(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final screenWidth = size.width;
    final screenHeight = size.height;
    final pixelRatio = MediaQuery.of(context).devicePixelRatio;

    // Use the smaller dimension for consistent sizing
    final baseDimension = screenWidth < screenHeight ? screenWidth : screenHeight;
    double baseFontSize = baseDimension * 0.04; // 4% of smaller dimension

    // Adjust for pixel density
    if (pixelRatio > 3.0) {
      baseFontSize *= 0.95;
    } else if (pixelRatio < 2.0) {
      baseFontSize *= 1.05;
    }

    return baseFontSize.clamp(14.0, 22.0);
  }

  double _getPlayerCountFontSize(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final screenWidth = size.width;
    final screenHeight = size.height;
    final pixelRatio = MediaQuery.of(context).devicePixelRatio;

    final baseDimension = screenWidth < screenHeight ? screenWidth : screenHeight;
    double fontSize = baseDimension * 0.025; // 2.5% of smaller dimension

    // Adjust for pixel density
    if (pixelRatio > 3.0) {
      fontSize *= 0.95;
    } else if (pixelRatio < 2.0) {
      fontSize *= 1.05;
    }

    return fontSize.clamp(10.0, 16.0);
  }

  double _getPlayerCountIconSize(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final screenWidth = size.width;
    final screenHeight = size.height;
    final pixelRatio = MediaQuery.of(context).devicePixelRatio;

    final baseDimension = screenWidth < screenHeight ? screenWidth : screenHeight;
    double iconSize = baseDimension * 0.03; // 3% of smaller dimension

    // Adjust for pixel density
    if (pixelRatio > 3.0) {
      iconSize *= 0.95;
    } else if (pixelRatio < 2.0) {
      iconSize *= 1.05;
    }

    return iconSize.clamp(12.0, 18.0);
  }

  @override
  Widget build(BuildContext context) {
    final cardWidth = _getCardWidth(context);
    final cardHeight = _getCardHeight(context);
    final padding = _getResponsivePadding(context);
    final titleFontSize = _getTitleFontSize(context);
    final playerCountFontSize = _getPlayerCountFontSize(context);
    final playerCountIconSize = _getPlayerCountIconSize(context);

    return SafeArea(
      child: Center(
        child: GestureDetector(
          onTapDown: _onTapDown,
          onTapUp: _onTapUp,
          onTapCancel: _onTapCancel,
          child: AnimatedBuilder(
            animation: _scaleAnimation,
            builder: (context, child) {
              return Transform.scale(
                scale: _scaleAnimation.value,
                child: Container(
                  width: cardWidth,
                  height: cardHeight,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    gradient: const LinearGradient(
                      colors: [
                        Color(0xFF8B0000), // Dark red
                        Color(0xFFDC143C), // Crimson
                        Color(0xFF8B0000), // Dark red
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.3),
                      width: 2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.4),
                        blurRadius: _isPressed ? 4 : 8,
                        offset: Offset(0, _isPressed ? 2 : 4),
                        spreadRadius: _isPressed ? 1 : 2,
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(14),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        // Image Section
                        Expanded(
                          flex: 3,
                          child: Container(
                            width: double.infinity,
                            padding: EdgeInsets.all(padding),
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                // Main game image - centered
                                Positioned.fill(
                                  child: Center(
                                    child: Image.asset(
                                      widget.imagePath,
                                      fit: BoxFit.contain,
                                      width: double.infinity,
                                      height: double.infinity,
                                      errorBuilder: (context, error, stackTrace) {
                                        return Container(
                                          decoration: BoxDecoration(
                                            color: Colors.white.withOpacity(0.1),
                                            borderRadius: BorderRadius.circular(8),
                                          ),
                                          child: Center(
                                            child: Icon(
                                              Icons.image_not_supported,
                                              color: Colors.white.withOpacity(0.5),
                                              size: cardWidth * 0.25, // Responsive icon size
                                            ),
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                ),
                                // Player count overlay - properly positioned
                                Positioned(
                                  bottom: 8,
                                  left: padding * 2.2,
                                  child: Container(
                                    padding: EdgeInsets.symmetric(
                                      horizontal: padding * 0.75,
                                      vertical: 6,
                                    ),
                                    decoration: BoxDecoration(
                                      color: Colors.black.withOpacity(0.7),
                                      borderRadius: BorderRadius.circular(20),
                                      border: Border.all(
                                        color: Colors.amber,
                                        width: 1,
                                      ),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Icon(
                                          Icons.people,
                                          color: Colors.amber,
                                          size: playerCountIconSize,
                                        ),
                                        SizedBox(width: 4),
                                        Text(
                                          '${widget.minPlayers}/${widget.maxPlayers}',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: playerCountFontSize,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        // Title Section
                        Expanded(
                          flex: 1,
                          child: Container(
                            width: double.infinity,
                            padding: EdgeInsets.symmetric(
                              horizontal: padding,
                              vertical: 8,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.3),
                              borderRadius: const BorderRadius.only(
                                bottomLeft: Radius.circular(14),
                                bottomRight: Radius.circular(14),
                              ),
                            ),
                            child: Center(
                              child: Text(
                                widget.title,
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: titleFontSize,
                                  fontWeight: FontWeight.bold,
                                  shadows: [
                                    Shadow(
                                      color: Colors.black.withOpacity(0.5),
                                      offset: const Offset(1, 1),
                                      blurRadius: 2,
                                    ),
                                  ],
                                ),
                                textAlign: TextAlign.center,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}