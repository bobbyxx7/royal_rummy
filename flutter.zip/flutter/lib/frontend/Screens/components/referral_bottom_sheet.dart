// lib/frontend/screens/components/referral_bottom_sheet.dart
import 'package:flutter/material.dart';
import 'reusable_buttons.dart';

class ReferralBottomSheet extends StatefulWidget {
  final String id;
  final String name;
  final String email;
  final String source;

  const ReferralBottomSheet({
    super.key,
    required this.id,
    required this.name,
    required this.email,
    required this.source,
  });

  @override
  State<ReferralBottomSheet> createState() => _ReferralBottomSheetState();
}

class _ReferralBottomSheetState extends State<ReferralBottomSheet> {
  final _referralController = TextEditingController();
  String _selectedGender = 'Male';

  @override
  void dispose() {
    _referralController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    return Padding(
      padding: EdgeInsets.all(screenWidth * 0.06),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Complete Your Profile',
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: screenHeight * 0.02),
          TextFormField(
            controller: _referralController,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              labelText: 'Referral Code (Optional)',
              labelStyle: const TextStyle(color: Colors.white70),
              prefixIcon: const Icon(Icons.code, color: Colors.amber),
              filled: true,
              fillColor: Colors.white.withOpacity(0.2),
              enabledBorder: const OutlineInputBorder(
                borderSide: BorderSide(color: Colors.amber),
              ),
              focusedBorder: const OutlineInputBorder(
                borderSide: BorderSide(color: Colors.amber, width: 2.0),
              ),
            ),
          ),
          SizedBox(height: screenHeight * 0.02),
          const Text(
            'Gender',
            style: TextStyle(color: Colors.white, fontSize: 16),
          ),
          Row(
            children: [
              Expanded(
                child: RadioListTile<String>(
                  title: const Text('Male', style: TextStyle(color: Colors.white)),
                  value: 'Male',
                  groupValue: _selectedGender,
                  onChanged: (value) {
                    setState(() {
                      _selectedGender = value!;
                    });
                  },
                  activeColor: Colors.amber,
                ),
              ),
              Expanded(
                child: RadioListTile<String>(
                  title: const Text('Female', style: TextStyle(color: Colors.white)),
                  value: 'Female',
                  groupValue: _selectedGender,
                  onChanged: (value) {
                    setState(() {
                      _selectedGender = value!;
                    });
                  },
                  activeColor: Colors.amber,
                ),
              ),
            ],
          ),
          SizedBox(height: screenHeight * 0.02),
          LoginRegisterBtn(
            text: 'Submit',
            outerContainerColor: const Color(0xFF9E0606),
            gradientColors: const [
              Color(0xFFE89090),
              Color(0xFFED3131),
              Color(0xFFED3131),
            ],
            onPressed: () {
              Navigator.pop(context, {
                'gender': _selectedGender,
                'referral_code': _referralController.text.trim(),
              });
            },
          ),
          SizedBox(height: MediaQuery.of(context).viewInsets.bottom + screenHeight * 0.02),
        ],
      ),
    );
  }
}