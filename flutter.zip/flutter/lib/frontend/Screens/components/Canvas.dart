import 'dart:math' as math;

import 'package:flutter/material.dart';

class SemicirclePainter extends CustomPainter {
  final Color backgroundColor;
  final Color borderColor;
  final double borderWidth;

  SemicirclePainter({
    required this.backgroundColor,
    required this.borderColor,
    required this.borderWidth,
  });

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;

  @override
  void paint(Canvas canvas, Size size) {
    final Paint backgroundPaint = Paint()
      ..color = backgroundColor
      ..style = PaintingStyle.fill;

    final Paint borderPaint = Paint()
      ..color = borderColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = borderWidth;

    final Rect rect = Rect.fromLTWH(0, 0, size.width, size.height * 2);
    const double startAngle = 0;
    const double sweepAngle = -math.pi;

    canvas.drawArc(rect, startAngle, sweepAngle, true, backgroundPaint);
    canvas.drawArc(rect, startAngle, sweepAngle, false, borderPaint);
  }
}

class GradientCircularProgressPainter extends CustomPainter {
  final double value;
  final Color backgroundColor;
  final bool isActive;
  final double strokeWidth;

  GradientCircularProgressPainter({
    required this.value,
    required this.backgroundColor,
    required this.isActive,
    required this.strokeWidth,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;

    final backgroundPaint = Paint()
      ..color = backgroundColor
      ..strokeWidth = strokeWidth
      ..style = PaintingStyle.stroke;
    canvas.drawArc(rect, 0, 2 * math.pi, false, backgroundPaint);

    final progressPaint = Paint()
      ..strokeWidth = strokeWidth
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    if (isActive) {
      progressPaint.color = Colors.green;
    } else {
      final gradient = SweepGradient(
        startAngle: -math.pi / 2,
        endAngle: -math.pi / 2 + 2 * math.pi,
        colors: [Colors.grey[300]!, Colors.grey[700]!, Colors.grey[300]!],
        stops: [0.0, 0.5, 1.0],
      );
      progressPaint.shader = gradient.createShader(rect);
    }

    final startAngle = -math.pi / 2;
    final sweepAngle = value * 2 * math.pi;
    canvas.drawArc(rect, startAngle, sweepAngle, false, progressPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

class SemicircleWithProgressPainter extends CustomPainter {
  final double progress;
  final bool isActive;
  final Color backgroundColor;
  final double borderWidth;
  final double strokeWidth;

  SemicircleWithProgressPainter({
    required this.progress,
    required this.isActive,
    required this.backgroundColor,
    required this.borderWidth,
    required this.strokeWidth,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Rect.fromLTWH(0, 0, size.width, size.height * 2);
    const startAngle = 0.0;
    const sweepAngle = -math.pi;

    // Draw background
    final backgroundPaint = Paint()
      ..color = backgroundColor
      ..style = PaintingStyle.fill;
    canvas.drawArc(rect, startAngle, sweepAngle, true, backgroundPaint);

    // Draw border/progress
    if (isActive) {
      // Active: Green progress arc
      final progressPaint = Paint()
        ..color = Colors.green
        ..strokeWidth = strokeWidth
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round;
      final progressSweep = sweepAngle * (1 - progress);
      canvas.drawArc(rect, startAngle, progressSweep, false, progressPaint);
    } else {
      // Inactive: Grey gradient border
      final gradientPaint = Paint()
        ..strokeWidth = borderWidth
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round;
      final gradient = SweepGradient(
        startAngle: -math.pi / 2, // Start at top-left of semicircle
        endAngle: -math.pi / 2 + 2 * math.pi, // End at top-right
        colors: [Colors.grey[300]!, Colors.grey[700]!, Colors.grey[300]!],
        stops: [0.0, 0.5, 1.0],
      );
      gradientPaint.shader = gradient.createShader(rect);
      canvas.drawArc(rect, startAngle, sweepAngle, false, gradientPaint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

class ProfileTimerWidget extends StatefulWidget {
  final String username;
  final int score;
  final int metric1;
  final int metric2;
  final bool isTimerActive;
  final Duration timerDuration;
  final VoidCallback? onTimerFinished;
  final double baseSize;
  final String imagePath; // <-- new
  final bool showTimer;   // <-- new

  const ProfileTimerWidget({
    required this.username,
    required this.score,
    required this.metric1,
    required this.metric2,
    required this.isTimerActive,
    this.timerDuration = const Duration(seconds: 20),
    this.onTimerFinished,
    Key? key,
    this.baseSize = 80.0,
    this.imagePath = 'assets/profile.png', // <-- default
    this.showTimer = true,                 // <-- default
  }) : super(key: key);

  @override
  _ProfileTimerWidgetState createState() => _ProfileTimerWidgetState();
}

class _ProfileTimerWidgetState extends State<ProfileTimerWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: widget.timerDuration,
      vsync: this,
    );
    if (widget.isTimerActive && widget.showTimer) {
      _controller.forward();
    } else {
      _controller.value = 1.0;
    }

    _controller.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        widget.onTimerFinished?.call();
      }
    });
  }

  @override
  void didUpdateWidget(ProfileTimerWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isTimerActive != oldWidget.isTimerActive || widget.showTimer != oldWidget.showTimer) {
      if (widget.isTimerActive && widget.showTimer) {
        _controller.forward(from: 0.0);
      } else {
        _controller.stop();
        _controller.value = 1.0;
      }
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final baseSize = screenWidth * 0.05;
    final timerSize = math.min(math.max(baseSize, 70.0), 100.0);
    final strokeWidth = timerSize * 0.08;
    final avatarDiameter = timerSize - strokeWidth;
    final avatarRadius = avatarDiameter / 2;
    final metricCircleSize = timerSize * 0.25;
    final metricCircleOffset = timerSize * 0.15;
    final totalSize = timerSize;

    return SizedBox(
      width: totalSize,
      height: totalSize,
      child: Stack(
        alignment: Alignment.center,
        children: [
          if (widget.showTimer)
            SizedBox(
              width: timerSize,
              height: timerSize,
              child: AnimatedBuilder(
                animation: _controller,
                builder: (context, child) {
                  return CustomPaint(
                    painter: GradientCircularProgressPainter(
                      value: _controller.value,
                      backgroundColor: Colors.black.withOpacity(0.8),
                      isActive: widget.isTimerActive,
                      strokeWidth: strokeWidth,
                    ),
                  );
                },
              ),
            ),
          SizedBox(
            width: avatarDiameter,
            height: avatarDiameter,
            child: CircleAvatar(
              radius: avatarRadius,
              backgroundColor: Colors.transparent,
              child: ClipOval(
                child: SizedBox(
                  width: avatarDiameter,
                  height: avatarDiameter,
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      FittedBox(
                        fit: BoxFit.cover,
                        child: Image.asset(
                          widget.imagePath,
                          width: avatarDiameter,
                          height: avatarDiameter,
                        ),
                      ),
                      Align(
                        alignment: Alignment.bottomCenter,
                        child: Padding(
                          padding: EdgeInsets.only(bottom: avatarRadius * 0.15),
                          child: Text(
                            widget.username,
                            style: TextStyle(
                                fontSize: avatarRadius * 0.3,
                                color: Colors.white,
                                shadows: [
                                  Shadow(
                                      color: Colors.black.withOpacity(0.7),
                                      offset: Offset(1, 1),
                                      blurRadius: 2)
                                ]),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          if (widget.showTimer)
            Positioned(
              right: 0,
              bottom: metricCircleOffset,
              child: AnimatedBuilder(
                  animation: _controller,
                  builder: (context, child) {
                    int remainingCoins = widget.metric2;
                    return _buildSmallCircle(remainingCoins, metricCircleSize);
                  }),
            ),
        ],
      ),
    );
  }
}

///  The Point Circle or can also be used for Showing the  timer..
Widget _buildSmallCircle(int value, double size) {
  return Container(
    width: size,
    height: size,
    decoration:  BoxDecoration(
      shape: BoxShape.circle,
      color: Colors.black.withOpacity(0.9),
    ),
    child: Center(
      child: Text(
        value.toString(),
        style: TextStyle(
          color: Colors.white,
          fontSize: size * 0.5,
        ),
      ),
    ),
  );
}

/// Main Player Profile...
class MainPlayerProfileTimerWidget extends StatefulWidget {
  final String username;
  final int score;
  final int metric1;
  final  int metric2;
  final bool isTimerActive;
  final Duration timerDuration;
  final VoidCallback? onTimerFinished;
  final String imagePath; // <-- new
  final bool showTimer;   // <-- new

  const MainPlayerProfileTimerWidget({
    required this.username,
    required this.score,
    required this.metric1,
    required this.metric2,
    required this.isTimerActive,
    this.timerDuration = const Duration(seconds: 20),
    this.onTimerFinished,
    Key? key,
    this.imagePath = 'assets/profile.png', // <-- default
    this.showTimer = true,                 // <-- default
  }) : super(key: key);

  @override
  _MainPlayerProfileTimerWidgetState createState() =>
      _MainPlayerProfileTimerWidgetState();
}

class _MainPlayerProfileTimerWidgetState
    extends State<MainPlayerProfileTimerWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: widget.timerDuration,
      vsync: this,
    );
    if (widget.isTimerActive && widget.showTimer) {
      _controller.forward(from: 0.0);
    } else {
      _controller.value = 1.0;
    }
    _controller.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        widget.onTimerFinished?.call();
      }
    });
  }

  @override
  void didUpdateWidget(MainPlayerProfileTimerWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isTimerActive != oldWidget.isTimerActive || widget.showTimer != oldWidget.showTimer) {
      if (widget.isTimerActive && widget.showTimer) {
        _controller.forward(from: 0.0);
      } else {
        _controller.stop();
        _controller.value = 1.0;
      }
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final baseSize = screenWidth * 0.05;
    final timerSize = math.min(math.max(baseSize, 80.0), 100.0);
    final metricCircleSize = timerSize * 0.25;
    final metricCircleOffset = timerSize * 0.15;

    return SizedBox(
      width: 180,
      height: 80,
      child: Stack(
        alignment: Alignment.center,
        children: [
          AnimatedBuilder(
            animation: _controller,
            builder: (context, child) {
              return CustomPaint(
                painter: SemicircleWithProgressPainter(
                  progress: _controller.value,
                  isActive: widget.isTimerActive,
                  backgroundColor: Colors.black.withOpacity(0.9),
                  borderWidth: 5.0,
                  strokeWidth: 5.0,
                ),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        widget.username,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        widget.score.toString(),
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
          Positioned(
            right: 20,
            top: 10,
              child: AnimatedBuilder(
                  animation: _controller,
                  builder: (context,child){
                    int remainingSeconds = widget.isTimerActive
                        ? (widget.timerDuration.inSeconds * (1 - _controller.value)).ceil()
                        : widget.metric1;
                    return _buildSmallCircle(remainingSeconds, metricCircleSize);
                  }
              )
          ),
          Positioned(
            right: 0,
            top: 10,
            bottom: metricCircleOffset,
            child: _buildSmallCircle(widget.metric2, metricCircleSize),
          ),
        ],
      )
    );
  }
}

/// Timer....
Widget createProfileTimer({
  required String username,
  required int score,
  required int metric1,
  required int metric2,
  required bool isTimerActive,
  Duration timerDuration = const Duration(seconds: 10),
  VoidCallback? onTimerFinished,
}) {
  return ProfileTimerWidget(
    username: username,
    score: score,
    metric1: metric1,
    metric2: metric2,
    isTimerActive: isTimerActive,
    timerDuration: timerDuration,
    onTimerFinished: onTimerFinished,
  );
}

/// Loading Indicator for Point_game_lobby...
class LoadingOverlay extends StatefulWidget {
  final List<String> imagesToPreload;
  final VoidCallback onLoadingComplete;

  const LoadingOverlay({
    required this.imagesToPreload,
    required this.onLoadingComplete,
    super.key,
  });

  @override
  State<LoadingOverlay> createState() => _LoadingOverlayState();
}

class _LoadingOverlayState extends State<LoadingOverlay> {
  double _progress = 0.0;

  @override
  void initState() {
    super.initState();
    _preloadComponents();
  }

  Future<void> _preloadComponents() async {
    final int totalComponents = widget.imagesToPreload.length + 2;
    final double step = 100 / totalComponents;

    for (String imagePath in widget.imagesToPreload) {
      await precacheImage(AssetImage(imagePath), context);
      setState(() {
        _progress += step;
      });
    }

    await Future.delayed(const Duration(seconds: 1));
    setState(() {
      _progress += step;
    });

    await Future.delayed(const Duration(seconds: 1));
    setState(() {
      _progress += step;
    });

    setState(() {
      _progress = 100;
    });
    widget.onLoadingComplete();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black.withOpacity(0.5),
      child: Center(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                "Starting your game",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              Container(
                width: 300,
                child: Stack(
                  children: [
                    Container(
                      height: 20,
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.5),
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    Container(
                      height: 20,
                      width: 300 * (_progress / 100),
                      decoration: BoxDecoration(
                        color: Colors.green,
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 5),
              Text(
                "${_progress.toInt()}%",
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}