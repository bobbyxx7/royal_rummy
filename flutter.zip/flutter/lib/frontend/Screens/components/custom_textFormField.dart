import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Custom TextFormField widget to manage its own focus and text state
class CustomTextFormField extends StatefulWidget {
  final TextEditingController controller;
  final FocusNode focusNode;
  final String labelText;
  final TextInputType keyboardType;
  final IconData icon;
  final List<TextInputFormatter>? inputFormatters;
  final String? Function(String?)? validator;
  final ValueNotifier<bool>? obscureText;
  final Widget? suffix;
  final Widget? suffixIcon;
  final void Function(String)? onChanged;

  const CustomTextFormField({
    super.key,
    required this.controller,
    required this.focusNode,
    required this.labelText,
    required this.keyboardType,
    required this.icon,
    this.inputFormatters,
    this.validator,
    this.suffix,
    this.suffixIcon,
    this.obscureText,
    this.onChanged,
  });

  @override
  _CustomTextFormFieldState createState() => _CustomTextFormFieldState();
}

class _CustomTextFormFieldState extends State<CustomTextFormField> {
  bool _isFocused = false;
  bool _hasData = false;

  @override
  void initState() {
    super.initState();
    widget.focusNode.addListener(_onFocusChanged);
    widget.controller.addListener(_onTextChanged);
    _hasData = widget.controller.text.isNotEmpty;
  }

  void _onFocusChanged() {
    setState(() {
      _isFocused = widget.focusNode.hasFocus;
    });
  }

  void _onTextChanged() {
    setState(() {
      _hasData = widget.controller.text.isNotEmpty;
    });
  }

  @override
  void dispose() {
    widget.focusNode.removeListener(_onFocusChanged);
    widget.controller.removeListener(_onTextChanged);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bool shouldFill = _isFocused || _hasData;

    final Color iconColor = _isFocused ? Colors.amber : const Color(0xFF9E7006);
    final Color labelColor = _isFocused ? Colors.amber : Colors.white70;
    final Color borderColor = _isFocused
        ? Colors.amber
        : const Color.fromRGBO(55, 71, 79, 1);
    final Color focusedBorderColor = Colors.amber;
    final Color fillColor = shouldFill
        ? Colors.white.withOpacity(0.2)
        : Colors.transparent;

    // Helper method to build the TextFormField with the appropriate obscureText logic
    Widget buildTextFormField({required bool obscureTextValue}) {
      return TextFormField(
        controller: widget.controller,
        focusNode: widget.focusNode,
        style: const TextStyle(color: Colors.white),
        keyboardType: widget.keyboardType,
        cursorColor: Colors.amber,
        inputFormatters: widget.inputFormatters,
        obscureText: obscureTextValue,
        onChanged: widget.onChanged,
        decoration: InputDecoration(
          labelText: widget.labelText,
          labelStyle: TextStyle(color: labelColor),
          prefixIcon: Icon(widget.icon, color: Colors.amber),
          suffix: widget.suffix,
          suffixIcon: widget.suffixIcon,
          filled: true,
          fillColor: fillColor,
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
                color: Colors.amber, width: _isFocused ? 2.0 : 1.0),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.amber, width: 2.0),
          ),
          errorBorder: const OutlineInputBorder(
            borderSide: BorderSide(color: Colors.red, width: 1.0),
          ),
          focusedErrorBorder: const OutlineInputBorder(
            borderSide: BorderSide(color: Colors.red, width: 2.0),
          ),
        ),
        validator: widget.validator,
      );
    }

    // Only apply ValueListenableBuilder for obscureText if it's provided (i.e., for password field)
    if (widget.obscureText != null) {
      return ValueListenableBuilder<bool>(
        valueListenable: widget.obscureText!,
        builder: (context, isObscured, child) {
          return buildTextFormField(obscureTextValue: !isObscured);
        },
      );
    } else {
      // For non-password fields, obscureText is false by default
      return buildTextFormField(obscureTextValue: false);
    }
  }
}