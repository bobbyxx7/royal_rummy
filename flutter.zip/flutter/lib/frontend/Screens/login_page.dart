import 'package:arka_infotech/frontend/Screens/components/internet_connectivity.dart';
import 'package:arka_infotech/frontend/Screens/components/reusable_alert_dialog.dart';
import 'package:arka_infotech/frontend/Socket/socket_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:provider/provider.dart';
import '../../provider/auth_view_model.dart';
import '../../provider/app_state_provider.dart';
import 'components/animations.dart';
import 'components/custom_textFormField.dart';
import 'components/reusable_buttons.dart';
import 'components/splash_Screen.dart';
import 'otp_verification_page.dart';
import 'register_page.dart';
import 'forgot_password_dialog.dart';
import 'dashboard_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  final _phoneController = TextEditingController();
  final _passwordController = TextEditingController();
  final _phoneFocusNode = FocusNode();
  final _passwordFocusNode = FocusNode();
  final ValueNotifier<bool> _isPasswordVisible = ValueNotifier<bool>(false);

  @override
  void initState() {
    super.initState();
    _setPortraitMode();
  }

  Future<void> _setPortraitMode() async {
    await SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
  }

  @override
  void dispose() {
    _phoneController.dispose();
    _passwordController.dispose();
    _phoneFocusNode.dispose();
    _passwordFocusNode.dispose();
    _isPasswordVisible.dispose();
    super.dispose();
  }

  void _showAlertDialog(String message) {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('Login Error'),
            content: Text(message),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('OK'),
              ),
            ],
          ),
    );
  }

  void _handleLogin() async {
    if (_formKey.currentState!.validate()) {
      if (!await checkInternetConnection()) {
        showDialog(
          context: context,
          builder:
              (_) => ReusableAlertDialog(
                title: "No Internet",
                message:
                    "You are not connected to the internet. Please check your connection and try again.",
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('OK'),
                  ),
                ],
              ),
        );
        return;
      }
      final authViewModel = context.read<AuthViewModel>();
      final appStateProvider = context.read<AppStateProvider>();

      // Send API request for login
      final success = await authViewModel.loginWithPassword(
        _phoneController.text,
        _passwordController.text,
      );

      // If API returns 200 (success), handle login and navigate to dashboard
      if (success) {
        print(
          'Login successful, handling app state and navigating to dashboard',
        );

        Navigator.pushReplacement(
          context,
          customSlideTransition(
            SplashScreen(
              backgroundImagePath: 'assets/dashboard_bg.png',
              onLoad: simulateLoading,
              nextPage: const DashboardPage(),
            ),
          ),
        );
      } else {
        // If API fails, show error message
        print('Login failed: ${authViewModel.errorMessage}');
        _showAlertDialog(
          authViewModel.errorMessage ?? 'Login failed. Please try again.',
        );
      }
    } else {
      _showAlertDialog('Please fill all required fields.');
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;
    final padding = screenWidth * 0.06;

    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) {
        if (!didPop) {
          SystemNavigator.pop();
        }
      },
      child: Scaffold(
        resizeToAvoidBottomInset: true,
        body: Consumer<AuthViewModel>(
          builder: (context, authViewModel, child) {
            return Stack(
              children: [
                Container(
                  height: screenHeight,
                  width: screenWidth,
                  decoration: const BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage('assets/img.png'),
                      fit: BoxFit.cover,
                      alignment: Alignment.topCenter,
                    ),
                  ),
                  child: SingleChildScrollView(
                    padding: EdgeInsets.all(padding),
                    child: ConstrainedBox(
                      constraints: BoxConstraints(
                        minHeight: screenHeight - (padding * 2),
                      ),
                      child: Form(
                        key: _formKey,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            SizedBox(height: screenHeight * 0.03),
                            Center(
                              child: Image.asset(
                                'assets/login_logo.png',
                                width: screenWidth * 0.4,
                                height: screenHeight * 0.2,
                                fit: BoxFit.contain,
                              ),
                            ),
                            SizedBox(height: screenHeight * 0.015),
                            const Text(
                              'Login',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 24,
                                fontStyle: FontStyle.italic,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: screenHeight * 0.03),
                            CustomTextFormField(
                              controller: _phoneController,
                              focusNode: _phoneFocusNode,
                              labelText: 'Phone Number',
                              keyboardType: TextInputType.phone,
                              icon: Icons.phone,
                              inputFormatters: [
                                FilteringTextInputFormatter.digitsOnly,
                                LengthLimitingTextInputFormatter(10),
                              ],
                              validator:
                                  (value) =>
                                      value == null || value.isEmpty
                                          ? 'Please enter your phone number'
                                          : null,
                            ),
                            SizedBox(height: screenHeight * 0.03),
                            CustomTextFormField(
                              controller: _passwordController,
                              focusNode: _passwordFocusNode,
                              labelText: 'Password',
                              keyboardType: TextInputType.visiblePassword,
                              icon: Icons.key,
                              inputFormatters: [
                                FilteringTextInputFormatter.singleLineFormatter,
                                LengthLimitingTextInputFormatter(20),
                              ],
                              obscureText: _isPasswordVisible,
                              suffixIcon: ValueListenableBuilder<bool>(
                                valueListenable: _isPasswordVisible,
                                builder: (context, isVisible, child) {
                                  return IconButton(
                                    icon: Icon(
                                      isVisible
                                          ? Icons.visibility
                                          : Icons.visibility_off,
                                      color:
                                          _passwordFocusNode.hasFocus
                                              ? Colors.amber
                                              : Colors.white70,
                                    ),
                                    onPressed: () {
                                      _isPasswordVisible.value = !isVisible;
                                    },
                                  );
                                },
                              ),
                              validator:
                                  (value) =>
                                      value == null || value.isEmpty
                                          ? 'Please enter your password'
                                          : null,
                            ),
                            SizedBox(height: screenHeight * 0.03),
                            LoginRegisterBtn(
                              text: 'Login',
                              outerContainerColor: const Color(0xFF9E0606),
                              gradientColors: const [
                                Color(0xFFE89090),
                                Color(0xFFED3131),
                                Color(0xFFED3131),
                              ],
                              onPressed: _handleLogin,
                            ),
                            SizedBox(height: screenHeight * 0.03),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                TextButton(
                                  onPressed: () {
                                    showDialog(
                                      context: context,
                                      builder:
                                          (context) =>
                                              const ForgotPasswordDialog(),
                                    );
                                  },
                                  child: const Text(
                                    'Forget Password ?',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                      decoration: TextDecoration.underline,
                                      decorationColor: Colors.white,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: screenHeight * 0.03),
                            LoginRegisterBtn(
                              text: 'Register',
                              outerContainerColor: const Color(0xFF9E7006),
                              gradientColors: const [
                                Color(0xFF6A4A3A),
                                Color(0xFF321907),
                                Color(0xFF121205),
                              ],
                              onPressed: () {
                                Navigator.pushNamed(context, '/register');
                              },
                            ),
                            SizedBox(height: screenHeight * 0.1),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                if (authViewModel.isLoading)
                  Container(
                    color: Colors.black54,
                    child: const Center(
                      child: SpinKitCircle(color: Colors.amber, size: 50.0),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }
}
