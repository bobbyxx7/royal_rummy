import 'package:arka_infotech/frontend/Screens/user_profile.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:provider/provider.dart';
import '../../model/user_model.dart';
import '../../provider/auth_view_model.dart';
import '../../provider/app_state_provider.dart';
import '../../services/secure_storage_service.dart';
import '../Socket/socket_service.dart';
import 'Game_Screen/deal_game_dashboard.dart';
import 'Game_Screen/point_game_dashboard.dart';
import 'Game_Screen/pool_game_dashboard.dart';
import 'components/Animations.dart';
import 'components/GameCard.dart';
import 'components/reusable_buttons.dart';
import 'components/splash_Screen.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> with WidgetsBindingObserver {
  final ValueNotifier<int> _selectedPlayer = ValueNotifier(2);
  final ValueNotifier<double> _pointValue = ValueNotifier(0.05);
  bool _isLoading = true;
  bool _isNavigating = false;
  UserModel? _user;
  final SecureStorageService _secureStorage = SecureStorageService();
  late final AuthViewModel authViewModel;
  late final AppStateProvider appStateProvider;
  late final SocketService socketService;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _setLandscapeMode();
    authViewModel = Provider.of<AuthViewModel>(context, listen: false);
    appStateProvider = Provider.of<AppStateProvider>(context, listen: false);
    socketService = Provider.of<SocketService>(context, listen: false);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _setPortraitMode();
    _selectedPlayer.dispose();
    _pointValue.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    // AppStateProvider will handle lifecycle changes
    appStateProvider.handleAppLifecycleChange(state.name);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _precacheImages();
  }

  Future<void> _setLandscapeMode() async {
    await SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    await Future.delayed(const Duration(milliseconds: 300));
    if (mounted) {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _setPortraitMode() async {
    await SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
  }

  Future<void> _precacheImages() async {
    final images = [
      'assets/dashboard_bg.png',
      'assets/profile.png',
      'assets/dashboard_assets/availabe_balance_logo.png',
      'assets/dashboard_assets/coins_logo.png',
      'assets/dashboard_assets/cards_point.png',
      'assets/dashboard_assets/points_rummy.png',
      'assets/dashboard_assets/pools_rummy.png',
      'assets/dashboard_assets/deals_rummy.png',
    ];
    for (final image in images) {
      await precacheImage(AssetImage(image), context);
    }
  }

  Widget _buildConnectionStatusIndicator(double size) {
    return Consumer2<AppStateProvider, SocketService>(
      builder: (context, appStateProvider, socketProvider, child) {
        return Container(
          width: size * 0.015,
          height: size * 0.025,
          decoration: BoxDecoration(
            color: socketProvider.isConnected ? Colors.green : Colors.red,
            shape: BoxShape.circle,
            border: Border.all(
              color: Colors.white,
              width: 2,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 4,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: appStateProvider.isSocketConnecting
              ? const Center(
                  child: SizedBox(
                    width: 8,
                    height: 8,
                    child: CircularProgressIndicator(
                      strokeWidth: 1,
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                    ),
                  ),
                )
              : null,
        );
      },
    );
  }

  Widget _buildNavigationButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    required double width,
    required double height,
  }) {
    return Padding(
      padding: EdgeInsets.symmetric(
        horizontal: width * 0.02,
        vertical: height * 0.005,
      ),
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: width,
          padding: EdgeInsets.symmetric(
            vertical: height * 0.01,
            horizontal: width * 0.01,
          ),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(width * 0.08),
            border: Border.all(
              color: Colors.amber.withOpacity(0.2),
              width: width * 0.015,
            ),
            gradient: LinearGradient(
              colors: [
                Colors.black.withOpacity(0.6),
                Colors.black.withOpacity(0.8)
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                color: Colors.amber,
                size: height * 0.05,
              ),
              SizedBox(height: height * 0.01),
              Text(
                label,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: height * 0.025,
                  fontWeight: FontWeight.w600,
                ),
                textAlign: TextAlign.center,
                overflow: TextOverflow.ellipsis,
                maxLines: 2,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildResponsiveGameCard({
    required String imagePath,
    required String title,
    required String minPlayers,
    required String maxPlayers,
    required VoidCallback onTap,
    required double availableWidth,
    required double availableHeight,
  }) {
    final cardWidth = availableWidth * 0.25;
    final cardHeight = availableHeight * 0.6;
    
    return SizedBox(
      width: cardWidth,
      height: cardHeight,
      child: GameCard(
        imagePath: imagePath,
        title: title,
        minPlayers: minPlayers,
        maxPlayers: maxPlayers,
        onTap: _isNavigating ? null : onTap,
      ),
    );
  }

  Future<void> _navigateToPointGameDashboard() async {
    if (!appStateProvider.isSocketConnected) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please wait, connecting to server...'),
          backgroundColor: Colors.orange,
          duration: Duration(seconds: 2),
        ),
      );
      return;
    }

    setState(() {
      _isNavigating = true;
    });

    await Future.delayed(const Duration(milliseconds: 500));

    if (mounted) {
      Navigator.push(
        context,
        customSlideTransition(SplashScreen(
          backgroundImagePath: 'assets/dashboard_bg.png',
          onLoad: simulateLoading,
          nextPage: PointGameDashboard(socketService: socketService),
        )),
      ).then((_) {
        if (mounted) {
          setState(() {
            _isNavigating = false;
          });
        }
      });
    }
  }

  Future<void> _navigateToPoolGameDashboard() async {
    setState(() {
      _isNavigating = true;
    });

    await Future.delayed(const Duration(milliseconds: 500));

    if (mounted) {
      Navigator.push(
        context,
        customSlideTransition(const PoolGameDashboard()),
      ).then((_) {
        if (mounted) {
          setState(() {
            _isNavigating = false;
          });
        }
      });
    }
  }

  Future<void> _navigateToDealGameDashboard() async {
    setState(() {
      _isNavigating = true;
    });

    await Future.delayed(const Duration(milliseconds: 500));

    if (mounted) {
      Navigator.push(
        context,
        customSlideTransition(const DealGameDashboard()),
      ).then((_) {
        if (mounted) {
          setState(() {
            _isNavigating = false;
          });
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final mediaQuery = MediaQuery.of(context);
    final screenWidth = mediaQuery.size.width;
    final screenHeight = mediaQuery.size.height;
    final topPadding = mediaQuery.padding.top;
    final bottomPadding = mediaQuery.padding.bottom;

    return Scaffold(
      backgroundColor: Colors.transparent,
      resizeToAvoidBottomInset: false,
      body: Consumer3<AuthViewModel, SocketService, AppStateProvider>(
        builder: (context, authProvider, socketProvider, appStateProvider, child) {
          final user = authViewModel.user!;
          return LayoutBuilder(
            builder: (context, constraints) {
              final availableWidth = constraints.maxWidth;
              final availableHeight = constraints.maxHeight;
              final padding = availableWidth * 0.005;

              return Stack(
                children: [
                  // Background
                  Image.asset(
                    'assets/dashboard_bg.png',
                    fit: BoxFit.cover,
                    width: availableWidth,
                    height: availableHeight,
                    color: const Color(0xFFF51925).withOpacity(0.5),
                    colorBlendMode: BlendMode.dstOver,
                  ),
                  
                  // Main content
                  Padding(
                    padding: EdgeInsets.only(
                      top: topPadding > 0 ? topPadding : 8,
                      bottom: bottomPadding > 0 ? bottomPadding : 8,
                      left: 8,
                      right: 8,
                    ),
                    child: Column(
                      children: [
                        // Header section
                        _buildHeaderSection(
                          user: user,
                          availableWidth: availableWidth,
                          availableHeight: availableHeight,
                          padding: padding,
                        ),
                        
                        // Main content area
                        Expanded(
                          child: Row(
                            children: [
                              // Game cards section
                              Expanded(
                                child: _buildGameCardsSection(
                                  availableWidth: availableWidth,
                                  availableHeight: availableHeight,
                                ),
                              ),
                              
                              // Side navigation
                              _buildSideNavigation(
                                availableWidth: availableWidth,
                                availableHeight: availableHeight,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  
                  // Loading overlay
                  if (_isNavigating)
                    Container(
                      width: availableWidth,
                      height: availableHeight,
                      color: Colors.black.withOpacity(0.7),
                      child: Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const CircularProgressIndicator(
                              color: Colors.amber,
                              strokeWidth: 4,
                            ),
                            SizedBox(height: availableHeight * 0.02),
                            Text(
                              'Loading Game...',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: (availableHeight * 0.025).clamp(16.0, 24.0),
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                ],
              );
            },
          );
        },
      ),
    );
  }

  Widget _buildHeaderSection({
    required UserModel user,
    required double availableWidth,
    required double availableHeight,
    required double padding,
  }) {
    return Padding(
      padding: EdgeInsets.all(padding),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Profile with connection status
          Stack(
            children: [
              GestureDetector(
                onTap: () {
                  Navigator.pushReplacement(
                    context,
                    customSlideTransition(
                      SplashScreen(
                        backgroundImagePath: 'assets/dashboard_bg.png',
                        onLoad: simulateLoading,
                        nextPage: UserProfilePage(),
                      ),
                    ),
                  );
                  print('Profile button tapped');
                },
                child: Image.asset(
                  'assets/profile.png',
                  width: availableWidth * 0.1,
                  height: availableHeight * 0.15,
                  fit: BoxFit.contain,
                ),
              ),
              Positioned(
                right: availableWidth * 0.02,
                top: availableWidth * 0.035,
                child: _buildConnectionStatusIndicator(availableWidth),
              ),
            ],
          ),
          
          SizedBox(width: padding),
          
          // Balance container
          _buildBalanceContainer(
            user: user,
            availableWidth: availableWidth,
            availableHeight: availableHeight,
          ),
          
          const Spacer(),
          
          // Coins container
          _buildCoinsContainer(
            availableWidth: availableWidth,
            availableHeight: availableHeight,
          ),
          
          SizedBox(width: availableWidth * 0.01),
          
          // Cards points container
          _buildCardsPointsContainer(
            availableWidth: availableWidth,
            availableHeight: availableHeight,
          ),
        ],
      ),
    );
  }

  Widget _buildBalanceContainer({
    required UserModel user,
    required double availableWidth,
    required double availableHeight,
  }) {
    return Container(
      width: availableWidth * 0.22,
      height: availableHeight * 0.1,
      decoration: BoxDecoration(
        color: Colors.amber,
        borderRadius: BorderRadius.circular(availableHeight * 0.05),
        gradient: const LinearGradient(
          colors: [Colors.red, Colors.yellowAccent, Colors.red],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Container(
        margin: EdgeInsets.all(availableHeight * 0.005),
        decoration: BoxDecoration(
          color: Colors.amber,
          borderRadius: BorderRadius.circular(availableHeight * 0.045),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              width: availableHeight * 0.05,
              height: availableHeight * 0.05,
              decoration: const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
              ),
              child: IconButton(
                icon: Icon(
                  Icons.add_circle,
                  color: Colors.amber,
                  size: availableHeight * 0.05,
                ),
                onPressed: () {
                  print('Add Balance tapped');
                },
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
              ),
            ),
            Expanded(
              child: Row(
                children: [
                  Text(
                    '₹ ',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: availableHeight * 0.04,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Expanded(
                    child: Text(
                      user.wallet,
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: availableHeight * 0.04,
                        fontWeight: FontWeight.bold,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
            Image.asset(
              'assets/dashboard_assets/availabe_balance_logo.png',
              width: availableWidth * 0.04,
              height: availableHeight * 0.08,
              fit: BoxFit.contain,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCoinsContainer({
    required double availableWidth,
    required double availableHeight,
  }) {
    return Container(
      width: availableWidth * 0.17,
      height: availableHeight * 0.1,
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.6),
        borderRadius: BorderRadius.circular(availableHeight * 0.025),
        border: Border.all(color: Colors.amber),
      ),
      child: Row(
        children: [
          SizedBox(width: availableWidth * 0.01),
          Image.asset(
            'assets/dashboard_assets/coins_logo.png',
            height: availableHeight * 0.06,
            fit: BoxFit.contain,
          ),
          SizedBox(width: availableWidth * 0.01),
          Expanded(
            child: Text(
              '15890',
              style: TextStyle(
                color: Colors.white,
                fontSize: availableHeight * 0.04,
                fontWeight: FontWeight.bold,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCardsPointsContainer({
    required double availableWidth,
    required double availableHeight,
  }) {
    return Container(
      width: availableWidth * 0.17,
      height: availableHeight * 0.1,
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.6),
        borderRadius: BorderRadius.circular(availableHeight * 0.025),
        border: Border.all(color: Colors.amber),
      ),
      child: Row(
        children: [
          SizedBox(width: availableWidth * 0.01),
          Image.asset(
            'assets/dashboard_assets/cards_point.png',
            height: availableHeight * 0.06,
            fit: BoxFit.contain,
          ),
          SizedBox(width: availableWidth * 0.01),
          Expanded(
            child: Text(
              '15890',
              style: TextStyle(
                color: Colors.white,
                fontSize: availableHeight * 0.04,
                fontWeight: FontWeight.bold,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGameCardsSection({
    required double availableWidth,
    required double availableHeight,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        _buildResponsiveGameCard(
          imagePath: 'assets/dashboard_assets/points_rummy.png',
          title: 'Point Rummy',
          minPlayers: '101',
          maxPlayers: '201',
          onTap: () {
            print('Point Rummy card tapped!');
            _navigateToPointGameDashboard();
          },
          availableWidth: availableWidth,
          availableHeight: availableHeight,
        ),
        _buildResponsiveGameCard(
          imagePath: 'assets/dashboard_assets/pools_rummy.png',
          title: 'Pool Rummy',
          minPlayers: '101',
          maxPlayers: '201',
          onTap: () {
            print('Pool Rummy card tapped!');
            _navigateToPoolGameDashboard();
          },
          availableWidth: availableWidth,
          availableHeight: availableHeight,
        ),
        _buildResponsiveGameCard(
          imagePath: 'assets/dashboard_assets/deals_rummy.png',
          title: 'Deal Rummy',
          minPlayers: '101',
          maxPlayers: '201',
          onTap: () {
            print('Deal Rummy card tapped!');
            _navigateToDealGameDashboard();
          },
          availableWidth: availableWidth,
          availableHeight: availableHeight,
        ),
      ],
    );
  }

  Widget _buildSideNavigation({
    required double availableWidth,
    required double availableHeight,
  }) {
    return Container(
      width: availableWidth * 0.12,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(availableHeight * 0.025),
        color: Colors.transparent,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 10,
            offset: const Offset(-2, 0),
          ),
        ],
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildNavigationButton(
              icon: Icons.local_offer,
              label: 'Promotions',
              onTap: () {
                print('Promotions tapped');
              },
              width: availableWidth * 0.12,
              height: availableHeight,
            ),
            _buildNavigationButton(
              icon: Icons.account_balance_wallet,
              label: 'Withdraw',
              onTap: () {
                print('Withdraw tapped');
              },
              width: availableWidth * 0.12,
              height: availableHeight,
            ),
            _buildNavigationButton(
              icon: Icons.casino,
              label: 'My Game',
              onTap: () {
                print('My Game tapped');
              },
              width: availableWidth * 0.12,
              height: availableHeight,
            ),
            _buildNavigationButton(
              icon: Icons.support_agent,
              label: 'Support',
              onTap: () {
                print('Support tapped');
              },
              width: availableWidth * 0.12,
              height: availableHeight,
            ),
            _buildNavigationButton(
              icon: Icons.settings,
              label: 'Settings',
              onTap: () {
                print('Settings tapped');
              },
              width: availableWidth * 0.12,
              height: availableHeight,
            ),
          ],
        ),
      ),
    );
  }
}