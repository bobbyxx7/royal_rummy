import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../../provider/Auth_provider.dart';
import '../components/Animations.dart';
import '../components/reusable_buttons.dart';
import 'Game_Lobby/deal_game_lobby.dart';

// DashboardPage displayed after successful login
class DealGameDashboard extends StatefulWidget {
  const DealGameDashboard({super.key});

  @override
  State<DealGameDashboard> createState() => _DealGameDashboardState();
}

class _DealGameDashboardState extends State<DealGameDashboard> {
  final ValueNotifier<int> _selectedPlayer = ValueNotifier(2);
  final ValueNotifier<double> _pointValue = ValueNotifier(5);

  @override
  void initState() {
    super.initState();
    // _setLandscapeMode();
  }

  @override
  void dispose() {
    // _setPortraitMode();
    _selectedPlayer.dispose(); // Dispose of ValueNotifier
    _pointValue.dispose(); // Dispose of ValueNotifier
    super.dispose();
  }

  // Future<void> _setLandscapeMode() async {
  //   await SystemChrome.setPreferredOrientations([
  //     DeviceOrientation.landscapeLeft,
  //     DeviceOrientation.landscapeRight,
  //   ]);
  // }
  //
  // Future<void> _setPortraitMode() async {
  //   await SystemChrome.setPreferredOrientations([
  //     DeviceOrientation.portraitUp,
  //     DeviceOrientation.portraitDown,
  //   ]);
  // }

  Widget _buildNavigationButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: double.infinity,
          padding: EdgeInsets.symmetric(vertical: 3, horizontal: 2),
          decoration: BoxDecoration(
            // color: Colors.white.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: Colors.amber.withOpacity(0.2),
              width: 1,
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                color: Colors.amber,
                size: 24,
              ),
              SizedBox(height: 8),
              Text(
                label,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;
    final padding = screenWidth * 0.005;

    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Stack(
        children: [
          Image.asset(
            'assets/dashboard_bg.png',
            fit: BoxFit.cover,
            width: screenWidth,
            height: screenHeight,
            color: const Color(0xFFF51925).withOpacity(0.5),
            colorBlendMode: BlendMode.dstOver,
          ),
          Column(
            children: [
              Padding(
                padding: EdgeInsets.all(padding),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    GestureDetector(
                      onTap: () {
                        print('Profile button tapped');
                      },
                      child: Image.asset(
                        'assets/profile.png',
                        width: screenWidth * 0.1,
                        height: screenHeight * 0.15,
                      ),
                    ),
                    SizedBox(width: padding),
                    Container(
                      width: screenWidth * 0.22,
                      height: screenHeight * 0.1,
                      decoration: BoxDecoration(
                        color: Colors.amber,
                        borderRadius: BorderRadius.circular(20),
                        gradient: const LinearGradient(
                          colors: [Colors.red, Colors.yellowAccent, Colors.red],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                      ),
                      child: Container(
                        margin: const EdgeInsets.all(2),
                        decoration: BoxDecoration(
                          color: Colors.amber,
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Container(
                              width: 20,
                              height: 20,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                shape: BoxShape.circle, // Makes the container circular
                              ),
                              child: IconButton(
                                icon: Icon(
                                  size: 20,
                                  Icons.add_circle,
                                  color: Colors.amber,
                                ),
                                onPressed: () {
                                  print('Add Balance tapped');
                                },
                                padding: EdgeInsets.zero,
                                constraints: BoxConstraints(),
                              ),
                            ),
                            Row(
                              children: [
                                const Text(
                                  '₹ ',
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const Text(
                                  '15890.0',
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                            Image.asset(
                              'assets/dashboard_assets/availabe_balance_logo.png',
                              width: screenWidth * 0.04,
                              height: screenHeight * 0.08,
                            ),
                          ],
                        ),
                      ),
                    ),
                    Spacer(),
                    Container(
                      width: screenWidth * 0.17,
                      height: screenHeight * 0.1,
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.6),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.amber),
                      ),
                      child: Row(
                        children: [
                          SizedBox(width: 10),
                          Image.asset(
                            'assets/dashboard_assets/coins_logo.png',
                            height: screenHeight * 0.06,
                          ),
                          SizedBox(width: 10),
                          const Text(
                            '15890',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(width: 10),
                    Container(
                      width: screenWidth * 0.17,
                      height: screenHeight * 0.1,
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.6),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.amber),
                      ),
                      child: Row(
                        children: [
                          SizedBox(width: 10),
                          Image.asset(
                            'assets/dashboard_assets/cards_point.png',
                            height: screenHeight * 0.06,
                          ),
                          SizedBox(width: 10),
                          const Text(
                            '15890',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          /// Select player text
                          Text(
                            'Select Players',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontFamily: 'Arial',
                              fontStyle: FontStyle.italic,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 10),

                          ValueListenableBuilder<int>(
                            valueListenable: _selectedPlayer,
                            builder: (context, selectedPlayer, child) {
                              return Container(
                                width: 210,
                                height: 50,
                                decoration: BoxDecoration(
                                  border: Border.all(
                                      color: Colors.white,
                                      width: 2
                                  ),
                                  borderRadius: BorderRadius.circular(10),
                                  gradient: LinearGradient(
                                    colors: [
                                      Colors.white,
                                      Colors.amber.shade600,
                                      Colors.amber.shade400,
                                      Colors.amber.shade600,
                                    ],
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                    stops: const [0.0, 0.3, 0.5, 1.0],
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.3),
                                      blurRadius: 8,
                                      offset: Offset(0, 4),
                                    ),
                                  ],
                                ),
                                child: Row(
                                  children: [
                                    // Left side (2 players)
                                    Expanded(
                                      child: GestureDetector(
                                        onTap: () {
                                          _selectedPlayer.value = 2;
                                          print('The value slected is 2');
                                        },
                                        child: Container(
                                          height: 50,
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.only(
                                              topLeft: Radius.circular(10),
                                              bottomLeft: Radius.circular(10),
                                            ),
                                            gradient: selectedPlayer == 2
                                                ? null : LinearGradient(
                                              colors: [
                                                Colors.white,
                                                Colors.black87,
                                                Colors.black,
                                                Colors.black87
                                              ],
                                              begin: Alignment.topCenter,
                                              end: Alignment.bottomCenter,
                                              stops: const [0.0, 0.3, 0.5, 1.0],
                                            ),
                                          ),
                                          child: Center(
                                            child: Text(
                                              '2 Deals',
                                              style: TextStyle(
                                                color: selectedPlayer == 2
                                                    ? Colors.black
                                                    : Colors.white,
                                                fontSize: 18,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    // Right side (6 players)
                                    Expanded(
                                      child: GestureDetector(
                                        onTap: () {
                                          _selectedPlayer.value = 6;
                                          print('The value slected is 6');
                                        },
                                        child: Container(
                                          height: 50,
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.only(
                                              topRight: Radius.circular(10),
                                              bottomRight: Radius.circular(10),
                                            ),
                                            gradient: selectedPlayer == 6
                                                ? null : LinearGradient(
                                              colors: [
                                                Colors.white,
                                                Colors.black87,
                                                Colors.black,
                                                Colors.black87
                                              ],
                                              begin: Alignment.topCenter,
                                              end: Alignment.bottomCenter,
                                              stops: const [0.0, 0.3, 0.5, 1.0],
                                            ),
                                          ),
                                          child: Center(
                                            child: Text(
                                              '6 Deals',
                                              style: TextStyle(
                                                color: selectedPlayer == 6
                                                    ? Colors.black
                                                    : Colors.white,
                                                fontSize: 18,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),

                          SizedBox(height: 20,),
                          ValueListenableBuilder<double>(
                            valueListenable: _pointValue,
                            builder: (context, pointValue, child) {
                              return Container(
                                padding: EdgeInsets.symmetric(
                                  horizontal: 40,
                                  vertical: 10,
                                ),
                                decoration: BoxDecoration(
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.3),
                                      blurRadius: 8,
                                      offset: Offset(0, 4),
                                    ),
                                  ],
                                  border: Border.all(
                                      color: Colors.white,
                                      width: 1
                                  ),
                                  color: Colors.black.withOpacity(0.6),
                                  borderRadius: BorderRadius.circular(10),
                                  gradient: LinearGradient(
                                    colors: [
                                      Colors.white,
                                      Colors.black26,
                                      Colors.black38,
                                      Colors.black45,
                                    ],
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                    stops: const [0.0, 0.3, 0.5, 1.0],
                                  ),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      'Entry Fees  =  ₹ ${pointValue.toStringAsFixed(2)}',
                                      style: TextStyle(
                                        fontStyle: FontStyle.italic,
                                        fontFamily: 'Arial',
                                        color: Colors.white,
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    SizedBox(width: 10),
                                    /// Need to change the Icon to spade icon or card icon..
                                    Image.asset(
                                      'assets/dashboard_assets/spade.png',
                                      width: 30,
                                      height: 25,
                                      fit: BoxFit.contain,
                                      color: Colors.amber,
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),

                          SizedBox(height: 20),

                          ValueListenableBuilder<double>(
                            valueListenable: _pointValue,
                            builder: (context, pointValue, child) {
                              return Row(
                                children: [
                                  SizedBox(width: screenWidth * 0.15,),
                                  /// make this circle the same size as the remove circle icon.
                                  Container(
                                    width: 32,
                                    height: 32,
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      shape: BoxShape.circle, // Makes the container circular
                                    ),
                                    child: IconButton(
                                      icon: Icon(
                                        size: 32,
                                        Icons.remove_circle,
                                        color: Colors.black,
                                      ),
                                      onPressed: () {
                                        if (_pointValue.value > 5) {
                                          _pointValue.value -= 5;
                                        }
                                      },
                                      padding: EdgeInsets.zero,
                                      constraints: BoxConstraints(),
                                    ),
                                  ),
                                  Expanded(
                                    child: Slider(
                                      value: pointValue,
                                      min: 5,
                                      max: 3000,
                                      onChanged: (value) {
                                        _pointValue.value = value;
                                      },
                                      activeColor: Colors.yellow,
                                      inactiveColor: Colors.black,
                                    ),
                                  ),
                                  /// make this circle the same size as the remove circle icon.
                                  Container(
                                    // color: Colors.white,
                                    width: 32,
                                    height: 32,
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      shape: BoxShape.circle, // Makes the container circular
                                    ),
                                    child: Center(
                                      child: IconButton(
                                        icon: Icon(
                                          size: 32,
                                          Icons.add_circle,
                                          color: Colors.black,
                                        ),
                                        onPressed: () {
                                          if (_pointValue.value < 3000) {
                                            _pointValue.value += 5;
                                          }
                                        },
                                        padding: EdgeInsets.zero,
                                        constraints: BoxConstraints(),
                                      ),
                                    ),
                                  ),
                                  SizedBox(width: screenWidth * 0.15,),
                                ],
                              );
                            },
                          ),
                          Row(
                            // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              SizedBox(width: screenWidth * 0.18,),
                              Text(
                                '5',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold
                                ),
                              ),
                              Spacer(),
                              Text(
                                '3000',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold
                                ),
                              ),
                              SizedBox(width: screenWidth * 0.2,),
                            ],
                          ),
                          SizedBox(height: 5,),
                          LoginRegisterBtn(
                            textColor: Colors.black,
                            widthSize1: screenWidth * 0.2,
                            widthSize2: screenWidth * 0.2,
                            text: 'Play Now',
                            outerContainerColor:  Colors.amber[800]!,
                            gradientColors:  [
                              Colors.amber[100]!,
                              Colors.amber,
                              Colors.amber[600]!,
                            ],
                            onPressed: () async {
                              Navigator.pushReplacement(
                                context,
                                customSlideTransition(DealGameLobby(numberOfPlayers: _selectedPlayer.value,)),
                              );
                            },
                          ),

                        ],
                      ),
                    ),
                    Container(
                      width: screenWidth * 0.12,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.transparent,
                        // gradient: LinearGradient(
                        //   colors: [
                        //     Color(0xFF8B4513), // Dark brown
                        //     Color(0xFFA0522D), // Saddle brown
                        //     Color(0xFF8B4513), // Dark brown
                        //   ],
                        //   begin: Alignment.topCenter,
                        //   end: Alignment.bottomCenter,
                        // ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.3),
                            blurRadius: 10,
                            offset: Offset(-2, 0),
                          ),
                        ],
                      ),
                      child: Column(
                        children: [
                          // SizedBox(height: 20,),
                          // Navigation Menu Items
                          _buildNavigationButton(
                            icon: Icons.local_offer,
                            label: 'Promotions',
                            onTap: () {
                              print('Promotions tapped');
                              // Navigate to promotions page
                            },
                          ),
                          _buildNavigationButton(
                            icon: Icons.account_balance_wallet,
                            label: 'Withdraw',
                            onTap: () {
                              print('Withdraw tapped');
                              // Navigate to withdraw page
                            },
                          ),
                          _buildNavigationButton(
                            icon: Icons.casino,
                            label: 'My Game',
                            onTap: () {
                              print('My Game tapped');
                              // Navigate to my games page
                            },
                          ),
                          _buildNavigationButton(
                            icon: Icons.support_agent,
                            label: 'Support',
                            onTap: () {
                              print('Support tapped');
                              // Navigate to support page
                            },
                          ),
                          _buildNavigationButton(
                            icon: Icons.settings,
                            label: 'Settings',
                            onTap: () {
                              print('Settings tapped');
                              // Navigate to settings page
                            },
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}