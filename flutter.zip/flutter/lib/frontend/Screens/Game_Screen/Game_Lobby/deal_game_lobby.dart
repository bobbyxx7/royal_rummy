import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../components/Canvas.dart';

class DealGameLobby extends StatefulWidget {
  final int numberOfPlayers;

  const DealGameLobby({super.key, required this.numberOfPlayers});

  @override
  State<DealGameLobby> createState() => _DealGameLobbyState();
}

class _DealGameLobbyState extends State<DealGameLobby> {
  final ValueNotifier<int> _entryLevel = ValueNotifier(10);
  final ValueNotifier<double> _pointValue = ValueNotifier(100.00);
  final ValueNotifier<int> _currentTurnIndex = ValueNotifier(0);
  final ValueNotifier<bool> _showLoading = ValueNotifier(true);
  final ValueNotifier<bool> _initialLoading = ValueNotifier(true); // New flag
  late int _totalPlayers;

  late List<Offset> _cachedPositions;

  final Map<int, List<Offset>> playerPositions = {
    2: [
      Offset(425, 80),
    ],
    6: [
      Offset(90, 120),
      Offset(275, 80),
      Offset(425, 80),
      Offset(575, 80),
      Offset(750, 120),
    ],
  };
  @override
  void initState() {
    super.initState();
    _totalPlayers = widget.numberOfPlayers;
    _startLoading();
    _cachedPositions = playerPositions[_totalPlayers] ?? [];
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  @override
  void dispose() {
    _entryLevel.dispose();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    _pointValue.dispose();
    _currentTurnIndex.dispose();
    _showLoading.dispose();
    super.dispose();
  }

  void _startLoading() {
    if (_initialLoading.value) {
      _showLoading.value = true;
      Future.delayed(const Duration(seconds: 3), () {
        _showLoading.value = false;
        _initialLoading.value = false;// Mark initial load as complete
        // _advanceTurn();
      });
    }
  }

  // void _advanceTurn() {
  //   _showLoading.value = true;
  //   Future.delayed(const Duration(seconds: 30), () {
  //     setState(() {
  //       _showLoading.value = false;
  //       int nextIndex = (_currentTurnIndex.value + 1) % _totalPlayers;
  //       _currentTurnIndex.value = nextIndex;
  //     });
  //   });
  // }

  void _advanceTurn() {
    if(!_initialLoading.value){
      Future.microtask((){
        setState(() {
          int nextIndex = (_currentTurnIndex.value + 1) % _totalPlayers;
          _currentTurnIndex.value = nextIndex;
        });
      });
    }
  }

  List<Widget> _buildProfileTimers() {
    List<Widget> profileTimers = [];

    int numOpponents = _totalPlayers - 1;
    List<Offset> positions = playerPositions[widget.numberOfPlayers] ?? [];

    for (int i = 0; i < numOpponents && i < _cachedPositions.length; i++) {
      int playerIndex = i + 1; // Main player is 0, opponents are 1 to n
      profileTimers.add(
        Positioned(
          left: positions[i].dx,
          top: positions[i].dy,
          child: ValueListenableBuilder<int>(
            valueListenable: _currentTurnIndex,
            builder: (context, currentTurn, child) {
              return ValueListenableBuilder<bool>(
                valueListenable: _showLoading,
                builder: (context, showLoading, child) {
                  return createProfileTimer(
                    username: "Opponent${i + 1}",
                    score: 4000,
                    metric1: 30,
                    metric2: 90,
                    isTimerActive: !showLoading && currentTurn == playerIndex,
                    onTimerFinished: _advanceTurn,
                    timerDuration: const Duration(seconds: 30),
                  );
                },
              );
            },
          ),
        ),
      );
    }
    return profileTimers;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Stack(
        clipBehavior: Clip.hardEdge,
        children: [
          Image.asset(
            'assets/dashboard_bg.png',
            fit: BoxFit.cover,
            width: double.infinity,
            height: double.infinity,
            color: const Color(0xFFF51925).withOpacity(0.5),
            colorBlendMode: BlendMode.dstOver,
          ),
          SizedBox(height: 10),
          Padding(
            padding: const EdgeInsets.only(top: 10.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(width: 20),
                IconButton(
                  icon: Icon(Icons.menu, color: Colors.amber, size: 30),
                  onPressed: () {
                    print('Menu tapped');
                  },
                ),
                SizedBox(width: 40),
                Expanded(
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.6),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.amber),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'Deals (2)',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                        SizedBox(width: 20),
                        Text(
                          ':',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(width: 20),
                        ValueListenableBuilder<int>(
                          valueListenable: _entryLevel,
                          builder: (context, entryLevel, child) {
                            return Text(
                              'Entry : $entryLevel',
                              style: TextStyle(
                                color: Colors.red[200],
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                              overflow: TextOverflow.ellipsis,
                            );
                          },
                        ),
                        SizedBox(width: 20),
                        Text(
                          'Round(s) : 0',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                        SizedBox(width: 20),
                        ValueListenableBuilder<double>(
                          valueListenable: _pointValue,
                          builder: (context, pointValue, child) {
                            return Text(
                              '₹ ${pointValue.toStringAsFixed(2)}',
                              style: TextStyle(
                                color: Colors.red[200],
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                              overflow: TextOverflow.ellipsis,
                            );
                          },
                        ),
                        SizedBox(width: 20),
                      ],
                    ),
                  ),
                ),
                SizedBox(width: 40),
                IconButton(
                  icon: Icon(Icons.settings, color: Colors.amber, size: 30),
                  onPressed: () {
                    print('Settings tapped');
                  },
                ),
              ],
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            top: 92,
            child: Image.asset(
              'assets/game_table2.png',
              fit: BoxFit.cover,
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            top: 370,
            child: Container(
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.6),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.amber),
              ),
              child: Row(
                children: [
                  SizedBox(width: 20),
                  ElevatedButton(
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all<Color>(Colors.amber),
                      foregroundColor: MaterialStateProperty.all<Color>(Colors.black),
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                      ),
                      elevation: MaterialStateProperty.all<double>(8.0),
                      shadowColor: MaterialStateProperty.all<Color>(Colors.amber.withOpacity(0.5)),
                      overlayColor: MaterialStateProperty.all<Color>(Colors.black12),
                    ),
                    onPressed: () {
                      print('Last Deal tapped');
                    },
                    child: Text(
                      'Last Deal',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  Spacer(),
                  ElevatedButton(
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all<Color>(Colors.amber),
                      foregroundColor: MaterialStateProperty.all<Color>(Colors.black),
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                      ),
                      elevation: MaterialStateProperty.all<double>(8.0),
                      shadowColor: MaterialStateProperty.all<Color>(Colors.amber.withOpacity(0.5)),
                      overlayColor: MaterialStateProperty.all<Color>(Colors.black12),
                    ),
                    onPressed: () {
                      print('Sort');
                    },
                    child: Text(
                      'Sort',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  SizedBox(width: 20),
                ],
              ),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            top: 360,
            child: Center(
              child: ValueListenableBuilder<int>(
                valueListenable: _currentTurnIndex,
                builder: (context, currentTurn, child) {
                  return ValueListenableBuilder<bool>(
                    valueListenable: _showLoading,
                    builder: (context, showLoading, child) {
                      return MainPlayerProfileTimerWidget(
                        username: "rummyn..",
                        score: 80,
                        metric1: 30,
                        metric2: 90,
                        isTimerActive: !showLoading && currentTurn == 0,
                        onTimerFinished: _advanceTurn,
                        timerDuration: const Duration(seconds: 30),
                      );
                    },
                  );
                },
              ),
            ),
          ),
          ..._buildProfileTimers(),
          ValueListenableBuilder<bool>(
            valueListenable: _showLoading,
            builder: (context, showLoading, child) {
              if (showLoading) {
                return LoadingOverlay(
                  imagesToPreload: [],
                  onLoadingComplete: () {
                    _showLoading.value = false;
                  },
                );
              }
              return SizedBox.shrink();
            },
          ),
        ],
      ),
    );
  }
}