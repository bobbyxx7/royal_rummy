// class GameLocalLogic {
//   static GameLocalLogic? _instance;
//   String jokerCard = '';
//   static const String invalid = 'Invalid';
//   static const String impureSequence = 'Impure sequence';
//   static const String pureSequence = 'Pure Sequence';
//   static const String set = 'set';
//   static const String mainJokerCard = 'JKR1';
//   static const String mainJokerCard2 = 'JKR2';
//   static const String dummyCard = 'backside_card';
//   static const int impureSequenceValue = 4;
//   static const int pureSequenceValue = 5;
//   static const int setValue = 6;
//
//   static GameLocalLogic getInstance() {
//     _instance ??= GameLocalLogic();
//     return _instance!;
//   }
//
//   void setJokerCard(String joker) {
//     jokerCard = joker;
//   }
//
//   List<CardModel> cardValue(List<CardModel> cards) {
//     int rule = 0;
//     int groupSize = cards.length;
//
//     // Initialize group values
//     cards[0].groupValueParams = '';
//     cards[0].groupValueResponse = '$rule';
//     cards[0].groupValue = getGroupStatus(rule);
//     cards[0].groupPoints = '${getGroupPoints(cards)}';
//     cards[0].valueGrp = rule;
//
//     cards = setValueList(cards, rule, cards[0].groupPoints, cards[0].groupValue);
//
//     if (groupSize <= 2) {
//       bool isCardsValueSame = false;
//       cards.sort((a, b) {
//         int cardValue1 = int.parse(convertCardIntoNumber(a.image));
//         int cardValue2 = int.parse(convertCardIntoNumber(b.image));
//         if (cardValue1 == cardValue2) isCardsValueSame = true;
//         return cardValue1.compareTo(cardValue2);
//       });
//
//       if (isCardsValueSame) cards = cards.reversed.toList();
//       return cards;
//     }
//
//     String jokerNum = jokerCard.length > 2 ? jokerCard.substring(2) : '';
//
//     // Initialize card variables
//     CardModel? card1, card2, card3, card4, card5, card6, card7, card8, card9, card10;
//     String card1Color = '', card2Color = '', card3Color = '', card4Color = '',
//         card5Color = '', card6Color = '', card7Color = '', card8Color = '',
//         card9Color = '', card10Color = '';
//     String card1Num = '-1', card2Num = '-1', card3Num = '-1', card4Num = '-1',
//         card5Num = '-1', card6Num = '-1', card7Num = '-1', card8Num = '-1',
//         card9Num = '-1', card10Num = '-1';
//     String card1ColorSet = '', card2ColorSet = '', card3ColorSet = '', card4ColorSet = '',
//         card5ColorSet = '', card6ColorSet = '', card7ColorSet = '', card8ColorSet = '',
//         card9ColorSet = '', card10ColorSet = '';
//     String card1NumSet = '-1', card2NumSet = '-1', card3NumSet = '-1', card4NumSet = '-1',
//         card5NumSet = '-1', card6NumSet = '-1', card7NumSet = '-1', card8NumSet = '-1',
//         card9NumSet = '-1', card10NumSet = '-1';
//
//     for (int i = 0; i < groupSize; i++) {
//       CardModel card = cards[i];
//       String cardName = card.image;
//
//       if (cardName == dummyCard) continue;
//
//       if (cardName == mainJokerCard || cardName == mainJokerCard2) {
//         cardName = jokerCard;
//       }
//
//       card.cardColor = getColorCode(cardName);
//       card.cardNumber = int.parse(convertSpecialToNumber(getCardNumber(cardName)));
//
//       if (i == 0) {
//         card1 = card;
//         card1Color = card1ColorSet = getColorCode(cardName);
//         card1Num = card1NumSet = getCardNumber(cardName);
//       } else if (i == 1) {
//         card2 = card;
//         card2Color = card2ColorSet = getColorCode(cardName);
//         card2Num = card2NumSet = getCardNumber(cardName);
//       } else if (i == 2) {
//         card3 = card;
//         card3Color = card3ColorSet = getColorCode(cardName);
//         card3Num = card3NumSet = getCardNumber(cardName);
//       } else if (i == 3) {
//         card4 = card;
//         card4Color = card4ColorSet = getColorCode(cardName);
//         card4Num = card4NumSet = getCardNumber(cardName);
//       } else if (i == 4) {
//         card5 = card;
//         card5Color = card5ColorSet = getColorCode(cardName);
//         card5Num = card5NumSet = getCardNumber(cardName);
//       } else if (i == 5) {
//         card6 = card;
//         card6Color = card6ColorSet = getColorCode(cardName);
//         card6Num = card6NumSet = getCardNumber(cardName);
//       } else if (i == 6) {
//         card7 = card;
//         card7Color = card7ColorSet = getColorCode(cardName);
//         card7Num = card7NumSet = getCardNumber(cardName);
//       } else if (i == 7) {
//         card8 = card;
//         card8Color = card8ColorSet = getColorCode(cardName);
//         card8Num = card8NumSet = getCardNumber(cardName);
//       } else if (i == 8) {
//         card9 = card;
//         card9Color = card9ColorSet = getColorCode(cardName);
//         card9Num = card9NumSet = getCardNumber(cardName);
//       } else if (i == 9) {
//         card10 = card;
//         card10Color = card10ColorSet = getColorCode(cardName);
//         card10Num = card10NumSet = getCardNumber(cardName);
//       }
//     }
//
//     if (isColorMatch(card1, card2, card3, card4, card5, card6, card7, card8, card9, card10)) {
//       if (straightCard(card1, card2, card3, card4, card5, card6, card7, card8, card9, card10)) {
//         rule = pureSequenceValue;
//         cards[0].groupValueParams = '';
//         cards[0].groupValueResponse = '$rule';
//         cards[0].groupValue = getGroupStatus(rule);
//         cards[0].groupPoints = cards[0].groupValue;
//         cards[0].valueGrp = rule;
//         cards = setValueList(cards, rule, cards[0].groupPoints, cards[0].groupValue);
//         return cards;
//       }
//     }
//
//     // Handle jokers
//     String jokerNum = jokerCard.length > 2 ? jokerCard.substring(2) : '';
//     if (card1Num == jokerNum) {
//       card1Color = 'JK';
//       card1Num = '0';
//       card1NumSet = '0';
//     }
//     if (card2Num == jokerNum) {
//       card2Color = 'JK';
//       card2Num = '0';
//       card2NumSet = '0';
//     }
//     // ... Repeat for card3 to card10 ...
//
//     // Determine set and color group
//     String set = '';
//     String colorGroup = '';
//     if (card1Color != 'JK') {
//       set = card1NumSet;
//       colorGroup = card1Color;
//     } else if (card2Color != 'JK') {
//       set = card2NumSet;
//       colorGroup = card2Color;
//     } else if (card3Color != 'JK') {
//       set = card3NumSet;
//       colorGroup = card3Color;
//     } // ... Continue for other cards ...
//
//     // Convert jokers to virtual cards
//     int jokerCount = 0;
//     if (card1Color == 'JK') {
//       card1NumSet = set;
//       card1Color = colorGroup;
//       card1ColorSet = '';
//       jokerCount++;
//     }
//     if (card2Color == 'JK') {
//       card2NumSet = set;
//       card2Color = colorGroup;
//       card2ColorSet = '';
//       jokerCount++;
//     }
//     // ... Repeat for card3 to card10 ...
//
//     // Convert card numbers
//     card1NumSet = convertSpecialToNumber(card1NumSet);
//     card2NumSet = convertSpecialToNumber(card2NumSet);
//     // ... Repeat for card3 to card10 ...
//
//     List<int> numList = [
//       int.parse(card1NumSet),
//       int.parse(card2NumSet),
//       int.parse(card3NumSet),
//       int.parse(card4NumSet),
//       int.parse(card5NumSet),
//       int.parse(card6NumSet),
//       int.parse(card7NumSet),
//       int.parse(card8NumSet),
//       int.parse(card9NumSet),
//       int.parse(card10NumSet),
//     ].where((num) => num >= 0).toList();
//
//     List<String> colorList = [
//       card1ColorSet, card2ColorSet, card3ColorSet, card4ColorSet,
//       card5ColorSet, card6ColorSet, card7ColorSet, card8ColorSet,
//       card9ColorSet, card10ColorSet,
//     ].where((color) => color.isNotEmpty).toList();
//
//     bool isColorMatch = colorList.isEmpty || colorList.every((color) => color == colorList[0]);
//
//     bool isSet = false;
//     if (!isColorMatch) {
//       isSet = numList.isNotEmpty && numList.every((num) => num == numList[0]);
//     }
//
//     if (jokerCount == numList.length) {
//       return cards;
//     }
//
//     if (isSet) {
//       rule = setValue;
//     } else {
//       bool color = colorList.isNotEmpty && colorList.every((c) => c == colorList[0]);
//       numList.sort();
//       bool sequence = checkSequence(numList, jokerCount);
//
//       if (sequence && color) {
//         int value = numList[0];
//         rule = value == 0 ? impureSequenceValue : pureSequenceValue;
//       }
//
//       if (rule == 0 && numList.contains(14)) {
//         numList = numList.map((num) => num == 14 ? 1 : num).toList();
//         numList.sort();
//         sequence = checkSequence(numList, jokerCount);
//         if (sequence && color) {
//           int value = numList[0];
//           rule = value == 0 ? impureSequenceValue : pureSequenceValue;
//         }
//       }
//     }
//
//     if (!isSet) {
//       cards.sort((a, b) {
//         int cardValue1 = int.parse(convertCardIntoNumber(a.image));
//         int cardValue2 = int.parse(convertCardIntoNumber(b.image));
//         return cardValue1.compareTo(cardValue2);
//       });
//       cards = cards.reversed.toList();
//     }
//
//     cards[0].groupValueParams = '';
//     cards[0].groupValueResponse = '$rule';
//     String cardGroupValue = getGroupStatus(rule);
//     cards[0].groupPoints = cardGroupValue == invalid ? '${getGroupPoints(cards)}' : cardGroupValue;
//     cards[0].groupValue = cardGroupValue;
//     cards[0].valueGrp = rule;
//
//     cards = setValueList(cards, rule, cards[0].groupPoints, cards[0].groupValue);
//     return cards;
//   }
//
//   bool checkSequence(List<int> arr, int jokerCount) {
//     bool sequence = true;
//     for (int j = 0; j < arr.length - 1; j++) {
//       int val = arr[j];
//       if (val == -1) break;
//       if (val != 0 && arr.length > j + 1) {
//         int cardGap = arr[j + 1] - (val + 1);
//         if (cardGap >= 0 && (cardGap == 0 || cardGap <= jokerCount)) {
//           jokerCount -= cardGap;
//         } else {
//           sequence = false;
//           break;
//         }
//       }
//     }
//     return sequence;
//   }
//
//   String getGroupStatus(int cardValue) {
//     switch (cardValue) {
//       case impureSequenceValue:
//         return impureSequence;
//       case pureSequenceValue:
//         return pureSequence;
//       case setValue:
//         return set;
//       default:
//         return invalid;
//     }
//   }
//
//   int getGroupPoints(List<CardModel> cards) {
//     int sum = 0;
//     String jokerNum = jokerCard.length > 2 ? jokerCard.substring(2) : '';
//     for (var card in cards) {
//       String currentCard = card.image;
//       if (currentCard == dummyCard) continue;
//       if (currentCard == mainJokerCard || currentCard == mainJokerCard2) {
//         currentCard = jokerCard;
//       }
//       String cardNum = getCardNumber(currentCard);
//       if (cardNum == jokerNum) {
//         cardNum = '0';
//       }
//       cardNum = convertSpecialToNumber(cardNum);
//       int cardValue = int.parse(cardNum);
//       if (cardValue > 10) cardValue = 10;
//       sum += cardValue;
//     }
//     return sum;
//   }
//
//   List<CardModel> setValueList(List<CardModel> cards, int rule, String groupPoints, String groupValue) {
//     return cards.map((card) {
//       card.groupValueParams = '';
//       card.groupValueResponse = '$rule';
//       card.groupValue = groupValue;
//       card.groupPoints = groupPoints;
//       card.valueGrp = rule;
//       return card;
//     }).toList();
//   }
//
//   String convertCardIntoNumber(String currentCard) {
//     String jokerNum = jokerCard.length > 2 ? jokerCard.substring(2) : '';
//     if (currentCard == mainJokerCard || currentCard == mainJokerCard2) {
//       currentCard = jokerCard;
//     }
//     if (currentCard == dummyCard) return '0';
//     String cardNum = getCardNumber(currentCard);
//     if (cardNum == jokerNum) cardNum = '0';
//     return convertSpecialToNumber(cardNum);
//   }
//
//   String getColorCode(String cardName) {
//     return cardName.substring(0, 2);
//   }
//
//   String getCardNumber(String cardName) {
//     return cardName.substring(2);
//   }
//
//   String convertSpecialToNumber(String cardNum) {
//     switch (cardNum) {
//       case 'J':
//         return '11';
//       case 'Q':
//         return '12';
//       case 'K':
//         return '13';
//       case 'A':
//         return '14';
//       default:
//         return cardNum;
//     }
//   }
//
//   bool isColorMatch(CardModel? card1, CardModel? card2, CardModel? card3, CardModel? card4,
//       CardModel? card5, CardModel? card6, CardModel? card7, CardModel? card8,
//       CardModel? card9, CardModel? card10) {
//     List<String?> colors = [
//       card1?.cardColor, card2?.cardColor, card3?.cardColor, card4?.cardColor,
//       card5?.cardColor, card6?.cardColor, card7?.cardColor, card8?.cardColor,
//       card9?.cardColor, card10?.cardColor,
//     ].where((color) => color != null).toList();
//     return colors.isEmpty || colors.every((color) => color == colors[0]);
//   }
//
//   bool straightCard(CardModel? card1, CardModel? card2, CardModel? card3, CardModel? card4,
//       CardModel? card5, CardModel? card6, CardModel? card7, CardModel? card8,
//       CardModel? card9, CardModel? card10) {
//     List<int> cardNumbers = [
//       card1?.cardNumber ?? -1, card2?.cardNumber ?? -1, card3?.cardNumber ?? -1,
//       card4?.cardNumber ?? -1, card5?.cardNumber ?? -1, card6?.cardNumber ?? -1,
//       card7?.cardNumber ?? -1, card8?.cardNumber ?? -1, card9?.cardNumber ?? -1,
//       card10?.cardNumber ?? -1,
//     ].where((num) => num != -1).toList();
//
//     cardNumbers.sort();
//     bool isStraight = checkSequence(cardNumbers, 0);
//
//     if (!isStraight && cardNumbers.contains(14)) {
//       cardNumbers = cardNumbers.map((num) => num == 14 ? 1 : num).toList();
//       cardNumbers.sort();
//       isStraight = checkSequence(cardNumbers, 0);
//     }
//
//     return isStraight;
//   }
// }