

import 'dart:math' as math;
import 'package:flutter/material.dart' hide Card;
import 'package:provider/provider.dart';

import '../../Model/Cards_Model.dart';
import 'package:arka_infotech/provider/pointGameProvider.dart';
import 'CardWidget.dart';

class PlayerHandWidget extends StatefulWidget {
  final Function(Card card, int groupIndex) onCardTap;
  final Function(Card card, int sourceGroup, int targetGroup, int insertIndex) onCardDropped;
  final double cardWidth;
  final double cardHeight;

  const PlayerHandWidget({
    Key? key,
    required this.onCardTap,
    required this.onCardDropped,
    this.cardWidth = 50,
    this.cardHeight = 80,
  }) : super(key: key);

  @override
  State<PlayerHandWidget> createState() => _PlayerHandWidgetState();
}

class _PlayerHandWidgetState extends State<PlayerHandWidget> {
  late final ValueNotifier<Card?> _currentlyDraggedCardNotifier;
  late final ValueNotifier<int?> _originalDraggedCardIndexNotifier;
  late double _step;

  @override
  void initState() {
    super.initState();
    _currentlyDraggedCardNotifier = ValueNotifier(null);
    _originalDraggedCardIndexNotifier = ValueNotifier(null);
    _step = widget.cardWidth * 0.6;
  }

  @override
  void dispose() {
    _currentlyDraggedCardNotifier.dispose();
    _originalDraggedCardIndexNotifier.dispose();
    super.dispose();
  }

  double _calculateCardOffset(int cardIndex, int groupIndex, int totalGroups) {
    // Simple offset: group spacing + card spacing
    final groupSpacing = 10.0;
    double groupLeft = groupIndex * (widget.cardWidth * 0.6 + groupSpacing);
    double cardLeft = cardIndex * _step;
    return groupLeft + cardLeft;
  }

  // Calculate global card index across all groups
  int _getGlobalCardIndex(int groupIndex, int cardIndex) {
    final pointGameProvider = Provider.of<PointGameProvider>(context, listen: false);
    int globalIndex = 0;
    for (int i = 0; i < groupIndex; i++) {
      globalIndex += pointGameProvider.cardGroups[i].length;
    }
    globalIndex += cardIndex;
    return globalIndex;
  }

  // Get reveal status using global card index
  bool _getCardRevealStatus(int groupIndex, int cardIndex) {
    final globalIndex = _getGlobalCardIndex(groupIndex, cardIndex);
    final pointGameProvider = Provider.of<PointGameProvider>(context, listen: false);
    final reveal = pointGameProvider.mainHandRevealStatusNotifier.length > globalIndex &&
           pointGameProvider.mainHandRevealStatusNotifier[globalIndex];
    
    // Debug print to track reveal status
    debugPrint('Card reveal - Group: $groupIndex, Card: $cardIndex, Global: $globalIndex, Reveal: $reveal');
    
    return reveal;
  }

  int _calculateInsertionIndex(Offset localOffset, int cardsInGroup) {
    double x = localOffset.dx;
    final dragCenterX = x + (widget.cardWidth / 2);
    int bestIndex = 0;
    double minDistance = double.infinity;
    for (int i = 0; i <= cardsInGroup; i++) {
      final slotX = i * _step;
      final distance = (dragCenterX - slotX).abs();
      if (distance < minDistance) {
        minDistance = distance;
        bestIndex = i;
      }
    }
    return bestIndex;
  }



  @override
  Widget build(BuildContext context) {
    return Consumer<PointGameProvider>(
      builder: (context, pointGameProvider, _) {
        final cardGroups = pointGameProvider.cardGroups;
        final revealStatus = pointGameProvider.mainHandRevealStatusNotifier;
        final selectedCards = pointGameProvider.selectedCards;
        
        debugPrint('[PLAYER_HAND] Building widget with ${cardGroups.length} groups');
        for (int i = 0; i < cardGroups.length; i++) {
          debugPrint('[PLAYER_HAND] Group $i has ${cardGroups[i].length} cards');
          for (int j = 0; j < cardGroups[i].length; j++) {
            final card = cardGroups[i][j];
            debugPrint('[PLAYER_HAND] Group $i, Card $j: ${card.suit} ${card.rank}');
          }
        }
        
        return SizedBox(
          height: widget.cardHeight * 1.5,
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: List.generate(cardGroups.length, (groupIndex) {
                final group = cardGroups[groupIndex];
                return Padding(
                  padding: const EdgeInsets.only(right: 10),
                  child: DragTarget<(Card, int)>(
                    onWillAcceptWithDetails: (_) => true,
                    onAccept: (data) {
                      final insertIndex = group.length;
                      widget.onCardDropped(
                        data.$1,
                        data.$2,
                        groupIndex,
                        insertIndex,
                      );
                    },
                    builder: (context, candidateData, rejectedData) {
                      return SizedBox(
                        width: math.min(
                            _step * group.length + widget.cardWidth,
                            MediaQuery.of(context).size.width * 0.8,
                        ),
                        height: widget.cardHeight * 1.5,
                        child: Stack(
                          clipBehavior: Clip.none,
                          children: List.generate(group.length, (cardIndex) {
                            final card = group[cardIndex];
                            return Positioned(
                              left: _calculateCardOffset(cardIndex, groupIndex, cardGroups.length),
                              top: 8,
                              child: Draggable<(Card, int)>(
                                data: (card, groupIndex),
                                feedback: Transform.scale(
                                  scale: 1.1,
                                  child: Material(
                                    color: Colors.transparent,
                                    elevation: 8,
                                    borderRadius: BorderRadius.circular(6),
                                    child: CardWidget(
                                      card: card,
                                      isFaceUp: revealStatus.length > cardIndex &&
                                          revealStatus[cardIndex],
                                      width: widget.cardWidth,
                                      height: widget.cardHeight,
                                    ),
                                  ),
                                ),
                                childWhenDragging: const SizedBox.shrink(),
                                onDragStarted: () {
                                  _currentlyDraggedCardNotifier.value = card;
                                  _originalDraggedCardIndexNotifier.value = cardIndex;
                                },
                                onDragCompleted: () {
                                  _currentlyDraggedCardNotifier.value = null;
                                  _originalDraggedCardIndexNotifier.value = null;
                                },
                                onDraggableCanceled: (_, __) {
                                  _currentlyDraggedCardNotifier.value = null;
                                  _originalDraggedCardIndexNotifier.value = null;
                                },
                                child: GestureDetector(
                                  onTap: () => widget.onCardTap(card, groupIndex),
                                  child: AnimatedContainer(
                                    duration: const Duration(milliseconds: 300),
                                    curve: Curves.easeInOutCubic,
                                    transform: Matrix4.translationValues(
                                      0,
                                      selectedCards.contains(card) ? -14.0 : 0,
                                      0,
                                    )..scale(
                                      selectedCards.contains(card) ? 1.05 : 1.0,
                                    ),
                                    decoration: BoxDecoration(
                                      border: selectedCards.contains(card)
                                          ? Border.all(color: Colors.amber, width: 2)
                                          : null,
                                      borderRadius: BorderRadius.circular(6),
                                      boxShadow: selectedCards.contains(card)
                                          ? [
                                        BoxShadow(
                                          color: Colors.amber.withOpacity(0.4),
                                          blurRadius: 10,
                                          offset: const Offset(0, 3),
                                        )
                                      ]
                                          : [],
                                    ),
                                                                          child: AnimatedSwitcher(
                                        duration: const Duration(milliseconds: 200),
                                        transitionBuilder: (child, animation) =>
                                            RotationYTransition(turns: animation, child: child),
                                        child: CardWidget(
                                          key: ValueKey('$groupIndex-$cardIndex-${_getGlobalCardIndex(groupIndex, cardIndex)}'),
                                          card: card,
                                          isFaceUp: _getCardRevealStatus(groupIndex, cardIndex),
                                          width: widget.cardWidth,
                                          height: widget.cardHeight,
                                        ),
                                      ),
                                  ),
                                ),
                              ),
                            );
                          }),
                        ),
                      );
                    },
                  ),
                );
              }),
            ),
          ),
        );
      },
    );
  }
}

// RotationYTransition widget (horizontal Y-rotation for flip animation)
class RotationYTransition extends AnimatedWidget {
  final Widget child;
  final Animation<double> turns;

  RotationYTransition({Key? key, required this.turns, required this.child}) : super(key: key, listenable: turns);

  @override
  Widget build(BuildContext context) {
    final value = turns.value;
    final angle = math.pi * value; // 0 to π radians

    return Transform(
      alignment: Alignment.center,
      transform: Matrix4.identity()
        ..setEntry(3, 2, 0.001)
        ..rotateY(angle),
      // Optional: flip widget halfway
      child: value <= 0.5 ? child : Transform(
        alignment: Alignment.center,
        transform: Matrix4.rotationY(math.pi),
        child: child,
      ),
    );
  }
}
