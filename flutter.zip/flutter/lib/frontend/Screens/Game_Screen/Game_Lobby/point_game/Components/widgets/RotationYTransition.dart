import 'package:flutter/material.dart';

class RotationYTransition extends AnimatedWidget {
  final Widget child;
  final Animation<double> turns;

  RotationYTransition({Key? key, required this.turns, required this.child})
    : super(key: key, listenable: turns);

  @override
  Widget build(BuildContext context) {
    final double rotationValue = turns.value;
    final double radians =
        rotationValue * 3.1415926535897932; // turns from 0 to 1 → 0 to π rad

    // Map 0 -> 0, 0.5 -> π/2 (flip halfway, show edge), 1 -> π (complete flip)
    // For better effect, you can flip the card content at half-way point

    bool isFirstHalf = rotationValue <= 0.5;
    return Transform(
      transform:
          Matrix4.identity()
            ..setEntry(3, 2, 0.001) // perspective
            ..rotateY(radians),
      alignment: Alignment.center,
      child:
          isFirstHalf
              ? child
              : Transform(
                alignment: Alignment.center,
                transform: Matrix4.rotationY(
                  3.1415926535897932,
                ), // flip child to back
                child: child,
              ),
    );
  }
}

