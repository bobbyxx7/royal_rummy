import 'dart:math';
import 'Cards_Model.dart';

enum TurnPhase { drawing, discarding }

class GameModel {
  List<Card> deck;
  List<Card> discardPile;
  List<List<Card>> playersHands;
  int currentTurn;
  TurnPhase currentTurnPhase;
  String? wildCardRank;
  // List<String>? suits;suits

  GameModel({required int numberOfPlayers})
      : deck = _createDeck(numberOfPlayers),
        discardPile = [],
        playersHands = List.generate(numberOfPlayers, (_) => []),
        currentTurn = 0,
        currentTurnPhase = TurnPhase.drawing {
    deck.shuffle(Random());
    _dealCards(numberOfPlayers);
    if (deck.isNotEmpty) {
      discardPile.add(deck.removeLast());
    }
  }

  static List<Card> _createDeck(int numberOfPlayers) {
    List<String> suits = ['hearts', 'diamonds', 'clubs', 'spades'];
    List<String> ranks = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13'];
    List<Card> deck = [];
    int deckCount = numberOfPlayers <= 2 ? 1 : 2;
    // Add normal cards with point values
    for (int i = 0; i < deckCount; i++) {
      deck.addAll(suits.expand((suit) => ranks.map((rank) {
        int value = int.tryParse(rank) ?? 10;
        return Card(suit: suit, rank: rank, pointValue: value);
      })).toList());
      deck.add(Card(suit: 'joker', rank: 'joker', isJoker: true, pointValue: 0));
    }
    return deck;
  }

  void _selectWildCard() {
    List<String> ranks = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13'];
    wildCardRank = ranks[Random().nextInt(ranks.length)];
    deck = deck.map((card) {
      if (card.rank == wildCardRank && !card.isJoker) {
        return Card(suit: card.suit, rank: '${card.rank}j', isWild: true, pointValue: 0);
      }
      return card;
    }).toList();
  }

  void _dealCards(int numberOfPlayers) {
    const int cardsPerPlayer = 13;
    for (int i = 0; i < numberOfPlayers; i++) {
      if (deck.length >= cardsPerPlayer) {
        playersHands[i].addAll(deck.sublist(0, cardsPerPlayer));
        deck = deck.sublist(cardsPerPlayer);
      } else {
        playersHands[i].addAll(deck);
        deck.clear();
      }
    }
  }

  void playerDrawFromDeck(int playerIndex) {
    if (currentTurn == playerIndex && currentTurnPhase == TurnPhase.drawing && deck.isNotEmpty) {
      Card drawnCard = deck.removeLast();
      playersHands[playerIndex].add(drawnCard);
      currentTurnPhase = TurnPhase.discarding;
    }
  }

  void playerDrawFromDiscard(int playerIndex) {
    if (currentTurn == playerIndex && currentTurnPhase == TurnPhase.drawing && discardPile.isNotEmpty) {
      Card drawnCard = discardPile.removeLast();
      playersHands[playerIndex].add(drawnCard);
      currentTurnPhase = TurnPhase.discarding;
    }
  }

  void playerDiscardCard(int playerIndex, Card card) {
    if (currentTurn == playerIndex && currentTurnPhase == TurnPhase.discarding) {
      if (playersHands[playerIndex].contains(card)) {
        playersHands[playerIndex].remove(card);
        discardPile.add(card);
        currentTurn = (currentTurn + 1) % playersHands.length;
        currentTurnPhase = TurnPhase.drawing;
      }
    }
  }

  void autoPlay(int playerIndex) {
    if (currentTurn == playerIndex) {
      if (currentTurnPhase == TurnPhase.drawing) {
        if (deck.isNotEmpty) {
          playerDrawFromDeck(playerIndex);
        } else if (discardPile.isNotEmpty) {
          playerDrawFromDiscard(playerIndex);
        } else {
          // No cards to draw, skip to next turn
          currentTurn = (currentTurn + 1) % playersHands.length;
          currentTurnPhase = TurnPhase.drawing;
          return;
        }
      }
      if (currentTurnPhase == TurnPhase.discarding && playersHands[playerIndex].isNotEmpty) {
        // Select a random card to discard
        final randomIndex = Random().nextInt(playersHands[playerIndex].length);
        playerDiscardCard(playerIndex, playersHands[playerIndex][randomIndex]);
      } else if (playersHands[playerIndex].isEmpty) {
        // If hand is empty, skip to next turn
        currentTurn = (currentTurn + 1) % playersHands.length;
        currentTurnPhase = TurnPhase.drawing;
      }
    }
  }

  int calculateHandPoints(int playerIndex) {
    return playersHands[playerIndex].fold(0, (sum, card) => sum + card.pointValue);
  }

  void sortPlayerHand(int playerIndex) {
    playersHands[playerIndex].sort((a, b) {
      // Prioritize jokers and wild cards
      if (a.isJoker) return -1;
      if (b.isJoker) return 1;
      if (a.isWild) return -1;
      if (b.isWild) return 1;

      // Compare suits
      const suitOrder = {'spades': 0, 'hearts': 1, 'diamonds': 2, 'clubs': 3};
      final suitComparison = suitOrder[a.suit]!.compareTo(suitOrder[b.suit]!);
      if (suitComparison != 0) return suitComparison;

      // Compare ranks, handling 'j' suffix for wild cards
      final rankA = int.tryParse(a.rank.replaceAll('j', '')) ?? 0;
      final rankB = int.tryParse(b.rank.replaceAll('j', '')) ?? 0;
      return rankA.compareTo(rankB);
    });
  }
}