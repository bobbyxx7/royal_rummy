import 'package:flutter/material.dart' hide Card;
import '../Model/Cards_Model.dart';
import '../Model/Card_Group_Model.dart';
import 'package:arka_infotech/provider/pointGameProvider.dart';

/// Specialized provider that focuses specifically on card hand management and wild card logic...


// Manages player hand and wild card state
class GameProvider extends ChangeNotifier {
  late PointGameProvider _pointGameProvider;
  String? _wildCardRank;

  // Constructor
  GameProvider(this._pointGameProvider);

  // Getters - delegate to PointGameProvider
  List<Card> get playerHand => _pointGameProvider.playersHands.isNotEmpty ? _pointGameProvider.playersHands[0] : [];
  List<List<Card>> get cardGroups => _pointGameProvider.cardGroups;
  Set<Card> get selectedCards => _pointGameProvider.selectedCards;
  String? get wildCardRank => _wildCardRank;
  bool get canDeclare => _pointGameProvider.canDeclare;
  GamePhase get gamePhase => _pointGameProvider.gamePhase;
  String? get currentChaalUserId => _pointGameProvider.currentChaalUserId;

  // Card Groups Management - delegate to PointGameProvider
  void updateCardGroups(List<List<Card>> groups) {
    _pointGameProvider.updateCardGroups(groups);
  }

  void addCardToGroup(int groupIndex, Card card) {
    final groups = List<List<Card>>.from(_pointGameProvider.cardGroups);
    if (groupIndex >= 0 && groupIndex < groups.length) {
      groups[groupIndex].add(card);
      _pointGameProvider.updateCardGroups(groups);
    }
  }

  void removeCardFromGroup(int groupIndex, int cardIndex) {
    final groups = List<List<Card>>.from(_pointGameProvider.cardGroups);
    if (groupIndex >= 0 && groupIndex < groups.length &&
        cardIndex >= 0 && cardIndex < groups[groupIndex].length) {
      groups[groupIndex].removeAt(cardIndex);
      // Remove empty groups
      groups.removeWhere((group) => group.isEmpty);
      _pointGameProvider.updateCardGroups(groups);
    }
  }

  void createNewGroup(List<Card> cards) {
    final groups = List<List<Card>>.from(_pointGameProvider.cardGroups);
    groups.add(cards);
    _pointGameProvider.updateCardGroups(groups);
  }

  // Selection Management - delegate to PointGameProvider
  void toggleCardSelection(Card card) {
    _pointGameProvider.toggleSelectedCard(card);
  }

  void clearCardSelection() {
    _pointGameProvider.clearSelectedCards();
  }

  // Game State Management - delegate to PointGameProvider
  void updateGamePhase(GamePhase phase) {
    _pointGameProvider.setGamePhase(phase);
  }

  void updateCurrentChaalUserId(String? userId) {
    _pointGameProvider.setCurrentChaalUserId(userId);
  }

  void updateCanDeclare(bool canDeclare) {
    _pointGameProvider.setCanDeclare(canDeclare);
  }

  // Existing methods
  void updateWildCard(String? wildCard) {
    _wildCardRank = wildCard;
    notifyListeners();
  }

  void updatePlayerHand(List<Card> hand) {
    _pointGameProvider.updatePlayerHand(0, hand); // Update player 0's hand
  }

  void mapHandWithWild(List<String> cardCodes) {
    if (_wildCardRank == null) {
      updatePlayerHand(cardCodes.map((c) => Card.fromServer(c)).toList());
      return;
    }
    String wildRank = _wildCardRank!.substring(2).replaceAll(RegExp('^0+'), '');
    final mapped = cardCodes.map((cardStr) {
      final cleanCardCode = cardStr.replaceAll('_', '');
      final suitCode = cleanCardCode.substring(0, 2).toUpperCase();
      final rankCode = cleanCardCode.substring(2);
      final isPrintedJoker = (suitCode == 'JK' || cleanCardCode.contains('JOKER') || cleanCardCode.endsWith('J'));
      final suitMap = {
        'RP': 'hearts',
        'BP': 'spades',
        'BL': 'clubs',
        'RS': 'diamonds',
      };
      String suit = suitMap[suitCode] ?? suitCode.toLowerCase();
      String normalizedRankCode = rankCode.replaceAll(RegExp('^0+'), '');
      String rank = rankCode;
      int pointValue = 0;
      if (rankCode == 'A') {
        rank = '1';
        pointValue = 10;
      } else if (rankCode == 'J') {
        rank = '11';
        pointValue = 10;
      } else if (rankCode == 'Q') {
        rank = '12';
        pointValue = 10;
      } else if (rankCode == 'K') {
        rank = '13';
        pointValue = 10;
      } else {
        pointValue = int.tryParse(rankCode) ?? 0;
        rank = rankCode;
      }
      bool isWild = false;
      if (normalizedRankCode == wildRank && !isPrintedJoker) {
        isWild = true;
        rank = '${normalizedRankCode}j';
        pointValue = 0;
        debugPrint('WILDCARD IN HAND: suit=$suit, originalRank=$rankCode, mappedRank=$rank');
      }
      return Card(
        suit: suit,
        rank: rank,
        isWild: isWild,
        isJoker: isPrintedJoker,
        pointValue: pointValue,
      );
    }).toList();
    updatePlayerHand(mapped);
  }
}