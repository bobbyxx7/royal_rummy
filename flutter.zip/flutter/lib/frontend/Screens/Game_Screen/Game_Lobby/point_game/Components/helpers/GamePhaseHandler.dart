
import 'package:flutter/material.dart' hide Card;
import 'package:provider/provider.dart';

import 'package:arka_infotech/provider/pointGameProvider.dart';

class GamePhaseHandler {
  static void handlePhaseTransition(GamePhase newPhase, BuildContext context) {
    final pointGameProvider = Provider.of<PointGameProvider>(context, listen: false);
    final currentPhase = pointGameProvider.gamePhase;
    
    debugPrint('[PHASE HANDLER] Transitioning from $currentPhase to $newPhase');
    
    // Validate transition
    if (!_isValidTransition(currentPhase, newPhase)) {
      debugPrint('[PHASE HANDLER] Invalid transition from $currentPhase to $newPhase');
      return;
    }
    
    // Handle phase-specific logic
    switch (newPhase) {
      case GamePhase.waiting:
        _handleWaitingPhase(context, pointGameProvider);
        break;
        
      case GamePhase.loading:
        _handleLoadingPhase(context, pointGameProvider);
        break;
        
      case GamePhase.dealing:
        _handleDealingPhase(context, pointGameProvider);
        break;
        
      case GamePhase.playing:
        _handlePlayingPhase(context, pointGameProvider);
        break;
        
      case GamePhase.result:
        _handleResultPhase(context, pointGameProvider);
        break;
    }
    
    // Update provider state
    pointGameProvider.setGamePhase(newPhase);
  }
  
  static bool _isValidTransition(GamePhase from, GamePhase to) {
    switch (from) {
      case GamePhase.waiting:
        return to == GamePhase.loading;
      case GamePhase.loading:
        return to == GamePhase.dealing;
      case GamePhase.dealing:
        return to == GamePhase.playing;
      case GamePhase.playing:
        return to == GamePhase.result;
      case GamePhase.result:
        return to == GamePhase.waiting; // Allow restart
    }
  }
  
  static void _handleWaitingPhase(BuildContext context, PointGameProvider provider) {
    debugPrint('[PHASE HANDLER] Entering waiting phase');
    // Reset waiting state
    provider.setHasTransitionedFromWaiting(false);
    provider.setIsCheckingPlayersJoined(false);
    provider.setWaitingStartTime(DateTime.now());
    // Additional waiting phase setup can go here
  }
  
  static void _handleLoadingPhase(BuildContext context, PointGameProvider provider) {
    debugPrint('[PHASE HANDLER] Entering loading phase');
    // Start loading assets, precaching, etc.
    provider.setShowLoading(true);
    provider.setLoadingProgress(0.0);
    
    // The actual loading process should be triggered from the lobby
    // We'll use a callback approach or handle it in the provider
    // For now, we'll let the lobby handle the startLoading call
    // when it transitions to the loading phase
  }
  
  static void _handleDealingPhase(BuildContext context, PointGameProvider provider) {
    debugPrint('[PHASE HANDLER] Entering dealing phase');
    // Setup dealing animation, card distribution, etc.
    provider.setIsDealing(true);
    provider.setDealingCurrentCardIndexNotifier(0);
    provider.setMyCardReceivedNotifier(false);
    
    // The my-card event will be emitted:
    // 1. After receiving start-game response (in _handleStartGameResponse)
    // 2. At the end of dealing animation (in _startDealingAnimation)
  }
  
  static void _handlePlayingPhase(BuildContext context, PointGameProvider provider) {
    debugPrint('[PHASE HANDLER] Entering playing phase');
    // Initialize game for playing, start timers, etc.
    provider.setShowLoading(false);
    provider.setIsDealing(false);
    provider.setMyCardReceivedNotifier(true);
  }
  
  static void _handleResultPhase(BuildContext context, PointGameProvider provider) {
    debugPrint('[PHASE HANDLER] Entering result phase');
    // Handle game results, show dialogs, etc.
  }
}

// Legacy function for backward compatibility
void gamePhaseHandler(GamePhase phase, BuildContext context) {
  GamePhaseHandler.handlePhaseTransition(phase, context);
}
