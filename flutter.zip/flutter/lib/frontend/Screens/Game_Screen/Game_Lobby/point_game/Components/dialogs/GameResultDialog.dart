import 'package:flutter/material.dart' hide Card;
import '../../Model/Card_Group_Model.dart';
import '../../Model/Cards_Model.dart';

class GameResultDialog extends StatefulWidget {
  final List<CardGroupModel> groups;
  final String gameId;
  final int gameStartTime;

  const GameResultDialog({
    super.key,
    required this.groups,
    required this.gameId,
    required this.gameStartTime,
  });

  @override
  State<GameResultDialog> createState() => _GameResultDialogState();
}

class _GameResultDialogState extends State<GameResultDialog> {
  late int _seconds;

  @override
  void initState() {
    super.initState();
    _seconds = widget.gameStartTime;
    _startTimer();
  }

  void _startTimer() {
    Future.doWhile(() async {
      if (_seconds <= 0) {
        if (mounted) Navigator.pop(context);
        return false;
      }
      await Future.delayed(const Duration(seconds: 1));
      if (mounted) {
        setState(() => _seconds--);
      }
      return true;
    });
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    final cardWidth = screenWidth * 0.06;
    final cardHeight = cardWidth * 1.6;

    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Game Result - ID: ${widget.gameId}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            if (widget.groups.isNotEmpty)
              Image.asset(
                'assets/cards/${widget.groups[0].cards[0].isWild ? "${widget.groups[0].cards[0].suit}/${widget.groups[0].cards[0].rank}" : "joker"}.png',
                width: cardWidth,
                height: cardHeight,
              ),
            const SizedBox(height: 10),
            ListView.builder(
              shrinkWrap: true,
              itemCount: widget.groups.length,
              itemBuilder: (context, index) {
                final group = widget.groups[index];
                return Row(
                  children: [
                    Text('Group ${index + 1}: ${group.groupValue} (${group.groupPoints} points)'),
                    const SizedBox(width: 10),
                    ...group.cards.map((card) => Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: Image.asset(
                        'assets/cards/${card.isJoker ? "joker" : "${card.suit}/${card.rank}"}.png',
                        width: cardWidth,
                        height: cardHeight,
                      ),
                    )),
                  ],
                );
              },
            ),
            const SizedBox(height: 10),
            Text('Next game in $_seconds seconds', style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 10),
            IconButton(
              icon: const Icon(Icons.close),
              onPressed: () => Navigator.pop(context),
            ),
          ],
        ),
      ),
    );
  }
}