class Card {
  final String suit;
  final String rank;
  final bool isWild;
  final bool isJoker;
  final int pointValue;

  Card({
    required this.suit,
    required this.rank,
    this.isWild = false,
    this.isJoker = false,
    this.pointValue = 0,
  });

  factory Card.fromJson(Map<String, dynamic> json) {
    return Card(
      suit: json['suit'] ?? '',
      rank: json['rank'] ?? '',
      isWild: json['isWild'] ?? false,
      isJoker: json['isJoker'] ?? false,
      pointValue: json['pointValue'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'suit': suit,
      'rank': rank,
      'isWild': isWild,
      'isJoker': isJoker,
      'pointValue': pointValue,
    };
  }

  static Card fromServer(String cardStr) {
    // Handle joker (backend may send 'JK', 'JOKER', or similar)
    final upper = cardStr.toUpperCase();
    if (upper == 'JK' || upper.contains('JOKER')) {
      return Card(suit: 'joker', rank: 'JK', isJoker: true, pointValue: 0);
    }

    // Detect wild card (ends with '_')
    bool isWild = cardStr.endsWith('_');
    // Remove trailing underscores and whitespace for parsing
    final cleaned = cardStr.replaceAll('_', '').trim();
    if (cleaned.length < 3) {
      // fallback
      return Card(suit: cleaned, rank: '', pointValue: 0);
    }

    // Map backend suit codes to asset folder names
    final suitMap = {
      'RP': 'hearts', // Red Poker/Heart
      'BP': 'spades', // Black Poker/Spade
      'BL': 'clubs',  // Black/Blue Club
      'RS': 'diamonds', // Red Diamond
    };
    String suitCode = cleaned.substring(0, 2).toUpperCase();
    String suit = suitMap[suitCode] ?? suitCode.toLowerCase();
    if (!['hearts', 'spades', 'clubs', 'diamonds', 'joker'].contains(suit)) {
      // Fallback for unmapped suits
      suit = 'hearts';
    }
    String rankRaw = cleaned.substring(2);
    String rank = rankRaw;
    int pointValue = 0;
    bool isJoker = false;

    // Map rank for asset and point value
    if (rankRaw == 'A') {
      rank = '1';
      pointValue = 10;
    } else if (rankRaw == 'J') {
      rank = '11';
      pointValue = 10;
    } else if (rankRaw == 'Q') {
      rank = '12';
      pointValue = 10;
    } else if (rankRaw == 'K') {
      rank = '13';
      pointValue = 10;
    } else {
      // Numeric rank
      pointValue = int.tryParse(rankRaw) ?? 0;
      rank = rankRaw;
    }

    // For wild cards, asset uses 'rankj' (e.g., 8j.png)
    if (isWild) {
      rank = '${rank}j';
      pointValue = 0; // Wild cards have 0 point value
    }

    final card = Card(
      suit: suit,
      rank: rank,
      isWild: isWild,
      isJoker: isJoker,
      pointValue: pointValue,
    );
    return card;
  }

  @override
  String toString() {
    if (isJoker) return 'Joker';
    if (isWild) return 'Wild $rank ($suit)';
    return '$rank of $suit';
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Card &&
          runtimeType == other.runtimeType &&
          suit == other.suit &&
          rank == other.rank &&
          isWild == other.isWild &&
          isJoker == other.isJoker &&
          pointValue == other.pointValue;

  @override
  int get hashCode => Object.hash(suit, rank, isWild, isJoker, pointValue);
}