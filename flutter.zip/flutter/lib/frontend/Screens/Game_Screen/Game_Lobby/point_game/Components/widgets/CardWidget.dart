

import 'package:flutter/material.dart' hide Card;

import '../../Model/Cards_Model.dart';

class CardWidget extends StatelessWidget {
  final Card? card;
  final bool isFaceUp;
  final double width;
  final double height;

  const CardWidget({
    super.key,
    this.card,
    this.isFaceUp = true,
    required this.width,
    required this.height,
  });

  @override
  Widget build(BuildContext context) {
    String imagePath;
    if (!isFaceUp || card == null) {
      imagePath = 'assets/cards/back_2.png';
    } else if (card!.isJoker) {
      imagePath = 'assets/cards/joker/joker.png';
    } else {
      String rank =
          card!.isWild
              ? card!.rank.replaceAll('_', '')
              : card!.rank.replaceAll('_', '');
      imagePath = 'assets/cards/${card!.suit}/$rank.png';
    }
    // print('Loading image: $imagePath'); // Commented out to reduce log spam
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(6),
        image: DecorationImage(
          alignment: Alignment.center,
          image: AssetImage(imagePath),
          fit: BoxFit.cover,
        ),
      ),
    );
  }
}