import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:arka_infotech/provider/pointGameProvider.dart';
import '../../Model/Game_Model.dart';
import 'PointGameLoadingRoom.dart';
import 'CardDealingAnimation.dart';
import 'PointGameResultDialog.dart';
import 'PlayerProfilesOverlay.dart';
import 'PointWaitingRoom.dart';


/// Unified overlay system for all game phases
class GamePhaseOverlay extends StatelessWidget {
  final GameModel gameModel;
  final double cardWidth;
  final double cardHeight;
  final List<Offset> playerPositions;
  final Function() onDealingComplete;
  final Function(String? userId) isTimerActiveFor;
  final List<Offset> cachedPositions;

  const GamePhaseOverlay({
    Key? key,
    required this.gameModel,
    required this.cardWidth,
    required this.cardHeight,
    required this.playerPositions,
    required this.onDealingComplete,
    required this.isTimerActiveFor,
    required this.cachedPositions,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<PointGameProvider>(
      builder: (context, provider, child) {
        final phase = provider.gamePhase;
        
        switch (phase) {
          case GamePhase.waiting:
            return _buildWaitingPhase(provider);
          case GamePhase.loading:
            return _buildLoadingPhase(provider);
          case GamePhase.dealing:
            return _buildDealingPhase(provider);
          case GamePhase.playing:
            return _buildPlayingPhase(provider);
          case GamePhase.result:
            return _buildResultPhase(provider);
        }
      },
    );
  }

  /// Waiting Phase Overlay
  Widget _buildWaitingPhase(PointGameProvider provider) {
    return SimpleWaitingRoom(
      getPlayerOffset: (seat) => _getPlayerOffset(seat),
      buildPlayerProfile: (seat) {
        final playersBySeat = provider.playersBySeat;
        final hasPlayer = playersBySeat[seat] != null &&
            playersBySeat[seat]!['user_id'] != null &&
            playersBySeat[seat]!['user_id'].toString() != '0';
        
        if (hasPlayer) {
          final player = playersBySeat[seat];
          return _buildPlayerProfile(
            name: player?['name'] ?? 'Player',
            isWaiting: false
          );
        } else {
          return buildSimplePlaceholderProfile(seat);
        }
      },
    );
  }



  /// Loading Phase Overlay
  Widget _buildLoadingPhase(PointGameProvider provider) {
    final percent = provider.loadingProgress.clamp(0.0, 100.0).toStringAsFixed(0);
    return buildLoadingRoom(percent);
  }

  /// Dealing Phase Overlay
  Widget _buildDealingPhase(PointGameProvider provider) {
    return Builder(
      builder: (context) {
        return Stack(
          children: [
            // Player profiles during dealing
            PlayerProfilesOverlay(
              cachedPositions: cachedPositions,
              showTimers: false, // No timers during dealing
              isTimerActiveFor: (userId) => isTimerActiveFor(userId) ?? false,
            ),
            // Card dealing animation
            CardDealingAnimation(
              playersHands: gameModel.playersHands,
              cardWidth: cardWidth,
              cardHeight: cardHeight,
              playerPositions: playerPositions,
              wildCardRank: gameModel.wildCardRank,
              wildCardTargetPosition: Offset(
                MediaQuery.of(context).size.width / 2,
                MediaQuery.of(context).size.height * 0.45,
              ),
              onDealingComplete: onDealingComplete,
            ),
          ],
        );
      },
    );
  }

  /// Playing Phase Overlay
  Widget _buildPlayingPhase(PointGameProvider provider) {
    return PlayerProfilesOverlay(
      cachedPositions: cachedPositions,
      showTimers: true, // Show timers during playing phase
      isTimerActiveFor: (userId) => isTimerActiveFor(userId) ?? false,
    );
  }

  /// Result Phase Overlay
  Widget _buildResultPhase(PointGameProvider provider) {
    return PointGameResultDialog(
      groups: [], // TODO: Add resultGroups to PointGameProvider if needed
      gameId: provider.gameId?.toString() ?? '',
      gameStartTime: 0, // TODO: Add gameStartTime to PointGameProvider if needed
    );
  }

  /// Helper method to get player offset
  Offset _getPlayerOffset(int seat) {
    // This should match your existing player position logic
    final positions = {
      2: [const Offset(390, 80)],
      6: [
        const Offset(50, 190),
        const Offset(190, 80),
        const Offset(390, 80),
        const Offset(590, 80),
        const Offset(740, 210),
      ],
    };
    
    final seatPositions = positions[seat] ?? [];
    if (seatPositions.isNotEmpty) {
      return seatPositions[0];
    }
    return const Offset(50, 50); // Default fallback
  }

  /// Helper method to build player profile
  Widget _buildPlayerProfile({required String name, required bool isWaiting}) {
    return Column(
      children: [
        CircleAvatar(
          backgroundImage: AssetImage(
            isWaiting ? 'assets/default_profile.jpeg' : 'assets/profile.png',
          ),
          radius: 30,
        ),
        const SizedBox(height: 4),
        Text(
          isWaiting ? 'Waiting...' : name,
          style: TextStyle(
            color: isWaiting ? Colors.amber : Colors.white,
            fontSize: 12,
          ),
        ),
      ],
    );
  }
}
