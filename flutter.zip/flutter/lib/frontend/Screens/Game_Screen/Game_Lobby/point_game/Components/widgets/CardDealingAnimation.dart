import 'package:flutter/material.dart' hide Card;
import 'dart:math' as math;
import '../../Model/Cards_Model.dart';
import '../../point_game_lobby.dart';
import 'CardWidget.dart';

class CardDealingAnimation extends StatefulWidget {
  final List<List<Card>> playersHands;
  final double cardWidth;
  final double cardHeight;
  final List<Offset> playerPositions;
  final VoidCallback onDealingComplete;
  final String? wildCardRank;
  final Offset? wildCardTargetPosition;

  const CardDealingAnimation({
    super.key,
    required this.playersHands,
    required this.cardWidth,
    required this.cardHeight,
    required this.playerPositions,
    required this.onDealingComplete,
    this.wildCardRank,
    this.wildCardTargetPosition,
  });

  @override
  State<CardDealingAnimation> createState() => _CardDealingAnimationState();
}

class _CardDealingAnimationState extends State<CardDealingAnimation>
    with TickerProviderStateMixin {
  late AnimationController _distributionController;
  late Animation<double> _distributionAnimation;
  Set<int> _glowingOpponentIndices = {};

  List<_AnimatedCardData> _animatedCards = [];
  bool _isDistributing = false;
  int _currentCardIndex = 0;
  final int cardsPerPlayer = 13;
  final Duration distributionDelay = const Duration(milliseconds: 40);

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _prepareCards();
    _startDistribution();
  }

  void _initializeAnimations() {
    _distributionController = AnimationController(
      duration: const Duration(milliseconds: 100),
      vsync: this,
    );
    _distributionAnimation = CurvedAnimation(
      parent: _distributionController,
      curve: Curves.easeInOutCubic,
    );
  }

  void _prepareCards() {
    final deckPosition = Offset(
      MediaQuery.of(context).size.width / 2 - widget.cardWidth / 2,
      MediaQuery.of(context).size.height * 0.33,
    );
    _animatedCards.clear();
    for (int round = 0; round < cardsPerPlayer; round++) {
      for (
        int playerIndex = 0;
        playerIndex < widget.playersHands.length;
        playerIndex++
      ) {
        if (round < widget.playersHands[playerIndex].length) {
          final card = widget.playersHands[playerIndex][round];
          final targetPosition = _calculateCardPosition(playerIndex, round);
          _animatedCards.add(
            _AnimatedCardData(
              card: card,
              startPosition: deckPosition,
              targetPosition: targetPosition,
              playerIndex: playerIndex,
              cardIndex: round,
              isDistributed: false,
            ),
          );
        }
      }
    }
    // Add the wildcard animation as the last dealt "card"
    if (widget.wildCardRank != null && widget.wildCardTargetPosition != null) {
      _animatedCards.add(
        _AnimatedCardData(
          card: Card(
            // Customize as per your model
            suit: 'spades', // Replace as needed!
            rank: '${widget.wildCardRank!}j',
            isWild: true,
            pointValue: 0,
          ),
          startPosition: deckPosition,
          targetPosition: widget.wildCardTargetPosition!,
          playerIndex: -1,
          cardIndex: 0,
          isDistributed: false,
        ),
      );
    }
  }

  Offset _calculateCardPosition(int playerIndex, int cardIndex) {
    if (playerIndex == 0) {
      // Main player (bottom)
      final baseX = MediaQuery.of(context).size.width * 0.25;
      final y = MediaQuery.of(context).size.height * 0.6;
      return Offset(baseX + cardIndex * (widget.cardWidth * 0.6), y);
    } else {
      // Other players: use their profile position (card vanishes into this spot)
      final basePosition = widget.playerPositions[playerIndex - 1];
      final screenWidth = MediaQuery.of(context).size.width;
      final screenHeight = MediaQuery.of(context).size.height;
      return Offset(
        basePosition.dx * screenWidth / 850,
        basePosition.dy * screenHeight / 600,
      );
    }
  }

  void _startDistribution() async {
    setState(() {
      _isDistributing = true;
    });
    for (int cardIndex = 0; cardIndex < _animatedCards.length; cardIndex++) {
      await _distributeCard(cardIndex);
    }
    setState(() {
      _isDistributing = false;
    });

    widget.onDealingComplete();
  }

  Future _distributeCard(int cardIndex) async {
    if (cardIndex >= _animatedCards.length) return;
    final cardData = _animatedCards[cardIndex];
    setState(() {
      _currentCardIndex = cardIndex;
      // if (cardData.playerIndex > 0) {
      //   _glowingOpponentIndices.add(cardData.playerIndex);
      // }
    });
    _distributionController.reset();
    await _distributionController.forward();
    setState(() {
      _animatedCards[cardIndex].isDistributed = true;
    });
    // if (cardData.playerIndex > 0) {
    //   // Remove the glow after half a second
    //   Future.delayed(const Duration(milliseconds: 400), () {
    //     if (mounted) {
    //       setState(() {
    //         _glowingOpponentIndices.remove(cardData.playerIndex);
    //       });
    //     }
    //   });
    // }
    await Future.delayed(distributionDelay);
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Table background dim/overlay
        Container(
          color: Colors.black.withOpacity(0.2),
          width: double.infinity,
          height: double.infinity,
        ),

        // Closed deck always visible
        Positioned(
          left: MediaQuery.of(context).size.width / 2 - widget.cardWidth / 2,
          top: MediaQuery.of(context).size.height * 0.33,
          child: Column(
            children: [
              CardWidget(
                isFaceUp: false,
                width: widget.cardWidth,
                height: widget.cardHeight,
              ),
              const SizedBox(height: 5),
              const Text(
                'Closed Deck',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),

        // Profile glows
        // for (int idx = 1; idx <= widget.playerPositions.length; idx++)
        //   if (_glowingOpponentIndices.contains(idx))
        //     Positioned(
        //       left: widget.playerPositions[idx-1].dx * MediaQuery.of(context).size.width / 850,
        //       top: widget.playerPositions[idx-1].dy * MediaQuery.of(context).size.height / 600,
        //       child: Container(
        //         width: widget.cardWidth * 1.4,
        //         height: widget.cardHeight * 1.2,
        //         decoration: BoxDecoration(
        //           borderRadius: BorderRadius.circular(40),
        //           border: Border.all(color: Colors.amberAccent, width: 6),
        //           boxShadow: [BoxShadow(color: Colors.amber.withOpacity(0.7), blurRadius: 24)],
        //         ),
        //       ),
        //     ),

        // Animated cards
        ..._animatedCards.asMap().entries.map((entry) {
          final index = entry.key;
          final cardData = entry.value;
          if (!cardData.isDistributed && index != _currentCardIndex) {
            return const SizedBox.shrink();
          }
          return _buildAnimatedCard(cardData, index == _currentCardIndex);
        }).toList(),
        // Distribution progress indicator
        // if (_isDistributing)
        //   Positioned(
        //     bottom: 50,
        //     left: 0,
        //     right: 0,
        //     child: Center(
        //       child: Container(
        //         padding: const EdgeInsets.symmetric(
        //           horizontal: 20,
        //           vertical: 10,
        //         ),
        //         decoration: BoxDecoration(
        //           color: Colors.black.withOpacity(0.7),
        //           borderRadius: BorderRadius.circular(20),
        //           border: Border.all(color: Colors.amber, width: 1),
        //         ),
        //         child: const Text(
        //           'Dealing Cards...',
        //           style: TextStyle(
        //             color: Colors.white,
        //             fontSize: 16,
        //             fontWeight: FontWeight.bold,
        //           ),
        //         ),
        //       ),
        //     ),
        //   ),
      ],
    );
  }

  Widget _buildAnimatedCard(
    _AnimatedCardData cardData,
    bool isCurrentlyAnimating,
  ) {
    // Animate the card flying from deck to its slot/profile
    if (isCurrentlyAnimating && !cardData.isDistributed) {
      return AnimatedBuilder(
        animation: _distributionAnimation,
        builder: (context, child) {
          final left =
              cardData.startPosition.dx +
              (cardData.targetPosition.dx - cardData.startPosition.dx) *
                  _distributionAnimation.value;
          final top =
              cardData.startPosition.dy +
              (cardData.targetPosition.dy - cardData.startPosition.dy) *
                  _distributionAnimation.value;
          double scale = 1;
          double opacity = 1;
          if (cardData.playerIndex != 0) {
            // For opponents, fade out/scaling as card goes into the profile
            scale = 1 - _distributionAnimation.value * 0.8;
            opacity = 1 - _distributionAnimation.value;
          }
          return Positioned(
            left: left,
            top: top,
            child: Opacity(
              opacity: opacity,
              child: Transform.scale(
                scale: scale,
                child: _buildCardWidget(cardData.card, false),
              ),
            ),
          );
        },
      );
    }

    // After animation is over:
    // - Only show table wild slot if this is the wild "card"
    // - Only show main player's cards sitting on table, not opponent
    if (cardData.isDistributed) {
      if (cardData.playerIndex == 0) {
        // Main player hand gets laid down (back of card) -- playing phase handles face-up
        return Positioned(
          left: cardData.targetPosition.dx,
          top: cardData.targetPosition.dy,
          child: _buildCardWidget(cardData.card, false),
        );
      } else if (cardData.playerIndex == -1) {
        // Wildcard: show face up after dealing
        return Positioned(
          left: cardData.targetPosition.dx,
          top: cardData.targetPosition.dy,
          child: _buildCardWidget(cardData.card, true),
        );
      } else {
        // Opponent: no cards remain on table
        return const SizedBox.shrink();
      }
    }
    return const SizedBox.shrink();
  }

  Widget _buildCardWidget(Card card, bool isFaceUp) {
    String imagePath;
    if (!isFaceUp) {
      imagePath = 'assets/cards/back_2.png';
    } else if (card.isJoker) {
      imagePath = 'assets/cards/joker.png';
    } else {
      imagePath = 'assets/cards/${card.suit}/${card.rank}.png';
    }
    return Container(
      width: widget.cardWidth,
      height: widget.cardHeight,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(6),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 6,
            offset: const Offset(2, 2),
            spreadRadius: 1,
          ),
        ],
        border: Border.all(color: Colors.white.withOpacity(0.7), width: 1),
        image: DecorationImage(
          image: AssetImage(imagePath),
          fit: BoxFit.cover,
          onError: (exception, stackTrace) {
            print('Failed to load image: $imagePath');
          },
        ),
      ),
    );
  }

  @override
  void dispose() {
    _distributionController.dispose();
    super.dispose();
  }
}

class _AnimatedCardData {
  final Card card;
  final Offset startPosition;
  final Offset targetPosition;
  final int playerIndex;
  final int cardIndex;
  bool isDistributed;
  _AnimatedCardData({
    required this.card,
    required this.startPosition,
    required this.targetPosition,
    required this.playerIndex,
    required this.cardIndex,
    this.isDistributed = false,
  });
}
