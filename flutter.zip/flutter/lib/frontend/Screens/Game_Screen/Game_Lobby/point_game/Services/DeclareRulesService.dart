import '../Model/Card_Group_Model.dart';

class DeclareRulesService {
  static const int impureSequenceValue = 4;
  static const int pureSequenceValue = 5;
  static const int setValue = 6;

  bool isRuleMatch(List<CardGroupModel> groups) {
    bool hasPureSequence = false;
    bool hasSequence = false;

    for (var group in groups) {
      if (group.valueGrp == pureSequenceValue) {
        hasPureSequence = true;
      }
      if (group.valueGrp == pureSequenceValue || group.valueGrp == impureSequenceValue) {
        hasSequence = true;
      }
    }

    return hasPureSequence && hasSequence;
  }
}