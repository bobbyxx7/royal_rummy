import 'dart:convert';
import 'dart:math';
import 'package:arka_infotech/provider/pointGameProvider.dart';
import 'package:flutter/material.dart' hide Card;
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'dart:math' as math;
import 'dart:async';
import '../../../components/Animations.dart';
import '../../../components/Canvas.dart';
import '../../point_game_dashboard.dart';
import './Model/Game_Model.dart';
import './Model/Cards_Model.dart';
import './Services/RummyPointSocketService.dart';
import '../../../../Socket/socket_service.dart';
import '../../../../../provider/auth_view_model.dart';
import './Services/GameLogicService.dart';
import 'Components/helpers/GamePhaseHandler.dart';
import 'Components/widgets/CardWidget.dart';
import 'Components/widgets/PlayerProfilesOverlay.dart';
import 'Components/widgets/PointGameLoadingRoom.dart';
import 'Components/widgets/PointGameResultDialog.dart';
import 'Components/widgets/PointGameWaitingRoom.dart';
import 'Components/widgets/player_hand_widget.dart';
import 'Components/widgets/CardDealingAnimation.dart';
import 'Components/widgets/player_profile_widget.dart';
import 'Components/widgets/GamePhaseOverlay.dart';
import './Services/CardHandProvider.dart';
import './Services/GameStateCoordinator.dart';
import './Services/WaitingPhaseService.dart';


class _AnimatedCardData {
  final Card card;
  final Offset startPosition;
  final Offset targetPosition;
  bool isDistributed;
  _AnimatedCardData({
    required this.card,
    required this.startPosition,
    required this.targetPosition,
    this.isDistributed = false,
  });
}

class PointGameLobby extends StatefulWidget {
  final GameModel gameModel;
  final SocketService socketService;
  final dynamic tableData; // Accept full response object
  final int? noOfPlayers;

  const PointGameLobby({
    super.key,
    required this.gameModel,
    required this.socketService,
    this.tableData, // now dynamic: entire table-data object
    this.noOfPlayers,
  });

  @override
  State<PointGameLobby> createState() => _PointGameLobbyState();
}

class _PointGameLobbyState extends State<PointGameLobby>
    with TickerProviderStateMixin {
  late final RummyPointSocketService _socketService;
  bool _isLoadingInitialized = false;
  List<String> _groupLabels = [];
  Timer? _statusTimer;
  dynamic _pendingMyCardData;

  late double screenWidth;
  late double screenHeight;
  double cardWidth = 50;
  double cardHeight = 80;
  late double deckLeft;
  late double discardLeft;
  late double userCardsLeft;
  late double userCardsTop;
  late AuthViewModel authViewModel;
  // bool _isDealing = false;
  List<_AnimatedCardData> _dealingAnimatedCards = [];
  int _dealingCurrentCardIndex = 0;
  AnimationController? _dealingController;
  Animation<double>? _dealingAnimation;

  // Add back ValueNotifier for game phase
  // final ValueNotifier<GamePhase> _gamePhaseNotifier = ValueNotifier(GamePhase.waiting);
  // Add ValueNotifiers for animation/drag/drop if needed
  late AnimationController _turnTimerController;

  late PointGameProvider pointGameProvider;

  /// Mapping...
  final Map<int, List<Offset>> playerPositions = {
    2: [const Offset(390, 80)], // seat_psoition 2
    6: [
      const Offset(50, 190), // seat_psoition 2
      const Offset(190, 80), // seat_psoition 3
      const Offset(390, 80), // seat_psoition 4
      const Offset(590, 80), // seat_psoition 5
      const Offset(740, 210), // seat_psoition 6
    ],
  };
  String _mapRankForAsset(String rank) {
    rank = rank.replaceAll('_', '').trim();
    switch (rank) {
      case 'A':
        return '1';
      case 'J':
        return '11';
      case 'Q':
        return '12';
      case 'K':
        return '13';
      default:
        return rank;
    }
  }



  /// Returns the expected player count for the table (2 or 6 typically). Supports full response object in tableData.
  int get expectedPlayerCount {
    if (widget.noOfPlayers != null) {
      debugPrint('Using noOfPlayers from constructor');
      return widget.noOfPlayers!;
    }
    // tableData is Map-like response
    if (widget.tableData != null &&
        widget.tableData is Map &&
        widget.tableData['no_of_players'] != null) {
      debugPrint('Using no_of_players from tableData');
      final n = int.tryParse(widget.tableData['no_of_players'].toString());
      if (n != null) return n;
    }
    // If tableData has table_data list with no_of_players in first map
    if (widget.tableData != null &&
        widget.tableData is Map &&
        widget.tableData['table_data'] != null &&
        (widget.tableData['table_data'] is List) &&
        (widget.tableData['table_data'] as List).isNotEmpty) {
      final map = widget.tableData['table_data'][0];
      if (map is Map && map['no_of_players'] != null) {
        debugPrint('Using no_of_players which was in first map of table_data');
        final n = int.tryParse(map['no_of_players'].toString());
        if (n != null) return n;
      }
      // Fallback to length of table_data
      debugPrint(
        'Using length of table_data as no_of_players ${widget.tableData['table_data'].length}',
      );
      return (widget.tableData['table_data'] as List).length;
    }
    // Legacy fallback - won't be used unless old usage
    return 2;
  }

  // Add debouncing for player join detection
  Timer? _playerCheckDebounceTimer;
  Map<int, Map<String, dynamic>> _previousPlayerState = {};

  void _checkIfAllPlayersJoined() async {
    // Prevent multiple simultaneous checks
    if (pointGameProvider.isCheckingPlayersJoined) return;
    
    final int expected = expectedPlayerCount;
    int filled = 0;
    List<dynamic> tableUsers = [];
    if (widget.tableData != null &&
        widget.tableData is Map &&
        widget.tableData['table_data'] != null) {
      tableUsers = widget.tableData['table_data'] as List;
    }
    
    // Count filled seats with improved logic
    final currentPlayerState = <int, Map<String, dynamic>>{};
    for (var seat = 1; seat <= expected; seat++) {
      final p = pointGameProvider.playersBySeat[seat];
      if (p != null &&
          p['user_id'] != null &&
          p['user_id'].toString() != '0' &&
          p['name'].toString() != '0') {
        filled++;
        currentPlayerState[seat] = Map<String, dynamic>.from(p);
      }
    }

    // Check for new players joined
    _detectPlayerChanges(currentPlayerState);

    bool canStart = _canGameStart(filled, expected);
    
    // Only proceed if we haven't already transitioned and conditions are met
    if (!pointGameProvider.hasTransitionedFromWaiting &&
        pointGameProvider.gamePhase == GamePhase.waiting &&
        canStart) {
      
      // Defer all provider state changes to avoid build-time setState
      WidgetsBinding.instance.addPostFrameCallback((_) async {
        if (mounted) {
          // Set flag to prevent multiple transitions
          pointGameProvider.setIsCheckingPlayersJoined(true);
          
          try {
            pointGameProvider.setHasTransitionedFromWaiting(true);
            await Future.delayed(const Duration(seconds: 1));
            
            if (mounted) {
              _transitionToPhase(GamePhase.loading);
            }
          } finally {
            // Always reset the flag
            pointGameProvider.setIsCheckingPlayersJoined(false);
          }
        }
      });
    }
    
    // Update previous state
    _previousPlayerState = currentPlayerState;
  }

  bool _canGameStart(int filled, int expected) {
    if (expected == 2) {
      return filled == 2;
    } else if (expected == 6) {
      // Auto-start with minimum 2 players after 30 seconds
      return filled >= 2 && (filled == 6 || _shouldAutoStart());
    } else {
      return filled == expected;
    }
  }

  bool _shouldAutoStart() {
    // Auto-start if waiting for more than 30 seconds with at least 2 players
    final waitingStartTime = pointGameProvider.waitingStartTime;
    if (waitingStartTime == null) return false;
    
    final waitingDuration = DateTime.now().difference(waitingStartTime);
    return waitingDuration.inSeconds >= 30;
  }

  void _detectPlayerChanges(Map<int, Map<String, dynamic>> currentState) {
    // Check for new players
    for (final entry in currentState.entries) {
      final seat = entry.key;
      final player = entry.value;
      final previousPlayer = _previousPlayerState[seat];
      
      // New player joined
      if (previousPlayer == null || 
          previousPlayer['user_id'] != player['user_id'] ||
          previousPlayer['name'] != player['name']) {
        _onPlayerJoined(seat, player);
      }
    }
    
    // Check for players who left
    for (final entry in _previousPlayerState.entries) {
      final seat = entry.key;
      final previousPlayer = entry.value;
      final currentPlayer = currentState[seat];
      
      // Player left
      if (currentPlayer == null || 
          currentPlayer['user_id'] != previousPlayer['user_id']) {
        _onPlayerLeft(seat, previousPlayer);
      }
    }
  }

  void _onPlayerJoined(int seat, Map<String, dynamic> player) {
    debugPrint('[WAITING] Player joined: ${player['name']} at seat $seat');
    
    // Show join animation in waiting room
    // This would trigger the animation in PointGameWaitingRoom
    
    // Defer provider state changes and UI updates to avoid build-time setState
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        // Update entry level
        final newEntryLevel = pointGameProvider.entryLevel - 1;
        pointGameProvider.setEntryLevel(newEntryLevel);
        
        // Show notification
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${player['name']} joined the game!'),
            backgroundColor: Colors.green,
            duration: const Duration(seconds: 2),
          ),
        );
      }
    });
  }

  void _onPlayerLeft(int seat, Map<String, dynamic> player) {
    debugPrint('[WAITING] Player left: ${player['name']} from seat $seat');
    
    // Defer provider state changes and UI updates to avoid build-time setState
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        // Update entry level
        final newEntryLevel = pointGameProvider.entryLevel + 1;
        pointGameProvider.setEntryLevel(newEntryLevel);
        
        // Show notification
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${player['name']} left the game'),
            backgroundColor: Colors.orange,
            duration: const Duration(seconds: 2),
          ),
        );
      }
    });
  }

  void _initializeForRevealHand() {
    final handLen = pointGameProvider.cardGroups.length;
    pointGameProvider.setMainHandRevealStatusNotifier(List.filled(handLen, false));
    pointGameProvider.setShowRealWildcard(false);
  }

  // Add waiting phase service
  late WaitingPhaseService _waitingPhaseService;

  @override
  void initState() {
    super.initState();
    pointGameProvider = Provider.of<PointGameProvider>(context, listen: false);
    
    // Initialize socket service first
    _socketService = RummyPointSocketService.getInstance();
    
    // Initialize waiting phase service
    _waitingPhaseService = WaitingPhaseService(_socketService);
    
    _turnTimerController = AnimationController(
      duration: const Duration(seconds: 30),
      vsync: this,
    )..addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        _advanceTurn();
      }
    });
    
    // Use provider's turn timer instead of local ValueNotifier
    pointGameProvider.addListener(_startTurnTimer);
  }

  void _startStatusTimer() {
    _statusTimer?.cancel();
    final user = Provider.of<AuthViewModel>(context, listen: false).user;
    if (user == null) return;
    _statusTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (pointGameProvider.gamePhase == GamePhase.playing &&
          pointGameProvider.gameId != null &&
          _socketService.isConnected) {
        _socketService.emitStatus(
          user.id.toString(),
          user.token.toString(),
          pointGameProvider.gameId.toString(),
        );
        print('Sent keep-alive status for gameId: ${pointGameProvider.gameId}');
      }
    });
  }

  void _setupSocketListeners() {
    // Initialize the coordinator
    final coordinator = GameStateCoordinator.getInstance();
    coordinator.setPointGameProvider(pointGameProvider);
    coordinator.initialize();

    // Set up coordinator callbacks
    coordinator.onPhaseChanged = (phase) {
      if (mounted) {
        setState(() {
          _transitionToPhase(phase);
        });
      }
    };

    coordinator.onCardsReceived = (cards) {
      if (mounted) {
        setState(() {
          pointGameProvider.setMyCardReceivedNotifier(true);
          // Trigger card dealing animation if needed
          if (coordinator.isDealingInProgress) {
            _startCardDealingAnimation(cards);
          }
        });
      }
    };

    coordinator.onDealingStateChanged = (isDealing) {
      if (mounted) {
        setState(() {
          pointGameProvider.setIsDealing(isDealing);
        });
      }
    };

    coordinator.onError = (error) {
      if (mounted) {
        _showErrorDialog(error);
      }
    };

    // Set up socket listeners using coordinator
    // _socketService is already initialized in initState()

    // Override the socket listeners to use coordinator
    _socketService.onMyCard = (data) async {
      if (!mounted) return;
      if (data is String) data = jsonDecode(data);
      if (data['code'] == 200 && data['cards'] != null) {
        final gameProvider = Provider.of<GameProvider>(context, listen: false);
        final cardCodes = (data['cards'] as List).map((
            c) => c['card'] as String).toList();
        gameProvider.mapHandWithWild(cardCodes);
        pointGameProvider.setMyCardReceivedNotifier(true);
        _checkIfReadyForPlayingPhase(); // <-- Only check here, NOT set phase directly
      }
      else {
        debugPrint(
            '[Socket] error in my-card response:  31m${data['message']} 0m');
      }
    };

    _socketService.onStartGameResponse = (data) {
      // Let coordinator handle this
      coordinator.handleStartGameResponse(data);
    };

    _socketService.onGetTableResponse = (data) {
      if (!mounted) return;
      if (data is String) data = jsonDecode(data);
      if (data['code'] == 200 && data['table_data'] != null) {
        setState(() {
          _updatePlayerProfilesFromTable(data['table_data']);
          final tableId = data['table_data'][0]['table_id'].toString();
          if (tableId != 'null' && tableId != '') {
            // int.tryParse(tableId);
            pointGameProvider.setTableId(int.tryParse(tableId));
          }
          if (data['message']?.toLowerCase()?.contains('already on tabl') == true) {
            final user = Provider.of<AuthViewModel>(context, listen: false).user;
            if (user != null && pointGameProvider.tableId != null) {
              _transitionToPhase(GamePhase.playing);
              _socketService.emitStatus(
                user.id.toString(),
                user.token.toString(),
                pointGameProvider.tableId.toString(),
              );
            }
          } else {
            _checkIfAllPlayersJoined();
          }
        });
      } else {
        _showErrorDialog(data['message'] ?? 'Failed to fetch table data');
      }
    };

    _socketService.onTrigger = (payload) {
      if (!mounted) return;
      if (payload == 'callStatus' || payload == 'call_status') {
        final user = Provider.of<AuthViewModel>(context, listen: false).user!;
        if (pointGameProvider.gameId!= null) {
          _socketService.emitStatus(
            user.id.toString(),
            user.token.toString(),
            pointGameProvider.gameId.toString(),
          );
        }
      }
    };

    _socketService.onStatus = (data) {
      if (!mounted) return;
      if (data is String) data = jsonDecode(data);

      if (data['code'] == 200 && data['table_users'] != null) {
        _updatePlayersFromStatus(data['table_users'], data['chaal_user_id']);
      } else if (data['code'] == 403) {
        // User not on table
        debugPrint('User not on table, returning to dashboard');
        Navigator.pop(context);
      }
    };

    _socketService.onGetCard = (data) {
      // Let coordinator handle this
      coordinator.handleGetCardData(data);
    };

    _socketService.onGetDropCard = (data) {
      // Let coordinator handle this
      coordinator.handleGetDropCardData(data);
    };
  }

  void _startCardDealingAnimation(List<Card> cards) {
    if (pointGameProvider.isDealing) return;

    setState(() {
      _dealingAnimatedCards = cards.asMap().entries.map((entry) {
        return _AnimatedCardData(
          card: entry.value,
          startPosition: Offset(deckLeft, screenHeight * 0.5),
          targetPosition: Offset(
            userCardsLeft + (entry.key * (cardWidth * 0.3)),
            userCardsTop,
          ),
        );
      }).toList();
      _dealingCurrentCardIndex = 0;
    });
    pointGameProvider.setIsDealing(true);

    _dealingController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    );

    _dealingAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _dealingController!,
      curve: Curves.easeInOut,
    ));

    _dealingController!.addListener(() {
      if (mounted) {
        setState(() {});
      }
    });

    _dealingController!.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        setState(() {
          _dealingAnimatedCards.clear();
        });
        pointGameProvider.setIsDealing(false);
        _dealingController?.dispose();
        _dealingController = null;
      }
    });

    _dealingController!.forward();
  }

  void _updatePlayersSeatMap(dynamic tableUsers) {
    if (tableUsers == null) return;
    
    try {
      Map<int, Map<String, dynamic>> newMap = {};
      
      // Validate and parse table users
      if (tableUsers is! List) {
        debugPrint('[PLAYER UPDATE] Invalid tableUsers format: expected List, got ${tableUsers.runtimeType}');
        return;
      }
      
      for (final p in tableUsers) {
        if (p is! Map) continue;
        
        int? seat = int.tryParse(p['seat_position']?.toString() ?? '');
        if (seat == null || seat < 1) continue;
        
        newMap[seat] = Map<String, dynamic>.from(p);
      }
      
      // Check if there are actual changes
      bool changed = false;
      for (final seat in newMap.keys) {
        final oldSeat = pointGameProvider.playersBySeat[seat];
        final newSeat = newMap[seat];
        if (newSeat == null) continue;
        
        if (oldSeat == null ||
            (oldSeat['user_id']?.toString() != newSeat['user_id']?.toString()) ||
            (oldSeat['name'] != newSeat['name']) ||
            (oldSeat['profile_pic'] != newSeat['profile_pic'])) {
          changed = true;
          break;
        }
      }
      
      if (!changed) {
        for (final seat in pointGameProvider.playersBySeat.keys) {
          if (!newMap.containsKey(seat)) {
            changed = true;
            break;
          }
        }
      }
      
      if (changed) {
        pointGameProvider.playersBySeat
          ..clear()
          ..addAll(newMap);
        
        debugPrint('playersBySeat: ${pointGameProvider.playersBySeat}');
        
        // Only count real players for entryLevel
        int realPlayers = 0;
        for (final p in pointGameProvider.playersBySeat.values) {
          if (p['user_id'] != null &&
              p['user_id'].toString() != '0' &&
              p['name'].toString() != '0') {
            realPlayers++;
          }
        }
        
        // Defer provider state changes to avoid build-time setState
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) {
            pointGameProvider.setEntryLevel(expectedPlayerCount - realPlayers);
            debugPrint('entryLevel: ${pointGameProvider.entryLevel}');
          }
        });
      }
    } catch (e) {
      debugPrint('[PLAYER UPDATE] Error updating player seat map: $e');
    }
  }

  void _updatePlayerProfilesFromTable(dynamic tableData) {
    final players =
        (tableData is Map && tableData['table_data'] != null)
            ? tableData['table_data']
            : (tableData ?? []);
    _updatePlayersSeatMap(players);
    _checkIfAllPlayersJoined();
  }

  void _updatePlayersFromStatus(List tableUsers, String? chaalUserId) {
    _updatePlayersSeatMap(tableUsers);
    pointGameProvider.setCurrentChaalUserId(chaalUserId);

    _checkIfAllPlayersJoined();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    if (!_isLoadingInitialized) {
      _isLoadingInitialized = true;
      authViewModel = Provider.of<AuthViewModel>(context, listen: false);
      
      // Initialize provider state after the build is complete
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          pointGameProvider.setCachedUser(authViewModel.user);
          pointGameProvider.initializeGame();
          pointGameProvider.setExpectedPlayerCount(expectedPlayerCount);
          pointGameProvider.setEntryLevel(expectedPlayerCount);
          pointGameProvider.setHasTransitionedFromWaiting(false);
        }
      });

      cardWidth = (MediaQuery.of(context).size.width * 0.06).clamp(32.0, 60.0);
      screenWidth = MediaQuery.of(context).size.width;
      screenHeight = MediaQuery.of(context).size.height;

      cardHeight = cardWidth * 1.6;
      deckLeft = (screenWidth - cardWidth) / 2 - 44;
      discardLeft = deckLeft + cardWidth + 30;
      userCardsLeft = screenWidth * 0.25;
      userCardsTop = screenHeight * 0.6;
      if (widget.tableData != null &&
          widget.tableData is Map &&
          widget.tableData['table_data'] != null &&
          (widget.tableData['table_data'] is List) &&
          (widget.tableData['table_data'] as List).isNotEmpty) {
        final first = widget.tableData['table_data'][0];
        final tableId = first['table_id']?.toString() ?? '';
        if (tableId != 'null' && tableId != '') {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted) {
              pointGameProvider.setTableId(int.tryParse(tableId));
            }
          });
        }
        _updatePlayerProfilesFromTable(widget.tableData);
        _checkIfAllPlayersJoined();
      } else {
        final user = authViewModel.user;
        if (user != null) {
          final tableBootValue = "80.0"; // TODO: dynamically fetch if needed
          final tablePlayers = expectedPlayerCount.toString();
          _socketService.getTable(
            user.id.toString(),
            user.token.toString(),
            tableBootValue,
            tablePlayers,
          );
        }
      }
      _setupSocketListeners();
      _setupSocketConnection();
      _transitionToPhase(GamePhase.waiting);
    }
  }

  @override
  void dispose() {
    // Cancel all timers
    _statusTimer?.cancel();
    _waitingTimeoutTimer?.cancel();
    _dealingController?.dispose();
    
    // Remove provider listener
    pointGameProvider.removeListener(_startTurnTimer);
    
    // Leave table if connected
    if (pointGameProvider.cachedUser != null && 
        pointGameProvider.gameId != null && 
        _socketService.isConnected) {
      try {
        _socketService.leaveTable(
          pointGameProvider.cachedUser.id.toString(),
          pointGameProvider.cachedUser.token.toString(),
          gameId: pointGameProvider.gameId.toString(),
        );
      } catch (e) {
        debugPrint('[DISPOSE] Error leaving table: $e');
      }
    }
    
    _turnTimerController.dispose();

    // SAFETY: Deregister all socket event listeners to avoid callbacks to disposed state
    _socketService.onMyCard = null;
    _socketService.onStartGameResponse = null;
    _socketService.onGetTableResponse = null;
    _socketService.onTrigger = null;
    _socketService.onStatus = null;
    _socketService.onGetCard = null;
    _socketService.onGetDropCard = null;
    _socketService.onLeaveTableResponse = null;
    
    // Dispose socket service
    try {
      (_socketService).dispose();
    } catch (e) {
      debugPrint('[DISPOSE] Error disposing socket service: $e');
    }
    
    // SAFETY: If using GameStateCoordinator singleton, also clear its callbacks if possible
    try {
      final coordinator = GameStateCoordinator.getInstance();
      coordinator.onPhaseChanged = null;
      coordinator.onCardsReceived = null;
      coordinator.onDealingStateChanged = null;
      coordinator.onError = null;
    } catch (_) {
      // Ignore if already disposed or doesn't exist.
    }

    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }
  void startLoading() async {
    debugPrint('[PHASE] Loading: precaching assets');
    pointGameProvider.setShowLoading(true);
    pointGameProvider.setLoadingProgress(0.0);
    final images = [
      'assets/dashboard_bg.png',
      'assets/profile.png',
      'assets/default_profile.jpeg',
      'assets/game_table2.png',
      'assets/cards/back_2.png',
      'assets/cards/joker/joker.png',
      for (var suit in ['hearts', 'diamonds', 'clubs', 'spades'])
        for (var rank in [
          '1',
          '2',
          '3',
          '4',
          '5',
          '6',
          '7',
          '8',
          '9',
          '10',
          '11',
          '12',
          '13',
        ]) ...[
          'assets/cards/$suit/$rank.png',
          'assets/cards/$suit/${rank}j.png',
        ],
    ];
    final totalSteps = images.length + 2;
    final step = 100.0 / totalSteps;
    for (var image in images) {
      try {
        await precacheImage(AssetImage(image), context);
        if (mounted) {
          pointGameProvider.setLoadingProgress(pointGameProvider.loadingProgress + step);
        }
      } catch (e) {
        print('Error precaching image $image: $e');
      }
    }

    await Future.delayed(const Duration(milliseconds: 500));
    if (mounted) {
      pointGameProvider.setLoadingProgress(pointGameProvider.loadingProgress + step);
    }

    await Future.delayed(const Duration(milliseconds: 500));
    if (mounted) {
      pointGameProvider.setLoadingProgress(100.0);
      pointGameProvider.setShowLoading(false);
      _transitionToPhase(GamePhase.dealing);
      // Always start dealing animation in dealing phase
      _startDealingAnimation(List<Card>.from(pointGameProvider.cardGroups.expand((group) => group).toList()));
      pointGameProvider.setMyCardReceivedNotifier(false);
    }
  }

  void _startTurnTimer() {
    _turnTimerController.reset();
    _turnTimerController.forward();
  }

  void _advanceTurn() {
    if (pointGameProvider.showLoading && mounted && !pointGameProvider.isTurnAdvancing) {
      pointGameProvider.setIsTurnAdvancing(true);
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) {
          pointGameProvider.setIsTurnAdvancing(false);
          return;
        }
        setState(() {
          pointGameProvider.clearSelectedCards();
          final playerCount = widget.gameModel.playersHands.length;
          if (widget.gameModel.currentTurnPhase == TurnPhase.discarding) {
            widget.gameModel.currentTurn =
                (widget.gameModel.currentTurn + 1) % playerCount;
            widget.gameModel.currentTurnPhase = TurnPhase.drawing;
          } else if (widget.gameModel.currentTurnPhase == TurnPhase.drawing) {
            widget.gameModel.currentTurnPhase = TurnPhase.discarding;
          }
          pointGameProvider.setCurrentTurnIndex(widget.gameModel.currentTurn);
          _startTurnTimer();
          pointGameProvider.setIsTurnAdvancing(false);
        });
      });
    }
  }
  void _sortPlayerHand() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      setState(() {
        final List<Card> hand = List<Card>.from(pointGameProvider.cardGroups.expand((group) => group).toList());
        pointGameProvider.updateCardGroups([List.from(hand)]);
        _groupLabels = [];
        pointGameProvider.clearSelectedCards();

        final logic = GameLogicService.getInstance();
        final grouped = logic.groupAndLabelHand(hand);
        List<List<Card>> validGroups = [];
        List<Card> leftover = [];
        List<String> labels = [];
        for (var g in grouped) {
          if (g.groupValue == 'Invalid') {
            leftover.addAll(g.cards);
          } else {
            validGroups.add(List<Card>.from(g.cards));
            labels.add(g.groupValue ?? 'Invalid');
          }
        }
        if (leftover.isNotEmpty) {
          Map<String, List<Card>> suitGroups = {};
          for (var card in leftover) {
            suitGroups.putIfAbsent(card.suit, () => []).add(card);
          }
          for (var suit in suitGroups.keys) {
            var suitGroup = suitGroups[suit]!;
            suitGroup.sort((a, b) {
              int rankA = int.tryParse(a.rank.replaceAll('j', '')) ?? 0;
              int rankB = int.tryParse(b.rank.replaceAll('j', '')) ?? 0;
              return rankA.compareTo(rankB);
            });
            validGroups.add(List<Card>.from(suitGroup));
            final points = logic.evaluateGroup(suitGroup).groupPoints;
            labels.add('Invalid ($suit, $points pts)');
          }
        }
        pointGameProvider.updateCardGroups(validGroups);
        _groupLabels = labels;

        final bool canDeclare = logic.validateDeclare(grouped);
        pointGameProvider.setCanDeclare(canDeclare);
        pointGameProvider.clearSelectedCards();
      });
    });
  }

  void _moveCard(
    Card card,
    int sourceIndex,
    int targetIndex,
    int insertionIndex,
  ) {
    setState(() {
      final groups = List<List<Card>>.from(pointGameProvider.cardGroups);
      
      // Remove card from all groups
      for (final group in groups) {
        group.remove(card);
      }
      
      // Remove empty groups
      final filteredGroups = groups.where((group) => group.isNotEmpty).toList();
      
      if (targetIndex < 0 || targetIndex >= filteredGroups.length) {
        return;
      }
      
      final group = filteredGroups[targetIndex];
      if (insertionIndex < 0) insertionIndex = 0;
      if (insertionIndex > group.length) insertionIndex = group.length;
      group.insert(insertionIndex, card);
      
      final newHand = <Card>[];
      for (final g in filteredGroups) {
        newHand.addAll(g);
      }
      
      pointGameProvider.updateCardGroups(filteredGroups);
      
      assert(
        newHand.toSet().length == newHand.length,
        'Duplicate card in hand after move!',
      );
    });
  }

  void _groupCards() {
    if (pointGameProvider.selectedCards.length > 1 && pointGameProvider.cardGroups.length < 6) {
      final selectedCards = pointGameProvider.selectedCards.toList();
      setState(() {
        final groups = List<List<Card>>.from(pointGameProvider.cardGroups);
        
        for (var group in groups) {
          group.removeWhere((card) => selectedCards.contains(card));
        }
        
        final filteredGroups = groups.where((group) => group.isNotEmpty).toList();
        filteredGroups.add(selectedCards);
        
        pointGameProvider.updateCardGroups(filteredGroups);
        pointGameProvider.clearSelectedCards();
        _rearrangeCards();
      });
    }
  }

  void _rearrangeCards() {
    setState(() {});
  }
  Future<void> _discardCardAnimation(Card card) async {
    if (pointGameProvider.animationAction != AnimationAction.none) return;

    Offset start = Offset(userCardsLeft + 50, userCardsTop + 50);
    pointGameProvider.setDiscardSourceGroupIndex(-1);
    pointGameProvider.setDiscardSourceCardIndex(-1);

    for (int groupIndex = 0; groupIndex < pointGameProvider.cardGroups.length; groupIndex++) {
      int cardIndex = pointGameProvider.cardGroups[groupIndex].indexOf(card);
      if (cardIndex != -1) {
        pointGameProvider.setDiscardSourceGroupIndex(groupIndex);
        pointGameProvider.setDiscardSourceCardIndex(cardIndex);
        double groupLeft = userCardsLeft + groupIndex * (cardWidth * 0.6 + 10);
        double cardLeft = groupLeft + cardIndex * (cardWidth * 0.6);
        start = Offset(cardLeft, userCardsTop + 10);
        break;
      }
    }
    if (pointGameProvider.discardSourceGroupIndex == -1) {
      return;
    }

    setState(() {
      final groups = List<List<Card>>.from(pointGameProvider.cardGroups);
      groups[pointGameProvider.discardSourceGroupIndex!].removeAt(pointGameProvider.discardSourceCardIndex!);
      if (groups[pointGameProvider.discardSourceGroupIndex!].isEmpty) {
        groups.removeAt(pointGameProvider.discardSourceGroupIndex!);
      }
      pointGameProvider.updateCardGroups(groups);
    });

    final discardIndex = widget.gameModel.discardPile.length;
    final offsetX = discardIndex % 3 * 5.0;
    final offsetY = discardIndex ~/ 3 * 5.0;
    final end = Offset(discardLeft + offsetX, screenHeight * 0.33 + offsetY);

    setState(() {
      pointGameProvider.setAnimationStart(start);
      pointGameProvider.setAnimationEnd(end);
      pointGameProvider.setDraggingCard(card);
      pointGameProvider.setAnimationAction(AnimationAction.discard);
    });
  }

  Future _revealMainPlayerHandSequentially() async {
    for (int i = 0; i < pointGameProvider.mainHandRevealStatusNotifier.length; i++) {
      await Future.delayed(const Duration(milliseconds: 100));
      final reveal = List<bool>.from(pointGameProvider.mainHandRevealStatusNotifier);
      reveal[i] = true;
      pointGameProvider.setMainHandRevealStatusNotifier(reveal);
    }
    await Future.delayed(const Duration(milliseconds: 300));
    if (mounted) {
      setState(() {
        pointGameProvider.setShowRealWildcard(true);
      });
      debugPrint('[REVEAL] Wild card shown');
    }
  }

  Widget _buildMainPlayerProfile() {
    final mainPlayer = pointGameProvider.playersBySeat[1];
    final name =
        mainPlayer != null && mainPlayer['name'] != null
            ? mainPlayer['name'] as String
            : (pointGameProvider.cachedUser?.name ?? 'You');
    final userId =
        mainPlayer != null && mainPlayer['user_id'] != null
            ? mainPlayer['user_id'].toString()
            : (pointGameProvider.cachedUser?.id?.toString() ?? '');

    final profilePic = 'assets/profile.png';
    return Positioned(
      left: 10,
      right: 0,
      top: screenHeight * 0.82,
      child: Center(
        child: ProfileTimerWidget(
                  key: const ValueKey('main_player'),
          username: name,
                  score: 80,
                  metric1: 30,
                  metric2: 90,
          isTimerActive: isTimerActiveFor(userId),
                  timerDuration: const Duration(seconds: 30),
          imagePath: profilePic,
        ),
      ),
    );
  }

  bool _canDraw() =>
      widget.gameModel.currentTurn == 0 &&
      widget.gameModel.currentTurnPhase == TurnPhase.drawing &&
      pointGameProvider.selectedCards.isEmpty &&
      pointGameProvider.animationAction == AnimationAction.none;

  Future<void> _startDealingAnimation(List<Card> cards) async {
    if (!mounted || pointGameProvider.gamePhase != GamePhase.dealing) return;
    pointGameProvider.setIsDealing(true);
    _dealingAnimatedCards.clear();
    pointGameProvider.setDealingCurrentCardIndexNotifier(0);

    final deckPosition = Offset(
      screenWidth / 2 - cardWidth / 2,
      screenHeight * 0.33,
    );
    for (int i = 0; i < 13; i++) {
      final target = Offset(
        userCardsLeft + i * (cardWidth * 0.6),
        userCardsTop,
      );
      _dealingAnimatedCards.add(
        _AnimatedCardData(
          card: Card(
            suit: 'unknown',
            rank: 'back',
            isWild: false,
            isJoker: false,
            pointValue: 0,
          ),
          startPosition: deckPosition,
          targetPosition: target,
        ),
      );
    }
    _dealingController?.dispose();
    _dealingController = AnimationController(
      duration: const Duration(milliseconds: 300), // Slightly longer for better visibility
      vsync: this,
    );

    _dealingAnimation = CurvedAnimation(
      parent: _dealingController!,
      curve: Curves.easeInOut,
    );
    _dealingController!.addStatusListener((status) {
      if (!mounted) return;

      if (status == AnimationStatus.completed) {
        if (pointGameProvider.dealingCurrentCardIndexNotifier < _dealingAnimatedCards.length - 1) {
          pointGameProvider.setDealingCurrentCardIndexNotifier(pointGameProvider.dealingCurrentCardIndexNotifier + 1);
          _dealingController!.reset();
          _dealingController!.forward();
        } else {
          pointGameProvider.setIsDealing(false);
          
          // Emit my-card event at the end of dealing phase
          final user = Provider.of<AuthViewModel>(context, listen: false).user;
          if (user != null && _socketService.isConnected) {
            _socketService.emitMyCard(user.id.toString(), user.token.toString());
            debugPrint('[DEALING] Emitted my-card event at end of dealing phase');
          }
          
          Future.delayed(const Duration(milliseconds: 500), () {
            _checkIfReadyForPlayingPhase(); // Only check here
          });
        }
      }
    });
    _dealingController!.forward();
  }

  void _checkIfReadyForPlayingPhase() {
    if (!pointGameProvider.isDealing && pointGameProvider.myCardReceivedNotifier) {
      _transitionToPhase(GamePhase.playing);
      _initializeForRevealHand();
      _revealMainPlayerHandSequentially();
    } else {
      debugPrint('[PHASE CHECK] Conditions not met yet - dealing: ${!pointGameProvider.isDealing}, myCard: ${pointGameProvider.myCardReceivedNotifier}');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<PointGameProvider>(
      // valueListenable: _gamePhaseNotifier,
      builder: (context, provider, _) {
        Widget mainTable = Stack(
          children: [
            Image.asset(
              'assets/dashboard_bg.png',
              fit: BoxFit.cover,
              width: double.infinity,
              height: double.infinity,
              color: const Color(0xFFF51925).withOpacity(0.5),
              colorBlendMode: BlendMode.dstOver,
            ),
            Padding(
              padding: const EdgeInsets.only(top: 10.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(width: 20),
                  IconButton(
                    icon: Icon(Icons.menu, color: Colors.amber, size: 30),
                    onPressed: () {
                      debugPrint('Menu tapped');
                    },
                  ),
                  SizedBox(width: 40),
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.6),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.amber),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'Deals (2)',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                          SizedBox(width: 20),
                          Text(
                            ':',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(width: 20),
                          Consumer<PointGameProvider>(
                            builder: (context, provider, child) {
                              return Text(
                                'Entry : ${provider.entryLevel}',
                                style: TextStyle(
                                  color: Colors.red[200],
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                                overflow: TextOverflow.ellipsis,
                              );
                            },
                          ),
                          SizedBox(width: 20),
                          Text(
                            'Round(s) : 0',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                          SizedBox(width: 20),
                          Consumer<PointGameProvider>(
                            builder: (context, provider, child) {
                              return Text(
                                '₹ ${provider.pointValue.toStringAsFixed(2)}',
                                style: TextStyle(
                                  color: Colors.red[200],
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                                overflow: TextOverflow.ellipsis,
                              );
                            },
                          ),
                          SizedBox(width: 20),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(width: 40),
                  IconButton(
                    icon: Icon(Icons.settings, color: Colors.amber, size: 30),
                    onPressed: () {
                      final user =
                          Provider.of<AuthViewModel>(
                            context,
                            listen: false,
                          ).user;
                      if (user != null && _socketService.isConnected) {
                        _socketService.leaveTable(
                          user.id.toString(),
                          user.token.toString(),
                          gameId: provider.gameId.toString(),
                        );
                      }
                    },
                  ),
                ],
              ),
            ),

            // Table and player profiles
            Positioned(
              left: 0,
              right: 0,
              top: screenHeight * 0.15,
              child: Image.asset('assets/game_table2.png', fit: BoxFit.contain),
            ),


            if (provider.gamePhase == GamePhase.playing) ...[
              ///  Showing Wild  CARD...
              Positioned(
                left: deckLeft - cardWidth,
                top: screenHeight * 0.25 + cardHeight * 0.5,
                child: Transform.rotate(
                  angle: -math.pi / 2,
                  child: Builder(
                    builder: (context) {
                      if (widget.gameModel.wildCardRank == null) {
                        return const SizedBox.shrink();
                      }
                      final wildCardCode = widget.gameModel.wildCardRank!;
                      final suitMap = {
                        'RP': 'hearts',
                        'BP': 'spades',
                        'BL': 'clubs',
                        'RS': 'diamonds',
                      };
                      final suitCode =
                          wildCardCode.substring(0, 2).toUpperCase();
                      final suit = suitMap[suitCode] ?? suitCode.toLowerCase();
                      String wildRankBase =
                          wildCardCode.length > 2
                              ? wildCardCode.substring(2).replaceAll('j', '')
                              : '';
                      String mappedRank = _mapRankForAsset(wildRankBase);
                      String wildDisplayRank =
                          '${mappedRank}j';
                      final tableWildCard = Card(
                        suit: suit,
                        rank: wildDisplayRank,
                        isWild: true,
                        isJoker: false,
                        pointValue: 0,
                      );

                      print(
                        'Wild Card: suit=${tableWildCard.suit}, rank=${tableWildCard.rank} (for display)',
                      );
                      return CardWidget(
                        card: tableWildCard,
                        width: cardWidth,
                        height: cardHeight,
                      );
                    },
                  ),
                ),
              ),

              /// Closed deck
              Positioned(
                left: deckLeft,
                top: screenHeight * 0.33,
                child: Column(
                  children: [
                    GestureDetector(
                      onTap:
                          _canDraw()
                              ? () async {
                                final user =
                                    Provider.of<AuthViewModel>(
                                      context,
                                      listen: false,
                                    ).user!;
                                if (_socketService.isConnected) {
                                  // Emit the get-card event and wait for response
                                  _socketService.emitGetCard(
                                    user.id.toString(),
                                    user.token.toString(),

                                  );

                                  // Don't start animation here - wait for server response
                                  // The animation will be handled in the coordinator's handleGetCardData
                                  debugPrint('[DRAW] Emitted get-card event, waiting for response');
                                }
                              }
                              : null,
                      child: CardWidget(
                        isFaceUp: false,
                        width: cardWidth,
                        height: cardHeight,
                      ),
                    ),
                    const SizedBox(height: 5),
                    const Text(
                      'Closed Deck',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),

              /// Open deck
              Positioned(
                left: discardLeft,
                top: screenHeight * 0.33,
                child: Column(
                  children: [
                    Stack(
                      children: [
                        for (
                          int i = 0;
                          i < widget.gameModel.discardPile.length;
                          i++
                        )
                          Positioned(
                            left: (i % 3) * 5.0,
                            top: (i ~/ 3) * 5.0,
                            child: Transform.rotate(
                              angle: (i % 3) * 0.05,
                              child: CardWidget(
                                card: widget.gameModel.discardPile[i],
                                width: cardWidth,
                                height: cardHeight,
                              ),
                            ),
                          ),
                        if (widget.gameModel.discardPile.isNotEmpty)
                          GestureDetector(
                            onTap:
                                _canDraw()
                                    ? () async {
                                      final user =
                                          Provider.of<AuthViewModel>(
                                            context,
                                            listen: false,
                                          ).user!;
                                      if (_socketService.isConnected) {
                                        _socketService.emitGetDropCard(
                                          user.id.toString(),
                                          user.token.toString(),

                                        );

                                        // Don't start animation here - wait for server response
                                        // The animation will be handled in the coordinator's handleGetCardData
                                        debugPrint('[DRAW_DISCARD] Emitted get-drop-card event, waiting for response');
                                      }
                                    }
                                    : null,
                            child: CardWidget(
                              card: widget.gameModel.discardPile.last,
                              width: cardWidth,
                              height: cardHeight,
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 5),
                    const Text(
                      'Open Deck',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),

              /// NEW PLAYER HAND...///
              if (provider.gamePhase == GamePhase.dealing || provider.gamePhase == GamePhase.playing)
                Consumer<PointGameProvider>(
                  builder: (context, provider, _) {
                    if (provider.isDealing) {
                      return const SizedBox.shrink();
                    }
                    else if (!provider.myCardReceivedNotifier) {
                      return _buildPlaceholderHand();
                    }
                    else {
                      return Positioned(
                left: userCardsLeft,
                top: userCardsTop,
                child: Container(
                  height: cardHeight * 1.5,
                          child: PlayerHandWidget(
                            onCardTap: _handleCardTap,
                            onCardDropped: _handleCardDrop,
                                    cardWidth: cardWidth,
                                    cardHeight: cardHeight,
                          ),
                        ),
                      );
                    }
                  },
                ),

              // Action buttons
              Positioned(
                left: screenWidth * 0.05,
                top: screenHeight * 0.87,
                child: Container(
                  width: screenWidth * 0.9,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.6),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.amber),
                  ),
                  child: Row(
                    children: [
                      ///LAST DEAL BTN..
                      // ElevatedButton(
                      //   style: ElevatedButton.styleFrom(
                      //     backgroundColor: Colors.amber,
                      //     foregroundColor: Colors.black,
                      //     shape: RoundedRectangleBorder(
                      //       borderRadius: BorderRadius.circular(10),
                      //     ),
                      //     elevation: 8,
                      //   ),
                      //   onPressed: () => debugPrint('Last Deal tapped'),
                      //   child: const Text(
                      //     'Last Deal',
                      //     style: TextStyle(
                      //       fontSize: 16,
                      //       fontWeight: FontWeight.bold,
                      //       color: Colors.white,
                      //     ),
                      //   ),
                      // ),
                      // const SizedBox(width: 10),
                      ElevatedButton(
                        onPressed:
                            provider.selectedCards.length > 1 &&
                                    provider.cardGroups.length < 6
                                ? _groupCards
                                : null,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.amber,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          elevation: 8,
                        ),
                        child: const Text(
                          'Group',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      ElevatedButton(
                        onPressed: () async {
                          try {
                            final user =
                                Provider.of<AuthViewModel>(
                                  context,
                                  listen: false,
                                ).user;
                            if (user != null && _socketService.isConnected) {
                              _socketService.leaveTable(
                                user.id.toString(),
                                user.token.toString(),
                                gameId: provider.gameId.toString(),
                              );
                            }
                            Navigator.pushReplacement(
                              context,
                              customSlideTransition(
                                PointGameDashboard(
                                  socketService: widget.socketService,
                                ),
                              ),
                            );
                          } catch (e) {
                            print(e);
                          }
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.amber,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          elevation: 8,
                        ),
                        child: const Text(
                          'Drop',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      const Spacer(),
                      ElevatedButton(
                        onPressed:
                            widget.gameModel.currentTurn == 0 &&
                                    widget.gameModel.currentTurnPhase ==
                                        TurnPhase.discarding &&
                                    provider.selectedCards.length == 1 &&
                                    provider.animationAction ==
                                        AnimationAction.none
                                ? () async {
                                  try {
                                    final selectedCard =
                                        provider.selectedCards.first;
                                    if (_socketService.isConnected) {
                                      _socketService.discardCard(selectedCard);
                                    }
                                    _discardCardAnimation(selectedCard);
                                  } catch (e) {}
                                }
                                : null,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.amber,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          elevation: 8,
                        ),
                        child: const Text(
                          'Discard',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Visibility(
                        visible: provider.useGroupSort,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.amber,
                            foregroundColor: Colors.black,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            elevation: 8,
                          ),
                          onPressed: () {
                            provider.setUseGroupSort(true);
                            _sortPlayerHand();
                          },
                          child: const Text(
                            'Sort',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Consumer<PointGameProvider>(
                        builder: (context, provider, _) {
                          return ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor:
                                  provider.canDeclare ? Colors.green : Colors.grey,
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                              elevation: provider.canDeclare ? 8 : 2,
                            ),
                            onPressed:
                                provider.canDeclare
                                    ? () {
                                      debugPrint('Declare button pressed');
                                    }
                                    : null,
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  provider.canDeclare
                                      ? Icons.check_circle
                                      : Icons.cancel,
                                  size: 16,
                                ),
                                const SizedBox(width: 4),
                                const Text(
                                  'Declare',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),
              Consumer<PointGameProvider>(
                builder: (context, provider, _) {
                  final card = provider.draggingCard;
                  if (card == null ||
                      provider.animationStart == null ||
                      provider.animationEnd == null) {
                    return const SizedBox.shrink();
                  }
                  final animatingCard = card;
                  return TweenAnimationBuilder<Offset>(
                    tween: Tween<Offset>(
                      begin: provider.animationStart!,
                      end: provider.animationEnd!,
                    ),
                    duration: const Duration(milliseconds: 500),
                    curve: Curves.easeInOut,
                    builder: (context, offset, child) {
                      return Positioned(
                        left: offset.dx,
                        top: offset.dy,
                        child: CardWidget(
                          card: animatingCard,
                          width: cardWidth,
                          height: cardHeight,
                        ),
                      );
                    },
                    onEnd: () {
                      setState(() {
                        if (provider.animationAction == AnimationAction.draw) {
                          if (provider.cardGroups.isEmpty) {
                            pointGameProvider.updateCardGroups([[animatingCard]]);
                          } else {
                            final groups = List<List<Card>>.from(provider.cardGroups);
                            groups.last.add(animatingCard);
                            pointGameProvider.updateCardGroups(groups);
                          }
                        } else if (provider.animationAction ==
                            AnimationAction.discard) {
                          widget.gameModel.playerDiscardCard(0, animatingCard);
                          widget.gameModel.currentTurnPhase = TurnPhase.drawing;
                          _advanceTurn();
                        }
                        pointGameProvider.setDraggingCard(null);
                        pointGameProvider.setAnimationStart(null);
                        pointGameProvider.setAnimationEnd(null);
                        pointGameProvider.setAnimationAction(AnimationAction.none);
                        pointGameProvider.setDiscardSourceGroupIndex(null);
                        pointGameProvider.setDiscardSourceCardIndex(null);
                      });
                    },
                  );
                },
              ),
              Consumer<PointGameProvider>(
                builder: (context, provider, _) {
                  if (provider.draggingCard != null &&
                      provider.draggingCardOffset != null) {
                    return Positioned(
                      left: provider.draggingCardOffset!.dx,
                      top: provider.draggingCardOffset!.dy,
                      child: CardWidget(
                        card: provider.draggingCard!,
                        width: cardWidth,
                        height: cardHeight,
                      ),
                    );
                  }
                  return const SizedBox.shrink();
                },
              ),
            ],
            _buildMainPlayerProfile(),
          ],
        );
        // Use unified GamePhaseOverlay for all phases
        final gamePhaseOverlay = GamePhaseOverlay(
          gameModel: widget.gameModel,
              cardWidth: cardWidth,
              cardHeight: cardHeight,
              playerPositions: playerPositions[expectedPlayerCount] ?? [],
              onDealingComplete: () {
                pointGameProvider.setIsDealingNotifier(false);
                _checkIfReadyForPlayingPhase();
              },
          isTimerActiveFor: isTimerActiveFor,
                  cachedPositions: pointGameProvider.cachedPositions,
        );

        return Scaffold(
          resizeToAvoidBottomInset: false,
          body: Stack(
            children: [
              mainTable,
              gamePhaseOverlay,
            ],
          ),
        );
      },
    );
  }

  // Widget _buildWaitingRoom() {
  //   final int nPlayers = expectedPlayerCount;
  //   List<Widget> profileWidgets = [];
  //   for (var seat = 2; seat <= nPlayers; seat++) {
  //     final pos = _getPlayerOffset(seat);
  //     Widget profileWidget = _buildPlaceholderProfile(seat);
  //     profileWidgets.add(
  //       Positioned(left: pos.dx, top: pos.dy, child: profileWidget),
  //     );
  //   }
  //   return Stack(
  //     children: [
  //       ...profileWidgets,
  //       Positioned.fill(
  //         child: Container(
  //           color: Colors.black.withOpacity(0.65),
  //           child: Center(
  //             child: Column(
  //               mainAxisAlignment: MainAxisAlignment.center,
  //               children: [
  //                 RotatingIconsLoader(size: 30, spacing: 0),
  //                 const SizedBox(height: 8),
  //                 ValueListenableBuilder<int>(
  //                   valueListenable: _entryLevel,
  //                   builder: (context, entryLevel, child) {
  //                     return Text(
  //                       'Waiting for $entryLevel more players...',
  //                       style: const TextStyle(
  //                         color: Colors.amber,
  //                         fontSize: 14,
  //                       ),
  //                     );
  //                   },
  //                 ),
  //               ],
  //             ),
  //           ),
  //         ),
  //       ),
  //     ],
  //   );
  // }

  // Widget _buildLoadingIndicator() {
  //   return Center(
  //     child: Column(
  //       mainAxisAlignment: MainAxisAlignment.center,
  //       children: [
  //         RotatingIconsLoader(size: 30, spacing: 0),
  //         SizedBox(height: 16),
  //         Text('Starting game...'),
  //       ],
  //     ),
  //   );
  // }

  // Widget _buildResultDialog() {
  //   // Placeholder for result dialog
  //   return Center(child: Text('Game result!'));
  // }

  void _handleStartGameResponse(data) {
    try {
      if (data is String) {
        data = jsonDecode(data);
      }
      if (data['code'] == 200) {
        pointGameProvider.setGameId(data['game_id']);
        
        // Emit my-card event after receiving start-game response
        final user = Provider.of<AuthViewModel>(context, listen: false).user;
        if (user != null && _socketService.isConnected) {
          _socketService.emitMyCard(user.id.toString(), user.token.toString());
          debugPrint('[START GAME] Emitted my-card event after start-game response');
        }
        
        setState(() {
          _transitionToPhase(GamePhase.dealing);
        });
      } else {
        _showErrorDialog(data['message'] ?? 'Failed to start game');
      }
    } catch (e) {
      _showErrorDialog('Error processing game start: $e');
    }
  }

  void _initializeGameForPlaying() {
    if (widget.gameModel.playersHands.isEmpty) {
      widget.gameModel.playersHands = List.generate(2, (index) => <Card>[]);
    }
    pointGameProvider.setCurrentTurnIndex(widget.gameModel.currentTurn);
    pointGameProvider.setShowLoading(false);
  }
  void _showErrorDialog(String message) {
    if (!mounted) return;
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('Error'),
            content: Text(message),
            actions: [
              TextButton(
                onPressed: () {
                  final user =
                      Provider.of<AuthViewModel>(context, listen: false).user;
                  if (user != null && _socketService.isConnected) {
                    _socketService.leaveTable(
                      user.id.toString(),
                      user.token.toString(),
                      gameId: pointGameProvider.gameId.toString(),
                    );
                  }
                  Navigator.pop(context);
                  Navigator.pop(context);
                },
                child: const Text('OK'),
              ),
            ],
          ),
    );
  }

  void _leaveTable() {
    final user = Provider.of<AuthViewModel>(context, listen: false).user;
    if (user == null) return;
    if (_socketService.isConnected) {
      _socketService.leaveTable(user.id.toString(), user.token.toString());
    }
    _socketService.onLeaveTableResponse = (data) {
      if (data is String) data = jsonDecode(data);
      if (data['code'] == 200) {
        setState(() {
          _transitionToPhase(GamePhase.waiting);
          pointGameProvider.updateCardGroups([]);
        });
        pointGameProvider.setGameId(null);
        print('Successfully left the table');
      } else {
        _showErrorDialog(data['message'] ?? 'Failed to leave table');
      }
    };
  }

  @override
  Future<bool> onWillPop() async {
    _leaveTable();
    return false;
  }

  int get _currentPlayerCount {
    if (pointGameProvider.playersBySeat.isNotEmpty) {
      return pointGameProvider.playersBySeat.length;
    }
    return playerPositions.keys.contains(widget.gameModel.playersHands.length)
        ? widget.gameModel.playersHands.length
        : 2;
  }

  Offset getPlayerOffset(int seat) {
    final positions =
        playerPositions[_currentPlayerCount] ?? playerPositions[2]!;
    print(
      "Trying to get position for seat: $seat, player count: $_currentPlayerCount",
    );

    if (_currentPlayerCount == 2) {
      // Defensive: use seat==2 for 2-player opponent
      if (seat == 1) {
        return Offset(
          screenWidth / 2 - 34,
          screenHeight * 0.82,
        ); // main player bottom center
      }
      if (seat == 2) {
        return positions[0]; // opponent top center
      }
    } else {
      // Defensive for 6-player (or other >2-player): valid seats 2-6
      if (seat == 1) {
        return Offset(screenWidth / 2 - 34, screenHeight * 0.82);
      }
      if (seat >= 2 && seat <= 6) {
        final index = seat - 2;
        if (index >= 0 && index < positions.length) {
          return positions[index];
        } else {
          print(
            "Warning: seat=$seat maps to out of range index $index for positions length ${positions.length}",
          );
        }
      } else {
        print(
          "Warning: seat=$seat is out of valid range for player count $_currentPlayerCount",
        );
      }
    }
    // Default fallback: Player bottom center
    return Offset(screenWidth / 2 - 34, screenHeight * 0.82);
  }

  // Unified player profiles overlay for all phases (shows all seats, main player first)
  void _transitionToPhase(GamePhase newPhase) {
    if (!mounted) return;
    
    final pointGame = Provider.of<PointGameProvider>(context, listen: false);
    final currentPhase = pointGame.gamePhase;

    debugPrint('[PHASE TRANSITION] $currentPhase → $newPhase');
    
    // Use the centralized phase handler
    GamePhaseHandler.handlePhaseTransition(newPhase, context);
    
    // Handle lobby-specific logic after phase transition
    if (newPhase == GamePhase.waiting) {
      _startWaitingTimeout();
    } else if (currentPhase == GamePhase.waiting && newPhase != GamePhase.waiting) {
      _cancelWaitingTimeout();
    }
    
    // Start loading phase when transitioning to loading
    if (newPhase == GamePhase.loading) {
      startLoading();
    }
  }



  // Helper: Deep equality for List<Card>
  bool _areHandsEqual(List<Card> a, List<Card> b) {
    if (a.length != b.length) return false;
    for (int i = 0; i < a.length; i++) {
      if (a[i] != b[i]) return false;
    }
    return true;
  }


  bool isTimerActiveFor(String? userId) {
    final pointGame = Provider.of<PointGameProvider>(context, listen: false);
    return pointGame.gamePhase == GamePhase.playing &&
        pointGameProvider.currentChaalUserId == userId;
  }

  // Helper: Check if all players have joined, then move to loading phase
  Widget _buildPlaceholderHand() {
  return Positioned(
    left: userCardsLeft,
    top: userCardsTop,
    child: SizedBox(
      width: 13 * (cardWidth * 0.6) + cardWidth,
      height: cardHeight * 1.5,
      child: Stack(
        children: List.generate(13, (index) {
          return Positioned(
            left: index * (cardWidth * 0.6),
          top: 8,
                child: CardWidget(
              card: Card(
                suit: 'unknown',
                rank: 'back',
                isWild: false,
                isJoker: false,
                pointValue: 0,
              ),
              isFaceUp: false,
              width: cardWidth,
              height: cardHeight,
            ),
          );
        }),
          ),
        ),
      );
    }

  void _handleCardTap(Card card, int groupIndex) {
    setState(() {
      pointGameProvider.toggleSelectedCard(card);
    });
  }

void _handleCardDrop(Card card, int sourceGroup, int targetGroup, int insertIndex) {
  _moveCard(card, sourceGroup, targetGroup, insertIndex);
}

  // Add timeout management for waiting phase
  Timer? _waitingTimeoutTimer;
  static const Duration _waitingTimeout = Duration(minutes: 5); // 5 minutes timeout

  void _startWaitingTimeout() {
    _waitingTimeoutTimer?.cancel();
    _waitingTimeoutTimer = Timer(_waitingTimeout, () {
      if (mounted && pointGameProvider.gamePhase == GamePhase.waiting) {
        _handleWaitingTimeout();
      }
    });
  }

  void _handleWaitingTimeout() {
    debugPrint('[WAITING] Timeout reached, showing error dialog');
    _showErrorDialog('Waiting timeout reached. Please try again.');
    // Optionally return to dashboard
    Navigator.pop(context);
  }

  void _cancelWaitingTimeout() {
    _waitingTimeoutTimer?.cancel();
    _waitingTimeoutTimer = null;
  }

  void _setupSocketConnection() {
    try {
      if (!_socketService.isConnected) {
        final userId = pointGameProvider.cachedUser?.id?.toString() ?? '';
        if (userId.isNotEmpty) {
          _socketService.connect(userId);
          debugPrint('[SOCKET] Attempting to connect with userId: $userId');
        } else {
          debugPrint('[SOCKET] No valid user ID for connection');
          _showErrorDialog('User authentication error. Please login again.');
          return;
        }
      }
      
      // Start waiting timeout when entering waiting phase
      if (pointGameProvider.gamePhase == GamePhase.waiting) {
        _startWaitingTimeout();
      }
      
    } catch (e) {
      debugPrint('[SOCKET] Connection error: $e');
      _showErrorDialog('Failed to connect to game server. Please check your internet connection.');
    }
  }

}


