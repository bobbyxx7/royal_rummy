
import '../../Model/Cards_Model.dart';

List<List<Card>> addGroup(List<Card> selectedCards, List<List<Card>> currentGroups) {
  final updatedGroups = List<List<Card>>.from(currentGroups)..add(selectedCards);
  return updatedGroups;
}