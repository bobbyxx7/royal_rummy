// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import 'package:arka_infotech/provider/pointGameProvider.dart';
//
// import '../../../../../components/Animations.dart';
//
//
// /// Enhanced waiting room that matches the design requirements
// class EnhancedWaitingRoom extends StatefulWidget {
//   final Offset Function(int seat) getPlayerOffset;
//   final Widget Function(int seat) buildPlayerProfile;
//
//   const EnhancedWaitingRoom({
//     Key? key,
//     required this.getPlayerOffset,
//     required this.buildPlayerProfile,
//   }) : super(key: key);
//
//   @override
//   State<EnhancedWaitingRoom> createState() => _EnhancedWaitingRoomState();
// }
//
// class _EnhancedWaitingRoomState extends State<EnhancedWaitingRoom>
//     with TickerProviderStateMixin {
//   late AnimationController _pulseController;
//   late AnimationController _joinAnimationController;
//   Map<int, bool> _playerJoinAnimations = {};
//
//   @override
//   void initState() {
//     super.initState();
//     _pulseController = AnimationController(
//       duration: const Duration(seconds: 2),
//       vsync: this,
//     )..repeat(reverse: true);
//
//     _joinAnimationController = AnimationController(
//       duration: const Duration(milliseconds: 800),
//       vsync: this,
//     );
//   }
//
//   @override
//   void dispose() {
//     _pulseController.dispose();
//     _joinAnimationController.dispose();
//     super.dispose();
//   }
//
//   void _triggerJoinAnimation(int seat) {
//     setState(() {
//       _playerJoinAnimations[seat] = true;
//     });
//
//     _joinAnimationController.forward().then((_) {
//       if (mounted) {
//         setState(() {
//           _playerJoinAnimations[seat] = false;
//         });
//       }
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Consumer<PointGameProvider>(
//       builder: (context, pointGameProvider, child) {
//         final expectedPlayerCount = pointGameProvider.expectedPlayerCount;
//         final waitingCount = pointGameProvider.entryLevel;
//         final playersBySeat = pointGameProvider.playersBySeat;
//
//         List<Widget> profileWidgets = [];
//
//         // Build player profiles for all expected seats
//         for (var seat = 2; seat <= expectedPlayerCount; seat++) {
//           final pos = widget.getPlayerOffset(seat);
//           final hasPlayer = playersBySeat[seat] != null &&
//               playersBySeat[seat]!['user_id'] != null &&
//               playersBySeat[seat]!['user_id'].toString() != '0';
//
//           Widget profileWidget = widget.buildPlayerProfile(seat);
//
//           // Add join animation if player just joined
//           if (hasPlayer && _playerJoinAnimations[seat] == true) {
//             profileWidget = AnimatedBuilder(
//               animation: _joinAnimationController,
//               builder: (context, child) {
//                 return Transform.scale(
//                   scale: 1.0 + (0.3 * _joinAnimationController.value),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       borderRadius: BorderRadius.circular(8),
//                       boxShadow: [
//                         BoxShadow(
//                           color: Colors.green.withOpacity(0.6),
//                           blurRadius: 10,
//                           spreadRadius: 2,
//                         ),
//                       ],
//                     ),
//                     child: profileWidget,
//                   ),
//                 );
//               },
//             );
//           }
//
//           profileWidgets.add(
//             Positioned(
//               left: pos.dx,
//               top: pos.dy,
//               child: profileWidget,
//             ),
//           );
//         }
//
//         return Stack(
//           children: [
//             // Player profile widgets
//             ...profileWidgets,
//
//             // Main waiting overlay
//             Positioned.fill(
//               child: Container(
//                 decoration: BoxDecoration(
//                   color: Colors.black.withOpacity(0.65),
//                   borderRadius: BorderRadius.circular(12),
//                 ),
//                 child: Center(
//                   child: Column(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//
//                       // Pulsing loading animation
//                       AnimatedBuilder(
//                         animation: _pulseController,
//                         builder: (context, child) {
//                           return Transform.scale(
//                             scale: 1.0 + (0.1 * _pulseController.value),
//                             child: RotatingIconsLoader(size: 30, spacing: 0),
//                           );
//                         },
//                       ),
//
//                       // const SizedBox(height: 16),
//                       //
//                       // // Dynamic waiting message
//                       // _buildWaitingMessage(waitingCount, expectedPlayerCount),
//                       //
//                       // const SizedBox(height: 20),
//                       //
//                       // // Progress indicator
//                       // _buildProgressIndicator(waitingCount, expectedPlayerCount),
//                     ],
//                   ),
//                 ),
//               ),
//             ),
//           ],
//         );
//       },
//     );
//   }
//
//   /// Build central card suit icons
//   // Widget _buildCardSuitIcons() {
//   //   return Row(
//   //     mainAxisAlignment: MainAxisAlignment.center,
//   //     children: [
//   //       _buildSuitIcon('♠', Colors.red),
//   //       const SizedBox(width: 20),
//   //       _buildSuitIcon('♦', Colors.red),
//   //       const SizedBox(width: 20),
//   //       _buildSuitIcon('♣', Colors.red),
//   //       const SizedBox(width: 20),
//   //       _buildSuitIcon('♥', Colors.red),
//   //     ],
//   //   );
//   // }
//   //
//   // /// Build individual suit icon
//   // Widget _buildSuitIcon(String suit, Color color) {
//   //   return Container(
//   //     width: 40,
//   //     height: 40,
//   //     decoration: BoxDecoration(
//   //       color: Colors.transparent,
//   //       border: Border.all(color: Colors.white, width: 1),
//   //       borderRadius: BorderRadius.circular(8),
//   //     ),
//   //     child: Center(
//   //       child: Text(
//   //         suit,
//   //         style: TextStyle(
//   //           color: color,
//   //           fontSize: 24,
//   //           fontWeight: FontWeight.bold,
//   //         ),
//   //       ),
//   //     ),
//   //   );
//   // }
//
//   /// Build waiting message
//   // Widget _buildWaitingMessage(int waitingCount, int expectedPlayerCount) {
//   //   final joinedCount = expectedPlayerCount - waitingCount;
//   //
//   //   if (waitingCount == 0) {
//   //     return const Text(
//   //       'All players joined! Starting game...',
//   //       style: TextStyle(
//   //         color: Colors.green,
//   //         fontSize: 16,
//   //         fontWeight: FontWeight.bold,
//   //       ),
//   //     );
//   //   }
//   //
//   //   return Column(
//   //     children: [
//   //       Text(
//   //         'Waiting for $waitingCount more player${waitingCount == 1 ? "" : "s"}...',
//   //         style: const TextStyle(
//   //           color: Colors.amber,
//   //           fontSize: 16,
//   //           fontWeight: FontWeight.bold,
//   //         ),
//   //       ),
//   //       const SizedBox(height: 8),
//   //       Text(
//   //         '$joinedCount of $expectedPlayerCount players joined',
//   //         style: const TextStyle(
//   //           color: Colors.white70,
//   //           fontSize: 12,
//   //         ),
//   //       ),
//   //     ],
//   //   );
//   // }
//
//   /// Build progress indicator
//   // Widget _buildProgressIndicator(int waitingCount, int expectedPlayerCount) {
//   //   final progress = (expectedPlayerCount - waitingCount) / expectedPlayerCount;
//   //
//   //   return Container(
//   //     width: 200,
//   //     height: 6,
//   //     decoration: BoxDecoration(
//   //       color: Colors.grey[800],
//   //       borderRadius: BorderRadius.circular(3),
//   //     ),
//   //     child: FractionallySizedBox(
//   //       alignment: Alignment.centerLeft,
//   //       widthFactor: progress,
//   //       child: Container(
//   //         decoration: BoxDecoration(
//   //           color: Colors.green,
//   //           borderRadius: BorderRadius.circular(3),
//   //         ),
//   //       ),
//   //     ),
//   //   );
//   // }
// }
