class DeclareRules {
  final List<int> groupValueList;
  static const int impureSequenceValue = 4;
  static const int pureSequenceValue = 5;
  static const int setValue = 6;

  DeclareRules(this.groupValueList);

  bool isRuleMatch() {
    bool isRulesMatch = false;
    int isPureOrImpureSeq = 0;

    for (int value in groupValueList) {
      if ((value == impureSequenceValue || value == pureSequenceValue) && isPureOrImpureSeq == 0) {
        isPureOrImpureSeq = value;
      } else if (isPureOrImpureSeq == pureSequenceValue) {
        if (value == pureSequenceValue || value == impureSequenceValue) {
          isRulesMatch = true;
        }
      } else if (isPureOrImpureSeq == impureSequenceValue) {
        if (value == pureSequenceValue) {
          isRulesMatch = true;
        }
      }
    }

    return isRulesMatch;
  }
}