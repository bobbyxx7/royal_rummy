import 'package:flutter/material.dart';
Widget buildGroupRibbon(label) {
    // if (groupIndex >= _groupLabels.length) return const SizedBox.shrink();
    // final label = _groupLabels[groupIndex];
    Color labelColor;
    IconData? icon;
    String displayText = label;
    String pointsText = '';

    // Determine styling and points for group type
    if (label.startsWith('Pure Sequence')) {
      labelColor = Colors.green;
      icon = Icons.check_circle;
      displayText = 'Pure Sequence';
    } else if (label.startsWith('Impure Sequence')) {
      labelColor = Colors.orange;
      icon = Icons.check_circle_outline;
      displayText = 'Impure Sequence';
    } else if (label.startsWith('Set')) {
      labelColor = Colors.blue;
      icon = Icons.grid_on;
      displayText = 'Set';
    } else if (label.startsWith('Invalid')) {
      labelColor = Colors.red;
      icon = Icons.cancel;
      // Extract points from label, e.g. 'Invalid (hearts, 10 pts)' or 'Invalid (10 pts)'
      final reg = RegExp(r'Invalid.*?(\d+) pts');
      final match = reg.firstMatch(label);
      if (match != null) {
        pointsText = '${match.group(1)} pts';
      }
      displayText = 'Invalid';
    } else {
      labelColor = Colors.amber;
      icon = Icons.help_outline;
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        return Center(
          child: Container(
            constraints: BoxConstraints(maxWidth: constraints.maxWidth - 8),
            margin: const EdgeInsets.only(top: 2, left: 2, right: 2),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(
              color: labelColor.withOpacity(0.85),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: labelColor, width: 1),
              boxShadow: [
                BoxShadow(
                  color: labelColor.withOpacity(0.3),
                  blurRadius: 6,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, color: Colors.white, size: 14),
                const SizedBox(width: 4),
                Flexible(
                  child: Text(
                    displayText,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                if (pointsText.isNotEmpty) ...[
                  const SizedBox(width: 6),
                  Flexible(
                    child: Text(
                      pointsText,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w500,
                        fontSize: 11,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }


Widget buildGroupLabel(label) {
  // if (groupIndex >= _groupLabels.length) return const SizedBox.shrink();
  //
  // final label = _groupLabels[groupIndex];
  Color labelColor;
  IconData? icon;
  String displayText = label;
  if (label.startsWith('Pure Sequence')) {
    labelColor = Colors.green;
    icon = Icons.check_circle;
    displayText = 'Pure Sequence';
  } else if (label.startsWith('Impure Sequence')) {
    labelColor = Colors.orange;
    icon = Icons.check_circle_outline;
    displayText = 'Impure Sequence';
  } else if (label.startsWith('Set')) {
    labelColor = Colors.blue;
    icon = Icons.grid_on;
    displayText = 'Set';
  } else if (label.startsWith('Invalid')) {
    labelColor = Colors.red;
    icon = Icons.cancel;
  } else {
    labelColor = Colors.amber;
    icon = Icons.help_outline;
  }

  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
    decoration: BoxDecoration(
      color: labelColor.withOpacity(0.2),
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: labelColor, width: 1),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        ...[
        Icon(icon, color: labelColor, size: 12),
        const SizedBox(width: 4),
      ],
        Text(
          displayText,
          style: TextStyle(
            color: labelColor,
            fontWeight: FontWeight.bold,
            fontSize: 11,
          ),
        ),
      ],
    ),
  );
}