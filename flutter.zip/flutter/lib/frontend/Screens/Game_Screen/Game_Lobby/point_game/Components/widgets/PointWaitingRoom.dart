import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:arka_infotech/provider/pointGameProvider.dart';
import '../../../../../components/Animations.dart';

/// Simple, reactive waiting room that matches your old clean design
class SimpleWaitingRoom extends StatelessWidget {
  final Offset Function(int seat) getPlayerOffset;
  final Widget Function(int seat) buildPlayerProfile;

  const SimpleWaitingRoom({
    Key? key,
    required this.getPlayerOffset,
    required this.buildPlayerProfile,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<PointGameProvider>(
      builder: (context, provider, child) {
        final expectedPlayerCount = provider.expectedPlayerCount;
        final waitingCount = provider.entryLevel;
        
        List<Widget> profileWidgets = [];
        
        // Build player profiles for all expected seats
        for (var seat = 2; seat <= expectedPlayerCount; seat++) {
          final pos = getPlayerOffset(seat);
          Widget profileWidget = buildPlayerProfile(seat);
          
          profileWidgets.add(
            Positioned(
              left: pos.dx,
              top: pos.dy,
              child: profileWidget,
            ),
          );
        }

        return Stack(
          children: [
            // Player profile widgets
            ...profileWidgets,
            
            // Main waiting overlay - using your old clean design
            Positioned.fill(
              child: Container(
                color: Colors.black.withOpacity(0.65),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Rotating loader (from your old design)
                      RotatingIconsLoader(size: 30, spacing: 0),
                      const SizedBox(height: 8),
                      
                      // Reactive waiting message (from your old design)
                      Text(
                        'Waiting for $waitingCount more player${waitingCount == 1 ? "" : "s"}...',
                        style: const TextStyle(
                          color: Colors.amber,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}


/// TODO:  Need to include this  in playerProfile Overlay...
Widget buildSimplePlaceholderProfile(int seat) {
  return Column(
    children: [
      CircleAvatar(
        backgroundImage: AssetImage(
          seat == 1 ? 'assets/profile.png' : 'assets/default_profile.jpeg',
        ),
        radius: 30,
      ),
      const SizedBox(height: 4),
      const Text(
        'Waiting...',
        style: TextStyle(color: Colors.amber)
      ),
    ],
  );
}
