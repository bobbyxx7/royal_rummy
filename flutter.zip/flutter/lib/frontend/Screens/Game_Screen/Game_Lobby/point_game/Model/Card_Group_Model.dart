import 'Cards_Model.dart';

class CardGroupModel {
  List<Card> cards;
  String groupValue; // e.g., "Pure Sequence", "Set", "Invalid"
  int groupPoints;
  int valueGrp;

  CardGroupModel({
    required this.cards,
    this.groupValue = 'Invalid',
    this.groupPoints = 0,
    this.valueGrp = 0,
  });

  factory CardGroupModel.fromJson(Map<String, dynamic> json) {
    return CardGroupModel(
      cards: (json['cards'] as List).map((e) => Card.fromJson(e)).toList(),
      groupValue: json['group_value'] ?? 'Invalid',
      groupPoints: json['group_points'] ?? 0,
      valueGrp: json['value_grp'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'cards': cards.map((card) => card.toJson()).toList(),
      'group_value': groupValue,
      'group_points': groupPoints,
      'value_grp': valueGrp,
    };
  }
}