import '../Model/Cards_Model.dart';
import '../Model/Card_Group_Model.dart';

class GameLogicService {
  static GameLogicService? _instance;
  String wildCardRank = '';
  static const String invalid = 'Invalid';
  static const String impureSequence = 'Impure Sequence';
  static const String pureSequence = 'Pure Sequence';
  static const String set = 'Set';
  static const int impureSequenceValue = 4;
  static const int pureSequenceValue = 5;
  static const int setValue = 6;

  static GameLogicService getInstance() {
    _instance ??= GameLogicService();
    return _instance!;
  }

  void setWildCardRank(String rank) {
    wildCardRank = rank;
  }

  /// Enhanced card group evaluation based on Rummy rules
  CardGroupModel evaluateGroup(List<Card> cards) {
    if (cards.isEmpty) {
      return CardGroupModel(cards: [], groupValue: invalid, groupPoints: 0, valueGrp: 0);
    }

    int rule = 0;
    int groupSize = cards.length;
    CardGroupModel group = CardGroupModel(cards: cards);

    // Handle groups with 2 or fewer cards
    if (groupSize <= 2) {
      cards.sort((a, b) => _compareCards(a, b));
      group.groupValue = invalid;
      group.groupPoints = _getGroupPoints(cards);
      group.valueGrp = rule;
      return group;
    }

    // Sort cards by rank for better evaluation
    cards.sort((a, b) => _compareCards(a, b));

    // Extract card properties
    List<String> colors = cards.map((card) => card.suit ?? 'JK').toList();
    List<int> numbers = cards.map((card) => _getCardNumber(card)).toList();
    int jokerCount = cards.where((card) => card.isJoker || card.isWild).length;

    // Check for pure sequence (same suit, consecutive numbers, no jokers)
    if (_isPureSequence(colors, numbers, jokerCount)) {
      rule = pureSequenceValue;
      group.groupValue = pureSequence;
      group.groupPoints = 0;
      group.valueGrp = rule;
      return group;
    }

    // Check for set (same rank, different suits)
    if (_isSet(colors, numbers, jokerCount)) {
      rule = setValue;
      group.groupValue = set;
      group.groupPoints = 0;
      group.valueGrp = rule;
      return group;
    }

    // Check for impure sequence (same suit, consecutive numbers, can have jokers)
    if (_isImpureSequence(colors, numbers, jokerCount)) {
      rule = impureSequenceValue;
      group.groupValue = impureSequence;
      group.groupPoints = 0;
      group.valueGrp = rule;
      return group;
    }

    // Invalid group
    group.groupValue = invalid;
    group.groupPoints = _getGroupPoints(cards);
    group.valueGrp = rule;
    return group;
  }

  /// Check if cards form a pure sequence (same suit, consecutive, no jokers)
  bool _isPureSequence(List<String> colors, List<int> numbers, int jokerCount) {
    if (jokerCount > 0) return false; // Pure sequence cannot have jokers
    
    // All cards must be same suit
    if (!_isColorMatch(colors)) return false;
    
    // Check for consecutive numbers
    List<int> sortedNumbers = List.from(numbers)..sort();
    return _checkConsecutive(sortedNumbers);
  }

  /// Check if cards form a set (same rank, different suits)
  bool _isSet(List<String> colors, List<int> numbers, int jokerCount) {
    // Get non-joker numbers
    List<int> nonJokerNumbers = numbers.where((n) => n > 0).toList();
    List<String> nonJokerColors = colors.where((c) => c != 'JK').toList();
    
    // All non-joker cards must have same rank
    if (nonJokerNumbers.isEmpty || nonJokerNumbers.toSet().length != 1) return false;
    
    // All non-joker cards must have different suits
    if (nonJokerColors.toSet().length != nonJokerColors.length) return false;
    
    // Must have at least 3 cards total (including jokers)
    return numbers.length >= 3;
  }

  /// Check if cards form an impure sequence (same suit, consecutive, can have jokers)
  bool _isImpureSequence(List<String> colors, List<int> numbers, int jokerCount) {
    // Get non-joker colors and numbers
    List<String> nonJokerColors = colors.where((c) => c != 'JK').toList();
    List<int> nonJokerNumbers = numbers.where((n) => n > 0).toList();
    
    // All non-joker cards must be same suit
    if (nonJokerColors.isEmpty || !_isColorMatch(nonJokerColors)) return false;
    
    // Check if numbers can form sequence with jokers
    if (nonJokerNumbers.isEmpty) return jokerCount >= 3; // All jokers
    
    nonJokerNumbers.sort();
    return _checkSequenceWithJokers(nonJokerNumbers, jokerCount);
  }

  /// Check if numbers are consecutive
  bool _checkConsecutive(List<int> numbers) {
    for (int i = 1; i < numbers.length; i++) {
      if (numbers[i] != numbers[i - 1] + 1) return false;
    }
    return true;
  }

  /// Check if numbers can form sequence with jokers
  bool _checkSequenceWithJokers(List<int> numbers, int jokerCount) {
    if (numbers.length <= 1) return jokerCount >= 2; // Need at least 3 cards total
    
    // Check gaps between consecutive numbers
    int totalGaps = 0;
    for (int i = 1; i < numbers.length; i++) {
      int gap = numbers[i] - numbers[i - 1] - 1;
      if (gap < 0) return false; // Overlapping numbers
      totalGaps += gap;
    }
    
    // Jokers can fill gaps
    return totalGaps <= jokerCount;
  }

  /// Enhanced hand grouping algorithm
  List<CardGroupModel> groupAndLabelHand(List<Card> hand) {
    if (hand.isEmpty) return [];
    
    // First, try to group by existing user groups if available
    List<List<Card>> groups = _splitHandIntoUserGroups(hand);
    
    // If no user groups, use intelligent grouping
    if (groups.length <= 1) {
      groups = _intelligentGrouping(hand);
    }
    
    // Evaluate each group
    List<CardGroupModel> result = [];
    for (var group in groups) {
      if (group.isNotEmpty) {
        result.add(evaluateGroup(group));
      }
    }
    
    return result;
  }

  /// Split hand into user-defined groups
  List<List<Card>> _splitHandIntoUserGroups(List<Card> hand) {
    // This would use the existing _cardGroups from the UI
    // For now, return a single group
    return [hand];
  }

  /// Intelligent grouping algorithm
  List<List<Card>> _intelligentGrouping(List<Card> hand) {
    List<List<Card>> groups = [];
    
    // Separate jokers
    List<Card> jokers = hand.where((card) => card.isJoker || card.isWild).toList();
    List<Card> nonJokers = hand.where((card) => !card.isJoker && !card.isWild).toList();
    
    // Group by suit
    Map<String, List<Card>> suitGroups = {};
    for (var card in nonJokers) {
      final suit = card.suit ?? 'Unknown';
      suitGroups.putIfAbsent(suit, () => []).add(card);
    }
    
    // Try to form sequences within each suit
    for (var suitGroup in suitGroups.values) {
      if (suitGroup.length >= 3) {
        // Try to form sequences
        var sequences = _findSequencesInSuit(suitGroup, jokers);
        groups.addAll(sequences);
      } else {
        // Add as potential set candidates
        groups.add(suitGroup);
      }
    }
    
    // Try to form sets from remaining cards
    var remainingCards = <Card>[];
    for (var group in groups) {
      remainingCards.addAll(group);
    }
    
    var sets = _findSets(remainingCards, jokers);
    if (sets.isNotEmpty) {
      groups = sets;
    }
    
    // Add remaining cards as a single group (not one per card)
    var usedCards = <Card>{};
    for (var group in groups) {
      usedCards.addAll(group);
    }
    var unusedCards = hand.where((card) => !usedCards.contains(card)).toList();
    if (unusedCards.isNotEmpty) {
      groups.add(unusedCards);
    }
    return groups;
  }

  /// Find sequences within a suit
  List<List<Card>> _findSequencesInSuit(List<Card> suitCards, List<Card> jokers) {
    List<List<Card>> sequences = [];
    
    // Sort by rank
    suitCards.sort((a, b) => _compareCards(a, b));
    
    // Find consecutive sequences
    List<Card> currentSequence = [];
    for (int i = 0; i < suitCards.length; i++) {
      if (currentSequence.isEmpty) {
        currentSequence.add(suitCards[i]);
      } else {
        int lastRank = _getCardNumber(currentSequence.last);
        int currentRank = _getCardNumber(suitCards[i]);
        
        if (currentRank == lastRank + 1) {
          currentSequence.add(suitCards[i]);
        } else {
          if (currentSequence.length >= 3) {
            sequences.add(List.from(currentSequence));
          }
          currentSequence = [suitCards[i]];
        }
      }
    }
    
    if (currentSequence.length >= 3) {
      sequences.add(currentSequence);
    }
    
    return sequences;
  }

  /// Find sets (same rank, different suits)
  List<List<Card>> _findSets(List<Card> cards, List<Card> jokers) {
    Map<int, List<Card>> rankGroups = {};
    
    for (var card in cards) {
      int rank = _getCardNumber(card);
      rankGroups.putIfAbsent(rank, () => []).add(card);
    }
    
    List<List<Card>> sets = [];
    for (var rankGroup in rankGroups.values) {
      if (rankGroup.length >= 3) {
        sets.add(rankGroup);
      }
    }
    
    return sets;
  }

  /// Validate declare according to Rummy rules
  bool validateDeclare(List<CardGroupModel> groups) {
    int pureSeqCount = 0;
    int totalSeqCount = 0;
    
    for (var group in groups) {
      if (group.groupValue == pureSequence) {
        pureSeqCount++;
        totalSeqCount++;
      } else if (group.groupValue == impureSequence) {
        totalSeqCount++;
      }
    }
    
    // Need at least 1 pure sequence and 2 total sequences
    return pureSeqCount >= 1 && totalSeqCount >= 2;
  }

  bool _checkSequence(List<int> arr, int jokerCount) {
    for (int j = 0; j < arr.length - 1; j++) {
      int val = arr[j];
      if (val == 0) continue; // Skip jokers
      int cardGap = arr[j + 1] - (val + 1);
      if (cardGap >= 0 && cardGap <= jokerCount) {
        jokerCount -= cardGap;
      } else {
        return false;
      }
    }
    return true;
  }

  bool _isColorMatch(List<String> colors) {
    return colors.toSet().length == 1 && colors.first != 'JK';
  }

  bool _straightCard(List<int> numbers, int jokerCount) {
    List<int> sorted = List.from(numbers)..sort();
    return _checkSequence(sorted, jokerCount);
  }

  int _getGroupPoints(List<Card> cards) {
    return cards.fold(0, (sum, card) {
      if (card.isJoker || card.isWild) return sum;
      return sum + (card.pointValue > 10 ? 10 : card.pointValue);
    });
  }

  int _getCardNumber(Card card) {
    if (card.isJoker || card.isWild) return 0;
    return int.tryParse(card.rank.replaceAll('j', '')) ?? 10;
  }

  int _compareCards(Card a, Card b) {
    int valueA = _getCardNumber(a);
    int valueB = _getCardNumber(b);
    return valueA.compareTo(valueB);
  }
}