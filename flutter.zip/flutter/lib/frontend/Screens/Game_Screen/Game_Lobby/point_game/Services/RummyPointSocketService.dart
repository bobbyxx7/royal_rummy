import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart' hide Card;
import 'package:socket_io_client/socket_io_client.dart' as IO;
import '../Model/Cards_Model.dart';
import '../Model/Game_Model.dart';
import '../Model/Card_Group_Model.dart';
import '../../../../../../Constants/api_constants.dart';

enum SocketConnectionState { disconnected, connecting, connected, error }

class RummyPointSocketService {
  static RummyPointSocketService? _instance;
  IO.Socket? _socket;
  Timer? _reconnectTimer;
  bool _isConnecting = false;
  SocketConnectionState _connectionState = SocketConnectionState.disconnected;
  int _reconnectAttempts = 0;
  static const int maxReconnectAttempts = 5;

  // Event callbacks
  Function(GameModel)? onGameStateUpdate;
  Function(String, List<List<Card>>, String?, int)? onGameStart;
  Function(List<CardGroupModel>, String, int)? onGameResult;
  Function(String)? onError;
  Function(SocketConnectionState)? onConnectionStateChanged;
  Function(String)? onTableJoined;
  Function(String)? onPlayerJoined;
  Function(String)? onPlayerLeft;
  Function(int, String)? onTurnUpdate;
  Function(dynamic)? onGetTableResponse; // Add callback for getTable response
  Function(dynamic)? onStartGameResponse; // Add callback for getTable response
  Function(dynamic)? onJoinTableResponse; // Add callback for joinTable response
  Function(dynamic)? onLeaveTableResponse; // Add callback for leaveTable response
  Function(dynamic)? onPackGameResponse; // Add callback for packGame response
  Function(dynamic)? onDeclareResponse; // Add callback for declare response
  Function(dynamic)? onTrigger;
  Function(dynamic)? onStatus;
  Function(dynamic)? onGetCard;
  Function(dynamic)? onGetDropCard;
  Function(dynamic)? onMyCard;

  static RummyPointSocketService getInstance() {
    _instance ??= RummyPointSocketService._internal();
    return _instance!;
  }

  RummyPointSocketService._internal();

  bool get isConnected => _connectionState == SocketConnectionState.connected;
  SocketConnectionState get connectionState => _connectionState;

  Future<void> connect(String userId) async {
    if (_isConnecting || isConnected) return;

    _isConnecting = true;
    _updateConnectionState(SocketConnectionState.connecting);
    
    try { 
      _socket = IO.io(
        ApiConstants.socketUrl,
        IO.OptionBuilder()
            .setTransports(['websocket'])
            .setQuery({'userId': userId})
            .setTimeout(10000)
            .enableAutoConnect()
            .build(),
      );

      _setupEventListeners();
      _socket!.connect();

      // Wait for connection with timeout
              await Future.any([
          Future(() async {
            while (_connectionState != SocketConnectionState.connected) {
              await Future.delayed(const Duration(milliseconds: 100));
              if (_connectionState == SocketConnectionState.error) {
                throw Exception('Connection failed');
              }
            }
          }),
        Future.delayed(const Duration(seconds: 10), () {
          throw Exception('Connection timeout');
        }),
      ]);

      _isConnecting = false;
      _reconnectAttempts = 0;
      print('RummyPointSocket connected successfully');
    } catch (e) {
      _isConnecting = false;
      _updateConnectionState(SocketConnectionState.error);
      print('RummyPointSocket connection failed: $e');
      rethrow;
    }
  }

  void _updateConnectionState(SocketConnectionState state) {
    _connectionState = state;
    onConnectionStateChanged?.call(state);
  }

  void _setupEventListeners() {
    _socket?.onConnect((_) {
      print('RummyPointSocket connected');
      _updateConnectionState(SocketConnectionState.connected);
      _cancelReconnectTimer();
    });

    _socket?.onDisconnect((_) {
      print('RummyPointSocket disconnected');
      _updateConnectionState(SocketConnectionState.disconnected);
      _startReconnectTimer();
    });

    _socket?.onError((error) {
      print('RummyPointSocket error: $error');
      _updateConnectionState(SocketConnectionState.error);
      onError?.call(error.toString());
    });

    // Game-specific events with proper validation
    _socket?.on('start-game', (data) {
      print('Game started: $data');
      if (_validateEventData(data)) {
        onStartGameResponse?.call(data);
      }
    });

    _socket?.on('get-table', (data) {
      print('get-table response received: $data');
      if (_validateEventData(data)) {
        onGetTableResponse?.call(data);
      }
    });

    _socket?.on('leave-table', (data) {
      print('leave-table response received: $data');
      if (_validateEventData(data)) {
        onLeaveTableResponse?.call(data);
      }
    });

    _socket?.on('pack-game', (data) {
      print('pack-game response received: $data');
      if (_validateEventData(data)) {
        onPackGameResponse?.call(data);
      }
    });

    _socket?.on('declare', (data) {
      print('declare response received: $data');
      if (_validateEventData(data)) {
        onDeclareResponse?.call(data);
      }
    });

    _socket?.on('trigger', (data) {
      print('Trigger event received: $data');
      if (_validateEventData(data)) {
        onTrigger?.call(data);
      }
    });

    _socket?.on('status', (data) {
      print('Status event received: $data');
      if (_validateEventData(data)) {
        onStatus?.call(data);
      }
    });

    _socket?.on('get-card', (data) {
      print('get-card event received: $data');
      if (_validateEventData(data)) {
        onGetCard?.call(data);
      }
    });

    _socket?.on('get-drop-card', (data) {
      print('get-drop-card event received: $data');
      if (_validateEventData(data)) {
        onGetDropCard?.call(data);
      }
    });

    _socket?.on('my-card', (data) {
      print('my-card event received: $data');
      if (_validateEventData(data)) {
        onMyCard?.call(data);
      }
    });
  }

  bool _validateEventData(dynamic data) {
    if (data == null) {
      print('Warning: Received null event data');
      return false;
    }
    return true;
  }

  void _startReconnectTimer() {
    _cancelReconnectTimer();
          _reconnectTimer = Timer.periodic(const Duration(seconds: 5), (timer) {
        if (_connectionState == SocketConnectionState.disconnected && !_isConnecting) {
        if (_reconnectAttempts < maxReconnectAttempts) {
          _reconnectAttempts++;
          print('Attempting to reconnect... (Attempt $_reconnectAttempts/$maxReconnectAttempts)');
          _socket?.connect();
        } else {
          print('Max reconnection attempts reached');
          _cancelReconnectTimer();
          onError?.call('Failed to reconnect after $maxReconnectAttempts attempts');
        }
      }
    });
  }

  void _cancelReconnectTimer() {
    _reconnectTimer?.cancel();
    _reconnectTimer = null;
  }

  // Game actions with validation
  void joinTable(String userId, String token, String tableId) {
    if (!isConnected) {
      onError?.call('Not connected to server');
      return;
    }
    
    if (userId.isEmpty || token.isEmpty || tableId.isEmpty) {
      onError?.call('Invalid parameters for join table');
      return;
    }

    debugPrint('Emitting joinTable event with: userId=$userId, token=$token, tableId=$tableId');
    _socket!.emit('join-table', {
      'user_id': userId,
      'token': token,
      'table_id': tableId,
    });
  }

  void getTable(String userId, String token, String bootValue, String noOfPlayers) {
    if (!isConnected) {
      onError?.call('Not connected to server');
      return;
    }

    if (userId.isEmpty || token.isEmpty || bootValue.isEmpty || noOfPlayers.isEmpty) {
      onError?.call('Invalid parameters for get table');
      return;
    }

    print('Emitting getTable event with: userId=$userId, token=$token, boot_value=$bootValue, no_of_players=$noOfPlayers');
    _socket!.emit('get-table', {
      'user_id': userId,
      'token': token,
      'boot_value': bootValue,
      'no_of_players': noOfPlayers,
    });
  }

  void leaveTable(String userId, String token, {String? gameId}) {
    if (!isConnected) {
      onError?.call('Not connected to server');
      return;
    }
    print('Emitting leave-table event with: userId=$userId, token=$token, gameId=$gameId');
    final data = {
      'user_id': userId,
      'token': token,
    };
    if (gameId != null) {
      data['game_id'] = gameId;
    }
    _socket!.emit('leave-table', data);
  }

  void drawFromDeck() {
    if (!isConnected) return;
    _socket!.emit('drawFromDeck', {});
  }

  void drawFromDiscard() {
    if (!isConnected) return;
    _socket!.emit('drawFromDiscard', {});
  }

  void discardCard(Card card) {
    if (!isConnected) return;
    _socket!.emit('discardCard', {'card': card.toJson()});
  }

  void declareHand(List<CardGroupModel> groups) {
    if (!isConnected) return;
    _socket!.emit('declare', {
      'groups': groups.map((group) => group.toJson()).toList(),
    });
  }

  void dropFromGame() {
    if (!isConnected) return;
    _socket!.emit('dropGame', {});
  }

  void packGame(String userId, String token, {String? gameId}) {
    if (!isConnected) {
      onError?.call('Not connected to server');
      return;
    }
    print('Emitting pack-game event with: userId=$userId, token=$token, gameId=$gameId');

    final data = {
      'user_id': userId,
      'token': token,
    };

    if (gameId != null) {
      data['game_id'] = gameId;
    }

    _socket!.emit('pack-game', data);
  }

  void declare(String userId, String token, List<CardGroupModel> groups, {String? gameId}) {
    if (!isConnected) {
      onError?.call('Not connected to server');
      return;
    }
    print('Emitting declare event with: userId=$userId, token=$token, gameId=$gameId');

    final data = {
      'user_id': userId,
      'token': token,
      'groups': groups.map((group) => group.toJson()).toList(),
    };

    if (gameId != null) {
      data['game_id'] = gameId;
    }

    _socket!.emit('declare', data);
  }

  GameModel _parseGameState(dynamic data) {
    try {
      final gameModel = GameModel(
          numberOfPlayers: data['numberOfPlayers'] ?? 2);

      if (data['deck'] != null) {
        gameModel.deck = (data['deck'] as List)
            .map((cardData) => Card.fromJson(cardData))
            .toList();
      }

      if (data['discardPile'] != null) {
        gameModel.discardPile = (data['discardPile'] as List)
            .map((cardData) => Card.fromJson(cardData))
            .toList();
      }

      if (data['playersHands'] != null) {
        gameModel.playersHands = (data['playersHands'] as List)
            .map((hand) =>
            (hand as List)
                .map((cardData) => Card.fromJson(cardData))
                .toList())
            .toList();
      }

      gameModel.currentTurn = data['currentTurn'] ?? 0;
      gameModel.currentTurnPhase = data['currentTurnPhase'] == 'drawing'
          ? TurnPhase.drawing
          : TurnPhase.discarding;
      gameModel.wildCardRank = data['wildCardRank'];

      return gameModel;
    } catch (e) {
      print('Error parsing game state: $e');
      throw Exception('Failed to parse game state: $e');
    }
  }

  void emitStatus(String userId, String token, String gameId) {
    if (!isConnected) return;
    print('Emitting status event: userId=$userId, token=$token, gameId=$gameId');
    _socket?.emit('status', {
      'user_id': userId,
      'token': token,
      'game_id': gameId,
    });
  }

  void emitGetCard(String userId, String token) {
    if (!isConnected) return;
    _socket!.emit('get-card', {
      'user_id': userId,
      'token': token,
    });
  }

  void emitGetDropCard(String userId, String token) {
    if (!isConnected) return;
    _socket!.emit('get-drop-card', {
      'user_id': userId,
      'token': token,
    });
  }

  void emitMyCard(String userId, String token) {
    if (!isConnected) return;
    print('Emitting my-card event: userId=$userId, token=$token');
    _socket!.emit('my-card', {
      'user_id': userId,
      'token': token,
    });
  }

  void dispose() {
    _cancelReconnectTimer();
    _socket?.disconnect();
    _socket?.dispose();
    _socket = null;
    _instance = null;
  }

  void on(String event, Function(dynamic) handler) {
    _socket?.on(event, handler);
  }
}