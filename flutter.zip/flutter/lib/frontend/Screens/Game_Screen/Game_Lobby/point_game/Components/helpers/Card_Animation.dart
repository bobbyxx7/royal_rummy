import 'package:flutter/material.dart' hide Card;
import '../../Model/Cards_Model.dart';

class CardAnimationHelper {
  final AnimationController controller;
  late final Animation<double> _curve;
  final ValueNotifier<Card?> draggingCard;
  final ValueNotifier<Offset?> draggingCardOffset;
  final ValueNotifier<bool> isFaceUp;
  final Function(bool, Card) onAnimationEnd;
  bool _isDiscarding = false;
  Offset? _start;
  Offset? _end;

  CardAnimationHelper({
    required this.controller,
    required this.draggingCard,
    required this.draggingCardOffset,
    required this.isFaceUp,
    required this.onAnimationEnd,
  }) {
    _curve = CurvedAnimation(parent: controller, curve: Curves.easeInOut);
    controller.addListener(_updatePosition);
    controller.addStatusListener(_handleStatus);
  }

  void startDrawAnimation(Card card, Offset start, Offset end, {bool faceUp = true}) {
    _isDiscarding = false;
    _animateCard(card, start, end, faceUp);
  }

  void startDiscardAnimation(Card card, Offset start, Offset end) {
    _isDiscarding = true;
    _animateCard(card, start, end, true);
  }

  void startDistributionAnimation(Card card, Offset start, Offset end, {required VoidCallback onReveal}) {
    _isDiscarding = false;
    isFaceUp.value = false;
    _animateCard(card, start, end, false, onEnd: () {
      isFaceUp.value = true;
      onReveal();
    });
  }

  void _animateCard(Card card, Offset start, Offset end, bool faceUp, {VoidCallback? onEnd}) {
    draggingCard.value = card;
    draggingCardOffset.value = start;
    isFaceUp.value = faceUp;
    _start = start;
    _end = end;
    controller.reset();
    controller.forward().then((_) => onEnd?.call());
  }

  void _updatePosition() {
    if (_start != null && _end != null) {
      final progress = _curve.value;
      final currentOffset = Offset(
        _start!.dx + (_end!.dx - _start!.dx) * progress,
        _start!.dy + (_end!.dy - _start!.dy) * progress,
      );
      draggingCardOffset.value = currentOffset;
    }
  }

  void _handleStatus(AnimationStatus status) {
    if (status == AnimationStatus.completed) {
      if (draggingCard.value != null) {
        onAnimationEnd(_isDiscarding, draggingCard.value!);
      }
      draggingCard.value = null;
      draggingCardOffset.value = null;
      _start = null;
      _end = null;
    }
  }

  void dispose() {
    controller.removeListener(_updatePosition);
    controller.removeStatusListener(_handleStatus);
    controller.dispose();
  }
}


class AnimatedCardData {
  final Card card;
  final Offset startPosition;
  final Offset targetPosition;
  final int playerIndex;
  final int cardIndex;
  bool isDistributed;
  bool isRevealed;
  bool isRevealing;

  AnimatedCardData({
    required this.card,
    required this.startPosition,
    required this.targetPosition,
    required this.playerIndex,
    required this.cardIndex,
    this.isDistributed = false,
    this.isRevealed = false,
    this.isRevealing = false,
  });
}