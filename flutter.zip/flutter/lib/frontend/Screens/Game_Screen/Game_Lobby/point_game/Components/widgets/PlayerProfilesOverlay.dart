import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../../../components/Canvas.dart';
import 'package:arka_infotech/provider/pointGameProvider.dart';

class PlayerProfilesOverlay extends StatelessWidget {
  final bool showTimers;
  final List<Offset> cachedPositions;
  final bool Function(String? userId) isTimerActiveFor;

  const PlayerProfilesOverlay({
    Key? key,
    required this.isTimerActiveFor,
    required this.cachedPositions,
    this.showTimers = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<PointGameProvider>(
      builder: (context, provider, child) {
        final expectedPlayerCount = provider.expectedPlayerCount;
        final playersBySeat = provider.playersBySeat;
        final phase = provider.gamePhase;
        final currentChaalUserId = provider.currentChaalUserId;

        final int nPlayers = expectedPlayerCount;
        List<Widget> widgets = [];
        // Only build overlays for opponent seats (seat 2 and above)
        for (var seat = 2; seat <= nPlayers; seat++) {
          final pos =
          cachedPositions.isNotEmpty && seat - 2 < cachedPositions.length
              ? cachedPositions[seat - 2]
              : const Offset(50, 50);
          final player = playersBySeat[seat];
          bool hasPlayer = player != null && player['user_id']?.toString() != '0';
          if (phase == GamePhase.waiting || phase == GamePhase.loading) {
        final name = hasPlayer ? (player['name'] ?? 'Opponent') : 'Opponent';
        final profilePic = 'assets/default_profile.jpeg';
        widgets.add(
          Positioned(
            left: pos.dx,
            top: pos.dy,
            child: ProfileTimerWidget(
              key: ValueKey('waiting_opponent_$seat'),
              username: name,
              score: 0,
              metric1: 0,
              metric2: 0,
              isTimerActive: false,
              timerDuration: const Duration(seconds: 30),
              imagePath: profilePic,
            ),
          ),
        );
      } else {
        if (hasPlayer) {
          widgets.add(
            Positioned(
              left: pos.dx,
              top: pos.dy,
              child: ProfileTimerWidget(
                username: player['name'] ?? 'Opponent',
                isTimerActive: showTimers && isTimerActiveFor(player['user_id']),
                timerDuration: const Duration(seconds: 30),
                score: 0,
                metric1: 0,
                metric2: 0,
                imagePath: 'assets/default_profile.jpeg',
                key: ValueKey('player_${player['user_id']}'),
              ),
            ),
          );
          print('if hasPlayer is  true');
        } else {
          widgets.add(
            Positioned(
              left: pos.dx,
              top: pos.dy,
              child: ProfileTimerWidget(
                username: 'Opponent',
                isTimerActive: false,
                timerDuration: const Duration(seconds: 30),
                score: 0,
                metric1: 0,
                metric2: 0,
                imagePath: 'assets/default_profile.jpeg',
                key: ValueKey('playing_placeholder_$seat'),
              ),
            ),
          );
          print('if hasPlayer is  false');
        }
      }
        }
        return Stack(children: widgets);
      },
    );
  }
}


// Widget buildPlayerProfilesOverlay(int expectedPlayerCount,Map<int, Map<String, dynamic>> playersBySeat,ValueNotifier<GamePhase> gamePhaseNotifier,List<Offset> cachedPositions,{bool showTimers = false}) {
//     final int nPlayers = expectedPlayerCount;
//     final phase = gamePhaseNotifier.value;
//     List<Widget> widgets = [];
//     // Only build overlays for opponent seats (seat 2 and above)
//     for (var seat = 2; seat <= nPlayers; seat++) {
//       final pos =
//           cachedPositions.isNotEmpty && seat - 2 < cachedPositions.length
//               ? cachedPositions[seat - 2]
//               : const Offset(50, 50);
//       final player = playersBySeat[seat];
//       bool hasPlayer = player != null && player['user_id']?.toString() != '0';
//       // Overlay logic by phase
//       if (phase == GamePhase.waiting || phase == GamePhase.loading) {
//         // --- WAITING or LOADING PHASE ---
//         // For opponent seats show loader/profile circle always
//         final name = hasPlayer ? (player['name'] ?? 'Opponent') : 'Opponent';
//         final profilePic = 'assets/default_profile.jpeg';
//         widgets.add(
//           Positioned(
//             left: pos.dx,
//             top: pos.dy,
//             child: ProfileTimerWidget(
//               key: ValueKey('waiting_opponent_$seat'),
//               username: name,
//               score: 0,
//               metric1: 0,
//               metric2: 0,
//               isTimerActive: false,
//               // No timer during waiting/loading
//               timerDuration: const Duration(seconds: 30),
//               imagePath: profilePic,
//             ),
//           ),
//         );
//       } else {
//         // --- PLAYING/RESULT PHASES ---
//         if (hasPlayer) {
//           widgets.add(
//             Positioned(
//               left: pos.dx,
//               top: pos.dy,
//               child: ProfileTimerWidget(
//                 username: player['name'] ?? 'Opponent',
//                 isTimerActive:
//                     showTimers && isTimerActiveFor(player['user_id']),
//                 timerDuration: const Duration(seconds: 30),
//                 score: 0,
//                 metric1: 0,
//                 metric2: 0,
//                 imagePath: 'assets/default_profile.jpeg',
//                 key: ValueKey('player_${player['user_id']}'),
//               ),
//             ),
//           );
//         } else {
//           // just to be safe, fallback to loader/placeholder if player disappears
//           widgets.add(
//             Positioned(
//               left: pos.dx,
//               top: pos.dy,
//               child: ProfileTimerWidget(
//                 username: 'Opponent',
//                 isTimerActive: false,
//                 timerDuration: const Duration(seconds: 30),
//                 score: 0,
//                 metric1: 0,
//                 metric2: 0,
//                 imagePath: 'assets/default_profile.jpeg',
//                 key: ValueKey('playing_placeholder_$seat'),
//               ),
//             ),
//           );
//         }
//       }
//     }
//     return Stack(children: widgets);
//   }