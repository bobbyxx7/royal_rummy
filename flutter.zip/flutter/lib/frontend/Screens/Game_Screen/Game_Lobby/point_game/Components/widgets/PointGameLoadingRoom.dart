import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../../components/Animations.dart';
import 'package:arka_infotech/provider/pointGameProvider.dart';

Widget buildLoadingRoom(String percent) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          RotatingIconsLoader(size: 30, spacing: 0),
          SizedBox(height: 18),
          Text('Loading Game.. $percent%',
          style: TextStyle(
            fontSize: 20,
            color: Colors.amber,
            fontWeight: FontWeight.bold,
            shadows: [Shadow(color: Colors.black,  blurRadius: 2)],
          ),
          ),
        ],
      ),
    );
  }


