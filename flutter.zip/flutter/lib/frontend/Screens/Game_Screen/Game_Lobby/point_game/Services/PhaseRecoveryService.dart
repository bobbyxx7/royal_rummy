import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:arka_infotech/provider/pointGameProvider.dart';
import 'RummyPointSocketService.dart';
import 'dart:async'; // Added for Timer

class PhaseRecoveryService {
  final RummyPointSocketService _socketService;
  
  PhaseRecoveryService(this._socketService);
  
  /// Attempts to recover the game state when reconnecting
  Future<bool> attemptRecovery(BuildContext context) async {
    final provider = Provider.of<PointGameProvider>(context, listen: false);
    
    debugPrint('[RECOVERY] Attempting to recover game state');
    
    try {
      // Check if we have a valid game ID
      if (provider.gameId == null) {
        debugPrint('[RECOVERY] No game ID found, cannot recover');
        return false;
      }
      
      // Check if we have a valid user
      if (provider.cachedUser == null) {
        debugPrint('[RECOVERY] No cached user found, cannot recover');
        return false;
      }
      
      // Attempt to reconnect to socket
      if (!_socketService.isConnected) {
        await _reconnectSocket(context);
      }
      
      // Request current game status
      if (context.mounted) {
        await _requestGameStatus(context);
      } else {
        return false;
      }
      
      debugPrint('[RECOVERY] Recovery attempt completed');
      return true;
      
    } catch (e) {
      debugPrint('[RECOVERY] Recovery failed: $e');
      return false;
    }
  }
  
  Future<void> _reconnectSocket(BuildContext context) async {
    if (!context.mounted) return;
    
    final userId = Provider.of<PointGameProvider>(context, listen: false).cachedUser?.id?.toString() ?? '';
    
    if (userId.isNotEmpty) {
      await _socketService.connect(userId);
      
      // Wait for connection
      int attempts = 0;
      while (!_socketService.isConnected && attempts < 10) {
        await Future.delayed(const Duration(milliseconds: 500));
        attempts++;
        if (!context.mounted) return;
      }
      
      if (!_socketService.isConnected) {
        throw Exception('Failed to reconnect to socket');
      }
    }
  }
  
  Future<void> _requestGameStatus(BuildContext context) async {
    final user = Provider.of<PointGameProvider>(context, listen: false).cachedUser;
    final gameId = Provider.of<PointGameProvider>(context, listen: false).gameId;
    
    if (user != null && gameId != null) {
      // Request current game status from server using RummyPointSocketService
      _socketService.emitStatus(
        user.id.toString(),
        user.token.toString(),
        gameId.toString(),
      );
    }
  }
  
  /// Handles network disconnection during game
  void handleDisconnection(BuildContext context) {
    debugPrint('[RECOVERY] Network disconnection detected');
    
    // Show reconnection dialog
    _showReconnectionDialog(context);
    
    // Start reconnection attempts
    _startReconnectionAttempts(context);
  }
  
  void _showReconnectionDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('Connection Lost'),
        content: const Text('Attempting to reconnect...'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(); // Close dialog
              Navigator.of(context).pop(); // Return to dashboard
            },
            child: const Text('Cancel'),
          ),
        ],
      ),
    );
  }
  
  void _startReconnectionAttempts(BuildContext context) {
    Timer.periodic(const Duration(seconds: 5), (timer) async {
      if (!context.mounted) {
        timer.cancel();
        return;
      }
      
      final success = await attemptRecovery(context);
      if (success && context.mounted) {
        timer.cancel();
        Navigator.of(context).pop(); // Close reconnection dialog
      }
    });
  }
  
  /// Saves current game state for recovery
  void saveGameState(BuildContext context) {
    // Save to local storage or shared preferences
    // This would be implemented based on your storage solution
    debugPrint('[RECOVERY] Saving game state for recovery');
  }
} 