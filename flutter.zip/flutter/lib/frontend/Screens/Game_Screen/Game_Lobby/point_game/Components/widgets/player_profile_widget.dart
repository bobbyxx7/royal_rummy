// import 'package:flutter/material.dart';
//
// Widget buildPlayerProfile({required String name, required bool isWaiting}) {
//   return Column(
//     children: [
//       CircleAvatar(
//         backgroundImage: AssetImage('assets/profile.png'),
//         radius: 30,
//       ),
//       SizedBox(height: 8),
//       Text(name, style: TextStyle(color: Colors.white)),
//       if (isWaiting)
//         Column(
//           children: [
//             SizedBox(height: 8),
//             CircularProgressIndicator(),
//             Text(
//               'Waiting...',
//               style: TextStyle(color: Colors.amber, fontSize: 12),
//             ),
//           ],
//         ),
//     ],
//   );
// }