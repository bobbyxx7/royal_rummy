import 'dart:async';
import 'package:flutter/material.dart' hide Card;
import '../Model/Cards_Model.dart';
import '../Model/Card_Group_Model.dart';
import 'CardHandProvider.dart';
import 'RummyPointSocketService.dart';
import 'GameLogicService.dart';
import 'package:arka_infotech/provider/pointGameProvider.dart';

// Import SocketConnectionState from RummyPointSocketService
import 'RummyPointSocketService.dart' show SocketConnectionState;
import 'dart:convert'; // Added for jsonDecode
import 'package:flutter/foundation.dart'; // Added for debugPrint

class GameStateCoordinator  {
  static GameStateCoordinator? _instance;
  GameProvider? _gameProvider;
  late RummyPointSocketService _socketService;
  late GameLogicService _gameLogicService;
  PointGameProvider? _pointGameProvider;
  
  // State synchronization
  Timer? _syncTimer;
  bool _isInitialized = false;
  
  // Callbacks for UI updates
  VoidCallback? onStateChanged;
  Function(String)? onError;
  Function(GamePhase)? onPhaseChanged;
  Function(List<Card>)? onCardsReceived;
  Function(bool)? onDealingStateChanged;
  Function(Card)? onDrawAnimationRequested; // Added for draw animation

  static GameStateCoordinator getInstance() {
    _instance ??= GameStateCoordinator._internal();
    return _instance!;
  }

  GameStateCoordinator._internal() {
    _socketService = RummyPointSocketService.getInstance();
    _gameLogicService = GameLogicService.getInstance();
    _setupEventHandlers();
  }

  void setPointGameProvider(PointGameProvider provider) {
    _pointGameProvider = provider;
    _gameProvider = GameProvider(provider);
    
    // Set up game provider state change handler
    _gameProvider?.addListener(() {
      onStateChanged?.call();
    });
  }

  GameProvider? get gameProvider => _gameProvider;
  RummyPointSocketService get socketService => _socketService;
  GameLogicService get gameLogicService => _gameLogicService;
  GamePhase get currentPhase => _pointGameProvider?.gamePhase ?? GamePhase.waiting;
  bool get isDealingInProgress => _pointGameProvider?.isDealing ?? false;
  bool get myCardReceived => _pointGameProvider?.myCardReceivedNotifier ?? false;
  int? get gameId => _pointGameProvider?.gameId;
  int? get tableId => _pointGameProvider?.tableId;


  // void updateShowLoading(bool value) {
  //   _showLoading = value;
  //
  // }

  void initialize() {
    if (_isInitialized) return;
    
    _isInitialized = true;
    _startStateSync();
  }

  void _setupEventHandlers() {
    // Socket service event handlers
    _socketService.onConnectionStateChanged = (state) {
      if (state == SocketConnectionState.connected) {
        _syncGameState();
      }
    };

    _socketService.onError = (error) {
      onError?.call(error);
    };

    _socketService.onMyCard = (data) {
      handleMyCardData(data);
    };

    _socketService.onGetCard = (data) {
      handleGetCardData(data);
    };

    _socketService.onGetDropCard = (data) {
      handleGetDropCardData(data);
    };

    _socketService.onStatus = (data) {
      _handleStatusData(data);
    };

    _socketService.onStartGameResponse = (data) {
      handleStartGameResponse(data);
    };

    // Game provider state change handler will be set up when provider is available
  }

  void handleStartGameResponse(dynamic data) {
    try {
      if (data is String) data = jsonDecode(data);
      
      if (data['code'] == 200 && _pointGameProvider != null) {
        _pointGameProvider!.setGameId(int.tryParse(data['game_id'].toString()));
        if (data['table_id'] != null && data['table_id'].toString() != 'null') {
          _pointGameProvider!.setTableId(int.tryParse(data['table_id'].toString()));
        }
        
        // Transition to dealing phase
        _updateGamePhase(GamePhase.dealing);
        _pointGameProvider!.setIsDealing(true);
        onDealingStateChanged?.call(true);
        
        // Request cards after a short delay
        Future.delayed(const Duration(milliseconds: 500), () {
          _requestMyCards();
        });
      }
    } catch (e) {
      onError?.call('Error handling start game response: $e');
    }
  }

  void handleMyCardData(dynamic data) {
    try {
      if (data is String) data = jsonDecode(data);
      
      if (data['code'] == 200 && data['cards'] != null && _gameProvider != null) {
        List<String> cardCodes = (data['cards'] as List)
            .map((c) => c['card'] as String)
            .toList();
        
        // Update game provider with cards
        _gameProvider!.mapHandWithWild(cardCodes);
        
        // Get the updated player hand from game provider
        final playerHand = _gameProvider!.playerHand;
        
        // Update cardGroups in PointGameProvider so UI can display the cards
        if (playerHand.isNotEmpty && _pointGameProvider != null) {
          // Create a single group with all cards initially
          final cardGroups = [playerHand];
          _pointGameProvider!.updateCardGroups(cardGroups);
          
          debugPrint('[COORDINATOR] Updated cardGroups with ${playerHand.length} cards');
        }
        
        _pointGameProvider?.setMyCardReceivedNotifier(true);
        
        // If dealing is in progress, complete it
        if (_pointGameProvider?.isDealing == true) {
          _pointGameProvider?.setIsDealing(false);
          onDealingStateChanged?.call(false);
          _updateGamePhase(GamePhase.playing);
        }
        
        // Notify UI about received cards
        onCardsReceived?.call(_gameProvider!.playerHand);
        
        debugPrint('Cards received: ${_gameProvider!.playerHand.length} cards');
      }
    } catch (e) {
      onError?.call('Error handling my card data: $e');
    }
  }

  void handleGetCardData(dynamic data) {
    try {
      if (data is Map && data['card'] != null && _gameProvider != null) {
        // Handle card drawn from deck/discard
        Card drawnCard = Card.fromServer(data['card']);
        List<Card> updatedHand = [..._gameProvider!.playerHand, drawnCard];
        _gameProvider!.updatePlayerHand(updatedHand);
        
        // Update cardGroups in PointGameProvider so UI can display the updated hand
        if (_pointGameProvider != null) {
          // Get current cardGroups and add the new card to the last group
          final currentGroups = List<List<Card>>.from(_pointGameProvider!.cardGroups);
          if (currentGroups.isNotEmpty) {
            // Add the new card to the last group
            currentGroups.last.add(drawnCard);
            _pointGameProvider!.updateCardGroups(currentGroups);
            debugPrint('[COORDINATOR] Added drawn card to cardGroups: ${drawnCard.suit} ${drawnCard.rank}');
          } else {
            // If no groups exist, create a new group with the drawn card
            final cardGroups = [updatedHand];
            _pointGameProvider!.updateCardGroups(cardGroups);
            debugPrint('[COORDINATOR] Created new cardGroup with drawn card: ${drawnCard.suit} ${drawnCard.rank}');
          }
        }
        
        // Trigger draw animation with the actual card received from server
        onDrawAnimationRequested?.call(drawnCard);
        
        onCardsReceived?.call(updatedHand);
        debugPrint('[COORDINATOR] Card drawn from server: ${drawnCard.suit} ${drawnCard.rank}');
      }
    } catch (e) {
      onError?.call('Error handling get card data: $e');
    }
  }

  void handleGetDropCardData(dynamic data) {
    try {
      if (data is Map && data['card'] != null && _gameProvider != null) {
        // Handle card drawn from discard pile
        Card drawnCard = Card.fromServer(data['card']);
        List<Card> updatedHand = [..._gameProvider!.playerHand, drawnCard];
        _gameProvider!.updatePlayerHand(updatedHand);
        
        // Update cardGroups in PointGameProvider so UI can display the updated hand
        if (_pointGameProvider != null) {
          // Get current cardGroups and add the new card to the last group
          final currentGroups = List<List<Card>>.from(_pointGameProvider!.cardGroups);
          if (currentGroups.isNotEmpty) {
            // Add the new card to the last group
            currentGroups.last.add(drawnCard);
            _pointGameProvider!.updateCardGroups(currentGroups);
            debugPrint('[COORDINATOR] Added drawn card from discard to cardGroups: ${drawnCard.suit} ${drawnCard.rank}');
          } else {
            // If no groups exist, create a new group with the drawn card
            final cardGroups = [updatedHand];
            _pointGameProvider!.updateCardGroups(cardGroups);
            debugPrint('[COORDINATOR] Created new cardGroup with drawn card from discard: ${drawnCard.suit} ${drawnCard.rank}');
          }
        }
        
        // Trigger draw animation with the actual card received from server
        onDrawAnimationRequested?.call(drawnCard);
        
        onCardsReceived?.call(updatedHand);
        debugPrint('[COORDINATOR] Card drawn from discard pile: ${drawnCard.suit} ${drawnCard.rank}');
      } else if (data is Map && data['card'] != null) {
        // Handle card dropped by other player (not drawn by current player)
        Card droppedCard = Card.fromServer(data['card']);
        // Update discard pile or handle as needed
        debugPrint('[COORDINATOR] Card dropped by other player: ${droppedCard.suit} ${droppedCard.rank}');
      }
    } catch (e) {
      onError?.call('Error handling get drop card data: $e');
    }
  }

  void _handleStatusData(dynamic data) {
    try {
      if (data is Map && _gameProvider != null) {
        // Update current chaal user
        if (data['chaal_user_id'] != null) {
          _gameProvider!.updateCurrentChaalUserId(data['chaal_user_id']);
        }
        
        // Update can declare status
        if (data['can_declare'] != null) {
          _gameProvider!.updateCanDeclare(data['can_declare']);
        }
        
        // Update players from table_users
        if (data['table_users'] != null) {
          _updatePlayersFromStatus(data['table_users']);
        }
      }
    } catch (e) {
      onError?.call('Error handling status data: $e');
    }
  }

  void _updatePlayersFromStatus(List tableUsers) {
    // Process player data from status
    for (var user in tableUsers) {
      if (user['user_id'] != null && user['user_id'].toString() != '0') {
        debugPrint('Player updated: ${user['name']} at seat ${user['seat_position']}');
      }
    }
  }

  void _updateGamePhase(GamePhase phase) {
    if (_pointGameProvider != null && _pointGameProvider!.gamePhase != phase) {
      _pointGameProvider!.setGamePhase(phase);
      onPhaseChanged?.call(phase);
      debugPrint('Game phase changed to: $phase');
    }
  }

  void _requestMyCards() {
    if (_pointGameProvider != null && _pointGameProvider!.currentChaalUserId != null) {
      _socketService.emitMyCard(
        _pointGameProvider!.currentChaalUserId!,
        'token', // Get from auth
      );
      debugPrint('Requesting my cards...');
    }
  }

  void _startStateSync() {
    _syncTimer = Timer.periodic(const Duration(seconds: 30), (timer) {
      if (_socketService.isConnected && _pointGameProvider != null && _pointGameProvider!.gameId != null) {
        _syncGameState();
      }
    });
  }

  void _syncGameState() {
    // Sync local state with server
    if (_pointGameProvider != null && _pointGameProvider!.currentChaalUserId != null && _pointGameProvider!.gameId != null) {
      _socketService.emitStatus(
        _pointGameProvider!.currentChaalUserId!,
        'token', // Get from auth
        _pointGameProvider!.gameId.toString(),
      );
    }
  }

  // Game actions
  void drawFromDeck() {
    if (_pointGameProvider != null && _pointGameProvider!.gamePhase == GamePhase.playing) {
      _socketService.drawFromDeck();
    }
  }

  void drawFromDiscard() {
    if (_pointGameProvider != null && _pointGameProvider!.gamePhase == GamePhase.playing) {
      _socketService.drawFromDiscard();
    }
  }

  void discardCard(Card card) {
    if (_pointGameProvider != null && _pointGameProvider!.gamePhase == GamePhase.playing && _gameProvider != null) {
      _socketService.discardCard(card);
      // Remove card from player hand
      List<Card> updatedHand = List.from(_gameProvider!.playerHand);
      updatedHand.remove(card);
      _gameProvider!.updatePlayerHand(updatedHand);
      
      // Update cardGroups in PointGameProvider to reflect the discarded card
      final currentGroups = List<List<Card>>.from(_pointGameProvider!.cardGroups);
      for (int i = 0; i < currentGroups.length; i++) {
        currentGroups[i].remove(card);
      }
      // Remove empty groups
      currentGroups.removeWhere((group) => group.isEmpty);
      _pointGameProvider!.updateCardGroups(currentGroups);
      
      debugPrint('[COORDINATOR] Removed discarded card from cardGroups: ${card.suit} ${card.rank}');
    }
  }

  void declareHand(List<CardGroupModel> groups) {
    if (_pointGameProvider != null && _pointGameProvider!.canDeclare) {
      _socketService.declare(
        'user_id', // Get from auth
        'token', // Get from auth
        groups,
        gameId: _pointGameProvider!.gameId?.toString(),
      );
    }
  }

  void packGame() {
    if (_pointGameProvider != null) {
      _socketService.packGame(
        'user_id', // Get from auth
        'token', // Get from auth
        gameId: _pointGameProvider!.gameId?.toString(),
      );
    }
  }

  // Card group management
  void createCardGroup(List<Card> cards) {
    if (cards.length >= 3 && _gameProvider != null) {
      CardGroupModel group = _gameLogicService.evaluateGroup(cards);
      if (group.groupValue != 'Invalid') {
        _gameProvider!.createNewGroup(cards);
        // Remove cards from player hand
        List<Card> updatedHand = List.from(_gameProvider!.playerHand);
        for (Card card in cards) {
          updatedHand.remove(card);
        }
        _gameProvider!.updatePlayerHand(updatedHand);
        
        // Update cardGroups in PointGameProvider
        if (_pointGameProvider != null) {
          final currentGroups = List<List<Card>>.from(_pointGameProvider!.cardGroups);
          // Remove the cards from existing groups
          for (int i = 0; i < currentGroups.length; i++) {
            for (Card card in cards) {
              currentGroups[i].remove(card);
            }
          }
          // Remove empty groups
          currentGroups.removeWhere((group) => group.isEmpty);
          // Add the new group
          currentGroups.add(cards);
          _pointGameProvider!.updateCardGroups(currentGroups);
          
          debugPrint('[COORDINATOR] Created new card group with ${cards.length} cards');
        }
      }
    }
  }

  void addCardToGroup(int groupIndex, Card card) {
    if (_gameProvider != null) {
      _gameProvider!.addCardToGroup(groupIndex, card);
      // Remove card from player hand
      List<Card> updatedHand = List.from(_gameProvider!.playerHand);
      updatedHand.remove(card);
      _gameProvider!.updatePlayerHand(updatedHand);
      
      // Update cardGroups in PointGameProvider
      if (_pointGameProvider != null) {
        final currentGroups = List<List<Card>>.from(_pointGameProvider!.cardGroups);
        // Remove the card from all groups first
        for (int i = 0; i < currentGroups.length; i++) {
          currentGroups[i].remove(card);
        }
        // Add the card to the specified group
        if (groupIndex >= 0 && groupIndex < currentGroups.length) {
          currentGroups[groupIndex].add(card);
        }
        _pointGameProvider!.updateCardGroups(currentGroups);
        
        debugPrint('[COORDINATOR] Added card to group $groupIndex: ${card.suit} ${card.rank}');
      }
    }
  }

  void removeCardFromGroup(int groupIndex, int cardIndex) {
    if (_gameProvider != null && groupIndex >= 0 && groupIndex < _gameProvider!.cardGroups.length &&
        cardIndex >= 0 && cardIndex < _gameProvider!.cardGroups[groupIndex].length) {
      Card removedCard = _gameProvider!.cardGroups[groupIndex][cardIndex];
      _gameProvider!.removeCardFromGroup(groupIndex, cardIndex);
      // Add card back to player hand
      List<Card> updatedHand = List.from(_gameProvider!.playerHand);
      updatedHand.add(removedCard);
      _gameProvider!.updatePlayerHand(updatedHand);
      
      // Update cardGroups in PointGameProvider
      if (_pointGameProvider != null) {
        final currentGroups = List<List<Card>>.from(_pointGameProvider!.cardGroups);
        if (groupIndex >= 0 && groupIndex < currentGroups.length &&
            cardIndex >= 0 && cardIndex < currentGroups[groupIndex].length) {
          currentGroups[groupIndex].removeAt(cardIndex);
          // Remove empty groups
          currentGroups.removeWhere((group) => group.isEmpty);
          _pointGameProvider!.updateCardGroups(currentGroups);
          
          debugPrint('[COORDINATOR] Removed card from group $groupIndex: ${removedCard.suit} ${removedCard.rank}');
        }
      }
    }
  }

  void toggleCardSelection(Card card) {
    if (_gameProvider != null) {
      _gameProvider!.toggleCardSelection(card);
    }
  }

  void clearCardSelection() {
    if (_gameProvider != null) {
      _gameProvider!.clearCardSelection();
    }
  }

  // Cleanup
  void dispose() {
    _syncTimer?.cancel();
    _gameProvider?.dispose();
    _socketService.dispose();
    _instance = null;
  }
} 