import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:arka_infotech/provider/pointGameProvider.dart';
import 'RummyPointSocketService.dart';


class WaitingPhaseService {
  static const Duration _waitingTimeout = Duration(minutes: 5);
  Timer? _timeoutTimer;
  final RummyPointSocketService _socketService;
  
  WaitingPhaseService(this._socketService);
  
  void initializeWaitingPhase(BuildContext context) {
    final provider = Provider.of<PointGameProvider>(context, listen: false);
    
    debugPrint('[WAITING SERVICE] Initializing waiting phase');
    
    // Reset waiting state
    provider.setHasTransitionedFromWaiting(false);
    provider.setIsCheckingPlayersJoined(false);
    
    // Start timeout timer
    _startTimeoutTimer(context);
    
    // Setup socket connection if needed
    _ensureSocketConnection(context);
  }
  
  void _startTimeoutTimer(BuildContext context) {
    _timeoutTimer?.cancel();
    _timeoutTimer = Timer(_waitingTimeout, () {
      if (context.mounted) {
        _handleTimeout(context);
      }
    });
  }
  
  void _handleTimeout(BuildContext context) {
    debugPrint('[WAITING SERVICE] Timeout reached');
    _showTimeoutDialog(context);
  }
  
  void _showTimeoutDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('Connection Timeout'),
        content: const Text('No players joined within the time limit. Please try again.'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(); // Close dialog
              Navigator.of(context).pop(); // Return to dashboard
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }
  
  void _ensureSocketConnection(BuildContext context) {
    final provider = Provider.of<PointGameProvider>(context, listen: false);
    
    if (!_socketService.isConnected) {
      final userId = provider.cachedUser?.id?.toString() ?? '';
      if (userId.isNotEmpty) {
        _socketService.connect(userId);
        debugPrint('[WAITING SERVICE] Connecting socket with userId: $userId');
      }
    }
  }
  
  void checkPlayerJoinStatus(BuildContext context) {
    final provider = Provider.of<PointGameProvider>(context, listen: false);
    
    if (provider.isCheckingPlayersJoined) return;
    
    final expected = provider.expectedPlayerCount;
    int filled = 0;
    
    for (var seat = 1; seat <= expected; seat++) {
      final p = provider.playersBySeat[seat];
      if (p != null &&
          p['user_id'] != null &&
          p['user_id'].toString() != '0' &&
          p['name'].toString() != '0') {
        filled++;
      }
    }
    
    bool canStart = false;
    if (expected == 2) {
      canStart = (filled == 2);
    } else if (expected == 6) {
      canStart = (filled >= 2 && filled <= 6);
    } else {
      canStart = (filled == expected);
    }
    
    if (canStart && !provider.hasTransitionedFromWaiting) {
      _transitionToLoading(context);
    }
  }
  
  void _transitionToLoading(BuildContext context) {
    final provider = Provider.of<PointGameProvider>(context, listen: false);
    
    provider.setIsCheckingPlayersJoined(true);
    provider.setHasTransitionedFromWaiting(true);
    
    // Cancel timeout since we're transitioning
    _timeoutTimer?.cancel();
    
    debugPrint('[WAITING SERVICE] All players joined, transitioning to loading');
  }
  
  void dispose() {
    _timeoutTimer?.cancel();
  }
} 