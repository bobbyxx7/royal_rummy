import 'package:arka_infotech/frontend/Screens/components/splash_Screen.dart';
import 'package:arka_infotech/provider/auth_view_model.dart';
import 'package:flutter/material.dart' hide Card;
import 'package:flutter/services.dart';
import 'dart:convert';
import 'package:provider/provider.dart';

import '../../../services/api_service.dart';
import 'Game_Lobby/point_game/Model/Game_Model.dart';
import 'Game_Lobby/point_game/Model/Cards_Model.dart';
import 'Game_Lobby/point_game/Services/RummyPointSocketService.dart';
import 'Game_Lobby/point_game/Services/RummyPointSocketService.dart' show SocketConnectionState;
import 'Game_Lobby/point_game/point_game_lobby.dart';
import '../../Socket/socket_service.dart';
import '../components/Animations.dart';
import '../components/reusable_buttons.dart';

class PointGameDashboard extends StatefulWidget {
  final SocketService socketService;

  const PointGameDashboard({super.key, required this.socketService});

  @override
  State<PointGameDashboard> createState() => _PointGameDashboardState();
}

// Custom Slider Thumb Shape
class CustomSliderThumbShape extends SliderComponentShape {
  final double thumbRadius;
  final Color innerColor;
  final Color outerStrokeColor;

  const CustomSliderThumbShape({
    required this.thumbRadius,
    this.innerColor = Colors.amber,
    this.outerStrokeColor = Colors.white,
  });

  @override
  Size getPreferredSize(bool isEnabled, bool isDiscrete) =>
      Size.fromRadius(thumbRadius);

  @override
  void paint(PaintingContext context, Offset center, {
    required Animation<double> activationAnimation,
    required Animation<double> enableAnimation,
    required bool isDiscrete,
    required TextPainter labelPainter,
    required RenderBox parentBox,
    required SliderThemeData sliderTheme,
    required TextDirection textDirection,
    required double value,
    required double textScaleFactor,
    required Size sizeWithOverflow,
  }) {
    final Canvas canvas = context.canvas;

    // Outer stroke
    final Paint outerPaint = Paint()
      ..color = outerStrokeColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = thumbRadius * 0.30;

    // Inner fill
    final Paint innerPaint = Paint()
      ..color = innerColor
      ..style = PaintingStyle.fill;

    canvas.drawCircle(center, thumbRadius, innerPaint);
    canvas.drawCircle(center, thumbRadius, outerPaint);

    // Draw highlight dot/shine for attractive effect
    final double dotRadius = thumbRadius * 0.21;
    final Offset dotCenter = Offset(
      center.dx - thumbRadius * 0.38,
      center.dy - thumbRadius * 0.38,
    );
    final Paint dotPaint = Paint()
      ..color = Colors.white70
      ..style = PaintingStyle.fill;
    canvas.drawCircle(dotCenter, dotRadius, dotPaint);
  }
}

class _PointGameDashboardState extends State<PointGameDashboard>
    with TickerProviderStateMixin {
  final ValueNotifier<int> selectedPlayer = ValueNotifier(2);
  final ValueNotifier<double> _pointValue = ValueNotifier(1.0);
  final ValueNotifier<bool> _isJoiningTable = ValueNotifier(false);
  final ValueNotifier<bool> _isWaitingForPlayers = ValueNotifier(false);
  final ValueNotifier<String> _connectionStatus = ValueNotifier('Disconnected');
  bool _isLoading = true;
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;
  late final AuthViewModel authViewModel;
  late final RummyPointSocketService _rummySocketService;

  // Define the allowed point values and their corresponding boot values
  final List<double> _allowedPointValues = [1.0, 10.0, 80.0, 100.0];
  final Map<double, double> _pointToBootValueMap = {
    1.0: 80.0,
    10.0: 800.0,
    80.0: 6400.0,
    100.0: 8000.0,
  };

  @override
  void initState() {
    super.initState();
    _setLandscapeMode();
    _initAnimations();
    authViewModel = Provider.of<AuthViewModel>(context, listen: false);
    _initializeRummySocketService();
  }

  void _initAnimations() {
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );
  }

  void _initializeRummySocketService() {
    _rummySocketService = RummyPointSocketService.getInstance();

    // Setup connection and error handlers
    _rummySocketService.onConnectionStateChanged = (connectionState) {
      if (mounted) {
        switch (connectionState) {
          case SocketConnectionState.connected:
            _connectionStatus.value = 'Connected';
            break;
          case SocketConnectionState.connecting:
            _connectionStatus.value = 'Connecting...';
            break;
          case SocketConnectionState.disconnected:
            _connectionStatus.value = 'Disconnected';
            break;
          case SocketConnectionState.error:
            _connectionStatus.value = 'Connection Error';
            break;
        }
        print('Socket connection status changed: $connectionState');
      }
    };

    _rummySocketService.onError = (error) {
      if (mounted) {
        _isJoiningTable.value = false;
        _isWaitingForPlayers.value = false;
        _showErrorDialog(error);
        print('Socket error: $error');
      }
    };

    _rummySocketService.onTableJoined = (tableId) {
      if (mounted) {
        _isWaitingForPlayers.value = true;
        print('Socket: Joined table: $tableId');
      }
    };

    // Set up socket callbacks for table and join responses
    _rummySocketService.onGetTableResponse = (data) {
      _handleGetTableResponse(data);
    };

    _rummySocketService.onGameStart =
        (gameId, playersHands, wildCardRank, currentTurn) {
      if (mounted) {
        _isWaitingForPlayers.value = false;
        _navigateToGameLobby(gameId, playersHands, wildCardRank, currentTurn);
      }
    };

    // Connect to socket server
    _connectToSocketServer();
  }

  Future<void> _connectToSocketServer() async {
    try {
      print('Attempting to connect to socket server with user ID: ${authViewModel.user!.id}');
      await _rummySocketService.connect(authViewModel.user!.id.toString());
      print('Connected to socket server, connection state: ${_rummySocketService.connectionState}');
    } catch (e) {
      print('Failed to connect to socket server: $e');
    }
  }

  void _navigateToGameLobby(String gameId, List<List<Card>> playersHands,
      String? wildCardRank, int currentTurn) {
    final gameModel = GameModel(numberOfPlayers: playersHands.length);
    gameModel.playersHands = playersHands;
    gameModel.wildCardRank = wildCardRank;
    gameModel.currentTurn = currentTurn;

    Navigator.pushReplacement(
      context,
      customSlideTransition(
        SplashScreen(
          backgroundImagePath: 'assets/dashboard_bg.png',
          onLoad: simulateLoading,
          nextPage: PointGameLobby(
            gameModel: gameModel,
            socketService: widget.socketService,
          ),
        ),
      ),
    );
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Error'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _showWaitingDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('Finding Players'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const CircularProgressIndicator(),
            const SizedBox(height: 16),
            Text('Waiting for ${selectedPlayer.value - 1} players...'),
            const SizedBox(height: 8),
            const Text('This may take a few moments'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () async {
              try {
                _isWaitingForPlayers.value = false;
                Navigator.pop(context);
              } catch (e) {
                print('Error leaving table: $e');
                Navigator.pop(context);
              }
            },
            child: const Text('Cancel'),
          ),
        ],
      ),
    );
  }

  void _handleGetTableResponse(data) {
    if (!mounted) return;
    try {
      print('Processing getTableResponse: $data');
      if (data is String) {
        try {
          data = jsonDecode(data);
          print('Converted string data to JSON: $data');
        } catch (e) {
          print('Failed to parse JSON string: $e');
          _showErrorDialog('Invalid response format');
          _isJoiningTable.value = false;
          return;
        }
      }

      if (data['code'] == 200) {
        print('Successfully got table with code 200');
        print('The User have Joined the table with table_id: ${data['table_data'][0]['table_id']}');
        final gameModel = GameModel(numberOfPlayers: selectedPlayer.value);

        print('[POINT DASHBOARD] The response data is: $data');
        // var tableData = data['table_data'];
        // if (tableData is Map) tableData = [tableData];
        // final noOfPlayers = int.tryParse(data['no_of_players']?.toString() ?? '') ?? selectedPlayer.value;
        Navigator.pushReplacement(
          context,
          customSlideTransition(
            SplashScreen(
              backgroundImagePath: 'assets/dashboard_bg.png',
              onLoad: simulateLoading,
              nextPage: PointGameLobby(
                gameModel: gameModel,
                socketService: widget.socketService,
                tableData: data,
                noOfPlayers: selectedPlayer.value,
              ),
            ),
          ),
        );
      } else {
        print('Error getting table: ${data['message']}, code: ${data['code']}');
        _showErrorDialog(data['message'] ?? 'Failed to get table');
        _isJoiningTable.value = false;
      }
    } catch (e, stackTrace) {
      print('Error processing getTableResponse: $e');
      print('Stack trace: $stackTrace');
      _showErrorDialog('Failed to process table data: $e');
      _isJoiningTable.value = false;
    }
  }

  _handlePlayNow() async {
    print('Play Now button clicked');
    print('Socket connected status: ${_rummySocketService.connectionState}');

    if (_rummySocketService.connectionState != SocketConnectionState.connected) {
      print('Socket is not connected, showing error dialog');
      _showErrorDialog('Not connected to server. Please check your connection.');
      return;
    }

    if (_isJoiningTable.value || _isWaitingForPlayers.value) {
      print('Already joining or waiting, ignoring click');
      return;
    }

    try {
      _isJoiningTable.value = true;
      print('_isJoiningTable set to true');

      print('Getting available table using socket...');
      print('User ID: ${authViewModel.user!.id}, Token: ${authViewModel.user!.token}, Boot Value: ${_getBootValue()}, Players: ${selectedPlayer.value}');

      _rummySocketService.getTable(
        authViewModel.user!.id.toString(),
        authViewModel.user!.token.toString(),
        _getBootValue().toString(),
        selectedPlayer.value.toString(),
      );

      print('getTable method called, waiting for response...');
    } catch (e) {
      print('Error in _handlePlayNow: $e');
      _showErrorDialog('Failed to join game: $e');
      _isJoiningTable.value = false;
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _precacheImages();
  }

  @override
  void dispose() {
    selectedPlayer.dispose();
    _pointValue.dispose();
    _isJoiningTable.dispose();
    _isWaitingForPlayers.dispose();
    _connectionStatus.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  Future<void> _setLandscapeMode() async {
    await SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    await Future.delayed(const Duration(milliseconds: 300));
    if (mounted) {
      setState(() {
        _isLoading = false;
      });
      _fadeController.forward();
    }
  }

  Future<void> _precacheImages() async {
    final images = [
      'assets/dashboard_bg.png',
      'assets/profile.png',
      'assets/dashboard_assets/availabe_balance_logo.png',
      'assets/dashboard_assets/coins_logo.png',
      'assets/dashboard_assets/cards_point.png',
      'assets/dashboard_assets/spade.png',
    ];
    for (final image in images) {
      await precacheImage(AssetImage(image), context);
    }
  }

  void _incrementPointValue() {
    final currentIndex = _allowedPointValues.indexOf(_pointValue.value);
    if (currentIndex < _allowedPointValues.length - 1) {
      _pointValue.value = _allowedPointValues[currentIndex + 1];
    }
  }

  void _decrementPointValue() {
    final currentIndex = _allowedPointValues.indexOf(_pointValue.value);
    if (currentIndex > 0) {
      _pointValue.value = _allowedPointValues[currentIndex - 1];
    }
  }

  double _getBootValue() {
    return _pointToBootValueMap[_pointValue.value] ?? 80.0;
  }

  Widget _buildNavigationButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    required double width,
    required double height,
  }) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: width * 0.02, vertical: height * 0.005),
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: width,
          padding: EdgeInsets.symmetric(
            vertical: height * 0.01,
            horizontal: width * 0.01,
          ),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(width * 0.08),
            border: Border.all(
              color: Colors.amber.withOpacity(0.2),
              width: width * 0.015,
            ),
            gradient: LinearGradient(
              colors: [Colors.black.withOpacity(0.6), Colors.black.withOpacity(0.8)],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                color: Colors.amber,
                size: height * 0.05,
              ),
              SizedBox(height: height * 0.01),
              Text(
                label,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: height * 0.025,
                  fontWeight: FontWeight.w600,
                ),
                textAlign: TextAlign.center,
                overflow: TextOverflow.ellipsis,
                maxLines: 2,
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final mediaQuery = MediaQuery.of(context);
    final screenWidth = mediaQuery.size.width;
    final screenHeight = mediaQuery.size.height;
    final topPadding = mediaQuery.padding.top;
    final bottomPadding = mediaQuery.padding.bottom;

    return Scaffold(
      backgroundColor: Colors.transparent,
      resizeToAvoidBottomInset: false,
      body: Consumer<AuthViewModel>(
        builder: (context, authViewModel, child) {
          final user = authViewModel.user!;
          return LayoutBuilder(
            builder: (context, constraints) {
              final availableWidth = constraints.maxWidth;
              final availableHeight = constraints.maxHeight;
              final padding = availableWidth * 0.005;

              return Stack(
                children: [
                  Image.asset(
                    'assets/dashboard_bg.png',
                    fit: BoxFit.cover,
                    width: availableWidth,
                    height: availableHeight,
                    color: const Color(0xFFF51925).withOpacity(0.5),
                    colorBlendMode: BlendMode.dstOver,
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                      top: topPadding > 0 ? topPadding : availableHeight * 0.01,
                      bottom: bottomPadding > 0 ? bottomPadding : availableHeight * 0.01,
                      left: availableWidth * 0.01,
                      right: availableWidth * 0.01,
                    ),
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          // Header section
                          Padding(
                            padding: EdgeInsets.all(padding),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Stack(
                                  children: [
                                    GestureDetector(
                                      onTap: () {
                                        print('Profile button tapped');
                                      },
                                      child: Image.asset(
                                        'assets/profile.png',
                                        width: availableWidth * 0.08,
                                        height: availableHeight * 0.12,
                                        fit: BoxFit.contain,
                                      ),
                                    ),
                                    Positioned(
                                      right: availableWidth * 0.015,
                                      top: availableHeight * 0.02,
                                      child: Container(
                                        width: availableWidth * 0.015,
                                        height: availableWidth * 0.015,
                                        decoration: BoxDecoration(
                                          color: widget.socketService.isConnected
                                              ? Colors.green
                                              : Colors.red,
                                          shape: BoxShape.circle,
                                          border: Border.all(
                                            color: Colors.white,
                                            width: 2,
                                          ),
                                          boxShadow: [
                                            BoxShadow(
                                              color: Colors.black.withOpacity(0.3),
                                              blurRadius: 4,
                                              offset: const Offset(0, 2),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(width: padding),
                                Container(
                                  width: availableWidth * 0.22,
                                  height: availableHeight * 0.1,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(availableHeight * 0.05),
                                    gradient: const LinearGradient(
                                      colors: [Colors.red, Colors.yellowAccent, Colors.red],
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                    ),
                                  ),
                                  child: Container(
                                    margin: EdgeInsets.all(availableHeight * 0.005),
                                    decoration: BoxDecoration(
                                      color: Colors.amber,
                                      borderRadius: BorderRadius.circular(availableHeight * 0.045),
                                    ),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                      children: [
                                        Container(
                                          width: availableHeight * 0.05,
                                          height: availableHeight * 0.05,
                                          decoration: const BoxDecoration(
                                            color: Colors.white,
                                            shape: BoxShape.circle,
                                          ),
                                          child: IconButton(
                                            icon: Icon(
                                              Icons.add_circle,
                                              color: Colors.amber,
                                              size: availableHeight * 0.05,
                                            ),
                                            onPressed: () {
                                              print('Add Balance tapped');
                                              _connectToSocketServer();
                                            },
                                            padding: EdgeInsets.zero,
                                            constraints: const BoxConstraints(),
                                          ),
                                        ),
                                        Row(
                                          children: [
                                            Text(
                                              '₹ ',
                                              style: TextStyle(
                                                color: Colors.black,
                                                fontSize: availableHeight * 0.04,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            Text(
                                              user.wallet,
                                              style: TextStyle(
                                                color: Colors.black,
                                                fontSize: availableHeight * 0.04,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ],
                                        ),
                                        Image.asset(
                                          'assets/dashboard_assets/availabe_balance_logo.png',
                                          width: availableWidth * 0.04,
                                          height: availableHeight * 0.08,
                                          fit: BoxFit.contain,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                const Spacer(),
                                Container(
                                  width: availableWidth * 0.17,
                                  height: availableHeight * 0.1,
                                  decoration: BoxDecoration(
                                    color: Colors.black.withOpacity(0.6),
                                    borderRadius: BorderRadius.circular(availableHeight * 0.025),
                                    border: Border.all(color: Colors.amber),
                                  ),
                                  child: Row(
                                    children: [
                                      SizedBox(width: availableWidth * 0.01),
                                      Image.asset(
                                        'assets/dashboard_assets/coins_logo.png',
                                        height: availableHeight * 0.06,
                                        fit: BoxFit.contain,
                                      ),
                                      SizedBox(width: availableWidth * 0.01),
                                      Expanded(
                                        child: Text(
                                          '15890',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: availableHeight * 0.04,
                                            fontWeight: FontWeight.bold,
                                          ),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(width: availableWidth * 0.01),
                                Container(
                                  width: availableWidth * 0.17,
                                  height: availableHeight * 0.1,
                                  decoration: BoxDecoration(
                                    color: Colors.black.withOpacity(0.6),
                                    borderRadius: BorderRadius.circular(availableHeight * 0.025),
                                    border: Border.all(color: Colors.amber),
                                  ),
                                  child: Row(
                                    children: [
                                      SizedBox(width: availableWidth * 0.01),
                                      Image.asset(
                                        'assets/dashboard_assets/cards_point.png',
                                        height: availableHeight * 0.06,
                                        fit: BoxFit.contain,
                                      ),
                                      SizedBox(width: availableWidth * 0.01),
                                      Expanded(
                                        child: Text(
                                          '15890',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: availableHeight * 0.04,
                                            fontWeight: FontWeight.bold,
                                          ),
                                          overflow: TextOverflow.ellipsis,
                                         ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          // Main content area
                          SizedBox(
                            height: availableHeight - (topPadding + bottomPadding + availableHeight * 0.1),
                            child: Row(
                              children: [
                                Expanded(
                                  child: SingleChildScrollView(
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Text(
                                          'Select Players',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: (availableHeight * 0.045).clamp(16.0, 28.0),
                                            fontFamily: 'Arial',
                                            fontStyle: FontStyle.italic,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        SizedBox(height: availableHeight * 0.02),
                                        ValueListenableBuilder<int>(
                                          valueListenable: selectedPlayer,
                                          builder: (context, value, child) {
                                            return Container(
                                              width: (availableWidth * 0.3).clamp(180.0, 360.0),
                                              height: (availableHeight * 0.1).clamp(50.0, 90.0),
                                              decoration: BoxDecoration(
                                                border: Border.all(color: Colors.white, width: 2),
                                                borderRadius: BorderRadius.circular(availableHeight * 0.025),
                                                gradient: const LinearGradient(
                                                  colors: [Colors.white, Colors.amber, Colors.amber, Colors.amber],
                                                  begin: Alignment.topCenter,
                                                  end: Alignment.bottomCenter,
                                                  stops: [0.0, 0.3, 0.5, 1.0],
                                                ),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Colors.black.withOpacity(0.3),
                                                    blurRadius: 8,
                                                    offset: const Offset(0, 4),
                                                  ),
                                                ],
                                              ),
                                              child: Row(
                                                children: [
                                                  Expanded(
                                                    child: GestureDetector(
                                                      onTap: () {
                                                        selectedPlayer.value = 2;
                                                        print('The value selected is 2');
                                                      },
                                                      child: Container(
                                                        height: double.infinity,
                                                        decoration: BoxDecoration(
                                                          borderRadius: BorderRadius.only(
                                                            topLeft: Radius.circular(availableHeight * 0.025),
                                                            bottomLeft: Radius.circular(availableHeight * 0.025),
                                                          ),
                                                          gradient: value == 2
                                                              ? null
                                                              : const LinearGradient(
                                                            colors: [Colors.white, Colors.black87, Colors.black, Colors.black87],
                                                            begin: Alignment.topCenter,
                                                            end: Alignment.bottomCenter,
                                                            stops: [0.0, 0.3, 0.5, 1.0],
                                                          ),
                                                        ),
                                                        child: Center(
                                                          child: Text(
                                                            '2',
                                                            style: TextStyle(
                                                              color: value == 2 ? Colors.black : Colors.white,
                                                              fontSize: (availableHeight * 0.045).clamp(16.0, 28.0),
                                                              fontWeight: FontWeight.bold,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Expanded(
                                                    child: GestureDetector(
                                                      onTap: () {
                                                        selectedPlayer.value = 6;
                                                        print('The value selected is 6');
                                                      },
                                                      child: Container(
                                                        height: double.infinity,
                                                        decoration: BoxDecoration(
                                                          borderRadius: BorderRadius.only(
                                                            topRight: Radius.circular(availableHeight * 0.025),
                                                            bottomRight: Radius.circular(availableHeight * 0.025),
                                                          ),
                                                          gradient: value == 6
                                                              ? null
                                                              : const LinearGradient(
                                                            colors: [Colors.white, Colors.black87, Colors.black, Colors.black87],
                                                            begin: Alignment.topCenter,
                                                            end: Alignment.bottomCenter,
                                                            stops: [0.0, 0.3, 0.5, 1.0],
                                                          ),
                                                        ),
                                                        child: Center(
                                                          child: Text(
                                                            '6',
                                                            style: TextStyle(
                                                              color: value == 6 ? Colors.black : Colors.white,
                                                              fontSize: (availableHeight * 0.045).clamp(16.0, 28.0),
                                                              fontWeight: FontWeight.bold,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            );
                                          },
                                        ),
                                        SizedBox(height: availableHeight * 0.03),
                                        ValueListenableBuilder<double>(
                                          valueListenable: _pointValue,
                                          builder: (context, pointValue, child) {
                                            return Container(
                                              padding: EdgeInsets.symmetric(
                                                horizontal: availableWidth * 0.05,
                                                vertical: availableHeight * 0.02,
                                              ),
                                              constraints: BoxConstraints(
                                                maxWidth: availableWidth * 0.6,
                                              ),
                                              decoration: BoxDecoration(
                                                border: Border.all(color: Colors.white, width: 1),
                                                color: Colors.black.withOpacity(0.6),
                                                borderRadius: BorderRadius.circular(availableHeight * 0.025),
                                                gradient: const LinearGradient(
                                                  colors: [Colors.white, Colors.black26, Colors.black38, Colors.black45],
                                                  begin: Alignment.topCenter,
                                                  end: Alignment.bottomCenter,
                                                  stops: [0.0, 0.3, 0.5, 1.0],
                                                ),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Colors.black.withOpacity(0.3),
                                                    blurRadius: 8,
                                                    offset: const Offset(0, 4),
                                                  ),
                                                ],
                                              ),
                                              child: Row(
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  Flexible(
                                                    child: Text(
                                                      'Point Value = ${pointValue.toStringAsFixed(2)}',
                                                      style: TextStyle(
                                                        color: Colors.white,
                                                        fontSize: (availableHeight * 0.04).clamp(14.0, 24.0),
                                                        fontWeight: FontWeight.bold,
                                                      ),
                                                      overflow: TextOverflow.ellipsis,
                                                    ),
                                                  ),
                                                  SizedBox(width: availableWidth * 0.015),
                                                  Image.asset(
                                                    'assets/dashboard_assets/spade.png',
                                                    width: availableWidth * 0.04,
                                                    height: availableHeight * 0.06,
                                                    fit: BoxFit.contain,
                                                    color: Colors.amber,
                                                  ),
                                                ],
                                              ),
                                            );
                                          },
                                        ),
                                        SizedBox(height: availableHeight * 0.03),
                                        ValueListenableBuilder<double>(
                                          valueListenable: _pointValue,
                                          builder: (context, pointValue, child) {
                                            return Container(
                                              constraints: BoxConstraints(
                                                maxWidth: availableWidth * 0.7,
                                              ),
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  // Enhanced Minus button
                                                  Container(
                                                    width: (availableHeight * 0.04).clamp(30.0, 30.0),
                                                    height: (availableHeight * 0.04).clamp(30.0, 30.0),
                                                    decoration: BoxDecoration(
                                                      color: Colors.white,
                                                      shape: BoxShape.circle,
                                                      boxShadow: [
                                                        BoxShadow(
                                                          color: Colors.black.withOpacity(0.2),
                                                          blurRadius: 4,
                                                          offset: const Offset(0, 2),
                                                        ),
                                                      ],
                                                    ),
                                                    child: IconButton(
                                                      icon: Icon(
                                                        Icons.remove_circle,
                                                        color: Colors.black,
                                                        size: (availableHeight * 0.06).clamp(30.0, 40.0),
                                                      ),
                                                      onPressed: _decrementPointValue,
                                                      padding: EdgeInsets.zero,
                                                      constraints: const BoxConstraints(),
                                                    ),
                                                  ),
                                                  // Slider and boot value labels
                                                  Expanded(
                                                    child: Container(
                                                      height: (availableHeight * 0.15).clamp(70.0, 100.0),
                                                      child: Stack(
                                                        alignment: Alignment.center,
                                                        children: [
                                                          // Slider
                                                          Positioned(
                                                            top: 0,
                                                            left: 0,
                                                            right: 0,
                                                            child: SliderTheme(
                                                              data: SliderTheme.of(context).copyWith(
                                                                trackHeight: 6.0,
                                                                activeTrackColor: Colors.amberAccent,
                                                                inactiveTrackColor: Colors.grey[800],
                                                                trackShape: const RoundedRectSliderTrackShape(),
                                                                thumbShape: CustomSliderThumbShape(
                                                                  thumbRadius: (availableHeight * 0.025).clamp(10.0, 18.0),
                                                                  innerColor: Colors.amber,
                                                                  outerStrokeColor: Colors.white,
                                                                ),
                                                                overlayShape: const RoundSliderOverlayShape(overlayRadius: 25.0),
                                                                disabledThumbColor: Colors.grey[400],
                                                              ),
                                                              child: Slider(
                                                                value: _allowedPointValues.indexOf(_pointValue.value).toDouble(),
                                                                min: 0.0,
                                                                max: _allowedPointValues.length - 1.0,
                                                                divisions: _allowedPointValues.length - 1,
                                                                onChanged: (value) {
                                                                  final index = value.round();
                                                                  _pointValue.value = _allowedPointValues[index];
                                                                },
                                                                activeColor: Colors.amber,
                                                                inactiveColor: Colors.grey[800],
                                                              ),
                                                            ),
                                                          ),
                                                          // Boot value labels with dots
                                                          Positioned(
                                                            bottom: 0,
                                                            left: 0,
                                                            right: 0,
                                                            child: Row(
                                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                              children: _pointToBootValueMap.entries.map((entry) {
                                                                final bootValue = entry.value;
                                                                final isSelected = pointValue == entry.key;
                                                                return Column(
                                                                  children: [
                                                                    isSelected
                                                                        ? Container(
                                                                      width: 10,
                                                                      height: 10,
                                                                      decoration: const BoxDecoration(
                                                                        color: Colors.amber,
                                                                        shape: BoxShape.circle,
                                                                      ),
                                                                    )
                                                                        : const SizedBox(width: 10, height: 10),
                                                                    const SizedBox(height: 4),
                                                                    Text(
                                                                      '₹${bootValue.toStringAsFixed(0)}',
                                                                      style: TextStyle(
                                                                        color: isSelected ? Colors.amber : Colors.white,
                                                                        fontSize: (availableHeight * 0.03).clamp(12.0, 18.0),
                                                                        fontWeight: FontWeight.bold,
                                                                      ),
                                                                    ),
                                                                  ],
                                                                );
                                                              }).toList(),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  // Enhanced Plus button
                                                  Container(
                                                    width: (availableHeight * 0.04).clamp(30.0, 30.0),
                                                    height: (availableHeight * 0.04).clamp(30.0, 30.0),
                                                    decoration: BoxDecoration(
                                                      color: Colors.white,
                                                      shape: BoxShape.circle,
                                                      boxShadow: [
                                                        BoxShadow(
                                                          color: Colors.black.withOpacity(0.2),
                                                          blurRadius: 4,
                                                          offset: const Offset(0, 2),
                                                        ),
                                                      ],
                                                    ),
                                                    child: IconButton(
                                                      icon: Icon(
                                                        Icons.add_circle,
                                                        color: Colors.black,
                                                        size: (availableHeight * 0.06).clamp(30.0, 40.0),
                                                      ),
                                                      onPressed: _incrementPointValue,
                                                      padding: EdgeInsets.zero,
                                                      constraints: const BoxConstraints(),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            );
                                          },
                                        ),
                                        SizedBox(height: availableHeight * 0.03),
                                        ValueListenableBuilder<bool>(
                                          valueListenable: _isWaitingForPlayers,
                                          builder: (context, isWaiting, _) {
                                            return ValueListenableBuilder<bool>(
                                              valueListenable: _isJoiningTable,
                                              builder: (context, isJoining, _) {
                                                return LoginRegisterBtn(
                                                  textColor: Colors.black,
                                                  widthSize1: (availableWidth * 0.2).clamp(140.0, 220.0),
                                                  widthSize2: (availableWidth * 0.2).clamp(140.0, 220.0),
                                                  text: isWaiting
                                                      ? 'Finding Players...'
                                                      : isJoining
                                                      ? 'Joining Table...'
                                                      : 'Play Now',
                                                  outerContainerColor: isWaiting || isJoining
                                                      ? Colors.grey[600]!
                                                      : Colors.amber[800]!,
                                                  gradientColors: isWaiting || isJoining
                                                      ? [Colors.grey[300]!, Colors.grey[500]!, Colors.grey[700]!]
                                                      : [Colors.amber[100]!, Colors.amber, Colors.amber[600]!],
                                                  onPressed: (isWaiting || isJoining) ? null : _handlePlayNow,
                                                );
                                              },
                                            );
                                          },
                                        ),
                                        SizedBox(height: availableHeight * 0.03),
                                      ],
                                    ),
                                  ),
                                ),
                                // Side navigation
                                Container(
                                  width: availableWidth * 0.12,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(availableHeight * 0.025),
                                    color: Colors.transparent,
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black.withOpacity(0.3),
                                        blurRadius: 10,
                                        offset: const Offset(-2, 0),
                                      ),
                                    ],
                                  ),
                                  child: SingleChildScrollView(
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        _buildNavigationButton(
                                          icon: Icons.local_offer,
                                          label: 'Promotions',
                                          onTap: () {
                                            print('Promotions tapped');
                                          },
                                          width: availableWidth * 0.12,
                                          height: availableHeight,
                                        ),
                                        _buildNavigationButton(
                                          icon: Icons.account_balance_wallet,
                                          label: 'Withdraw',
                                          onTap: () {
                                            print('Withdraw tapped');
                                          },
                                          width: availableWidth * 0.12,
                                          height: availableHeight,
                                        ),
                                        _buildNavigationButton(
                                          icon: Icons.casino,
                                          label: 'My Game',
                                          onTap: () {
                                            print('My Game tapped');
                                          },
                                          width: availableWidth * 0.12,
                                          height: availableHeight,
                                        ),
                                        _buildNavigationButton(
                                          icon: Icons.support_agent,
                                          label: 'Support',
                                          onTap: () {
                                            print('Support tapped');
                                          },
                                          width: availableWidth * 0.12,
                                          height: availableHeight,
                                        ),
                                        _buildNavigationButton(
                                          icon: Icons.settings,
                                          label: 'Settings',
                                          onTap: () {
                                            print('Settings tapped');
                                          },
                                          width: availableWidth * 0.12,
                                          height: availableHeight,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          );
        },
      ),
    );
  }
}