import 'package:arka_infotech/frontend/Screens/register_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../provider/auth_view_model.dart';
import 'components/custom_textFormField.dart';
import 'otp_verification_page.dart';

class ForgotPasswordDialog extends StatefulWidget {
  const ForgotPasswordDialog({super.key});

  @override
  State<ForgotPasswordDialog> createState() => _ForgotPasswordDialogState();
}

class _ForgotPasswordDialogState extends State<ForgotPasswordDialog> {
  final _formKey = GlobalKey<FormState>();
  final _phoneController = TextEditingController();
  final _phoneFocusNode = FocusNode();

  @override
  void dispose() {
    _phoneController.dispose();
    _phoneFocusNode.dispose();
    super.dispose();
  }

  void _handleForgotPassword() async {
    if (_formKey.currentState!.validate()) {
      final authViewModel = context.read<AuthViewModel>();
      final success = await authViewModel.sendOtp(_phoneController.text, 'forgot_password');
      if (success) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('OTP sent to ${_phoneController.text}')),
        );
        Navigator.pop(context);
        showOtpVerificationDialog(
          context,
          _phoneController.text,
          'forgot_password',
              (verified) {
            if (verified) {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ResetPasswordPage(mobile: _phoneController.text),
                ),
              );
            }
          },
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(authViewModel.errorMessage ?? 'Failed to send OTP')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: Colors.black.withOpacity(0.8),
      title: const Text(
        'Forgot Password',
        style: TextStyle(color: Colors.white),
      ),
      content: Form(
        key: _formKey,
        child: CustomTextFormField(
          controller: _phoneController,
          focusNode: _phoneFocusNode,
          labelText: 'Phone Number',
          keyboardType: TextInputType.phone,
          icon: Icons.phone,
          inputFormatters: [
            FilteringTextInputFormatter.digitsOnly,
            LengthLimitingTextInputFormatter(20),
          ],
          validator: (value) => value == null || value.isEmpty
              ? 'Please enter your phone number'
              : null,
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel', style: TextStyle(color: Colors.white)),
        ),
        TextButton(
          onPressed: _handleForgotPassword,
          child: const Text('Submit', style: TextStyle(color: Colors.amber)),
        ),
      ],
    );
  }
}

class ResetPasswordPage extends StatelessWidget {
  final String mobile;
  const ResetPasswordPage({super.key, required this.mobile});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Reset Password')),
      body: Center(child: Text('Reset password for $mobile')),
    );
  }
}