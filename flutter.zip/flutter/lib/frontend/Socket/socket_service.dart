import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;

class SocketService extends ChangeNotifier {
  final String backendUrl;
  IO.Socket? _socket;
  Timer? _pingTimer;
  bool _isConnected = false;


  SocketService({required this.backendUrl});

  bool get isConnected => _socket != null && _socket!.connected;

  Future<void> connect() async {
    if (_socket != null && _socket!.connected) {
      print('Socket already connected');
      return;
    }

    try {
      _socket = IO.io(
        backendUrl,
        IO.OptionBuilder()
            .setTransports(['websocket'])
            .disableAutoConnect()
            .setTimeout(10000) // Connection timeout
            .build(),
      );

      _socket!.connect();

      await Future.any([
        Future(() async {
          while (!_socket!.connected) {
            await Future.delayed(const Duration(milliseconds: 100));
          }
          _updateConnectionStatus(true);
          print('Socket connected successfully');
        }),
        Future.delayed(const Duration(seconds: 10), () {
          throw Exception('Socket connection timed out');
        }),
      ]);

      _socket!.onConnect((_) {
        print('Socket connected');
        _updateConnectionStatus(true);
        _startPing();
      });
      _socket!.onDisconnect((_) {
        print('Socket disconnected');
        _updateConnectionStatus(false);
        _stopPing();
        _reconnect();
      });
      _socket!.onError((error) => print('Socket error: $error'));
      // Add this to log all incoming events
      _socket!.onAny((event, data) {
        print('Received event: $event with data: $data');
      });
    } catch (e) {
      print('Socket connection failed: $e');
      rethrow;
    }
  }

  void _startPing() {
    _stopPing(); // Clear any existing timer
    _pingTimer = Timer.periodic(const Duration(seconds: 30), (timer) {
      if (isConnected) {
        _socket!.emit('ping', 'keep-alive');
        print('Sent ping to keep socket alive');
      } else {
        _stopPing();
      }
    });
  }

  void _updateConnectionStatus(bool status) {
    if (_isConnected != status) {
      _isConnected = status;
      notifyListeners(); // <-- NOTIFY on status change
    }
  }

  void _stopPing() {
    _pingTimer?.cancel();
    _pingTimer = null;
  }

  Future<void> _reconnect() async {
    if (_socket != null && !_socket!.connected) {
      print('Attempting to reconnect socket...');
      try {
        await connect();
        print('Socket reconnected successfully');
      } catch (e) {
        print('Socket reconnection failed: $e');
        Future.delayed(const Duration(seconds: 5), () => _reconnect());
      }
    }
  }

  void sendMessage(String event, dynamic data) {
    if (_socket != null && _socket!.connected) {
      _socket!.emit(event, data);
      print('Sent message: $event with data: $data');
    } else {
      print('Socket not connected, cannot send message: $event');
    }
  }

  void onEvent(String event, Function(dynamic) callback) {
    _socket?.on(event, callback);
  }

  Future<void> disconnect() async {
    _stopPing();
    if (_socket != null && _socket!.connected) {
      _socket!.disconnect();
      print('Socket disconnected');
    }
    _socket = null;
  }
}