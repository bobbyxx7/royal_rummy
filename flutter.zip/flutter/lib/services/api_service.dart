import 'dart:convert';
import 'package:http/http.dart' as http;
import '../constants/api_constants.dart';

class ApiService {
  final http.Client _client = http.Client();
  String? _sessionCookie;

  /// Check if API server is reachable
  Future<bool> checkApiConnectivity() async {
    try {
      final response = await _client.head(
        Uri.parse(ApiConstants.apiUrl),
        headers: {
          'Token': ApiConstants.token,
        },
      ).timeout(const Duration(seconds: 5));

      // If we get any response (even error), the API is reachable
      return response.statusCode >= 200 && response.statusCode < 500;
    } catch (e) {
      print('API connectivity check failed: $e');
      return false;
    }
  }

  // Future<Map<String, dynamic>> getTable(String userId, String token, String bootValue, String noOfPlayers) async {
  //   try {
  //     final body = {
  //       'user_id': userId,
  //       'token': token,
  //       'boot_value': bootValue,
  //       'no_of_players': noOfPlayers
  //     };
  //
  //     final headers = {
  //       'Cookie': ApiConstants.cookie,
  //       'Token': ApiConstants.token,
  //     };
  //
  //     print('Sending getTable request...');
  //     final response = await _client.post(
  //       Uri.parse(ApiConstants.getTable),
  //       headers: headers,
  //       body: body,
  //     );
  //
  //     print('Response Status: ${response.statusCode}');
  //     return jsonDecode(response.body);
  //   } catch (e) {
  //     print('Login request failed: $e');
  //     return {
  //       'success': false,
  //       'message': 'Network error: $e',
  //     };
  //   }
  // }

  Future<Map<String, dynamic>> login(String mobile, String password) async {
    try {
      final body = {
        'mobile': mobile,
        'password': password,
      };

      final headers = {
        'Cookie': ApiConstants.cookie,
        'Token': ApiConstants.token,
      };

      print('Sending login request...');
      final response = await _client.post(
        Uri.parse(ApiConstants.Login),
        headers: headers,
        body: body,
      );

      print('Response Status: ${response.statusCode}');
      return jsonDecode(response.body);
    } catch (e) {
      print('Login request failed: $e');
      return {
        'success': false,
        'message': 'Network error: $e',
      };
    }
  }

  Future<Map<String, dynamic>> sendOtp(String mobile, String type) async {
    try {
      final body = {
        'mobile': mobile,
        'type': type,
      };
      final headers = {
        'Token': ApiConstants.token,
        'Content-Type': 'application/x-www-form-urlencoded',
        'Cookie': ApiConstants.cookie,
      };
      print('Sending OTP request to ${ApiConstants.sendOtp} with body: $body');
      final response = await _client.post(
        Uri.parse(ApiConstants.sendOtp),
        headers: headers,
        body: body,
      );
      _sessionCookie = response.headers['set-cookie'] ?? _sessionCookie;
      print('OTP response: status=${response.statusCode}, body=${response.body}');
      return jsonDecode(response.body);
    } catch (e) {
      print('OTP request failed: $e');
      return {'success': false, 'message': 'Network error: $e'};
    }
  }

  /// Tempory unavailable need to change the api url...
  Future<Map<String, dynamic>> verifyOtp({
    required String otp,
    required String otpId,
    required String mobile,
  }) async {
    try {
      final body = {
        'otp': otp,
        'otp_id': otpId,
        'mobile': mobile,
      };
      final headers = {
        'Token': ApiConstants.token,
        'Content-Type': 'application/x-www-form-urlencoded',
        'Cookie': ApiConstants.cookie,
      };
      print('Sending verify OTP request to ${ApiConstants.register} with body: $body');
      final response = await _client.post(
        Uri.parse(ApiConstants.register),
        headers: headers,
        body: body,
      );
      _sessionCookie = response.headers['set-cookie'] ?? _sessionCookie;
      print('Verify OTP response: status=${response.statusCode}, body=${response.body}');
      return jsonDecode(response.body);
    } catch (e) {
      print('Verify OTP request failed: $e');
      return {'success': false, 'message': 'Network error: $e'};
    }
  }

  Future<Map<String, dynamic>> register({
    required String name,
    required String mobile,
    required String otpId,
    required String password,
    required String gender,
    String? referralCode,
  }) async {
    try {
      final body = {
        'name': name,
        'mobile': mobile,
        'password': password,
        'gender': gender,
        'otp_id': otpId,
        if (referralCode != null) 'referral_code': referralCode,
      };
      final headers = {
        'Token': ApiConstants.token,
        'Content-Type': 'application/x-www-form-urlencoded',
        'Cookie': ApiConstants.cookie,
      };
      print('Sending registration request to ${ApiConstants.register} with body: $body');
      final response = await _client.post(
        Uri.parse(ApiConstants.register),
        headers: headers,
        body: body,
      );
      _sessionCookie = response.headers['set-cookie'] ?? _sessionCookie;
      print('Registration response: status=${response.statusCode}, body=${response.body}');
      return jsonDecode(response.body);
    } catch (e) {
      print('Registration request failed: $e');
      return {'success': false, 'message': 'Network error: $e'};
    }
  }

  Future<Map<String, dynamic>> updateUserData(String userId, Map<String, dynamic> updatedFields) async {
    try {
      final body = {
        'user_id': userId,
        ...updatedFields,
      };
      final headers = {
        'Token': ApiConstants.token,
        'Content-Type': 'application/x-www-form-urlencoded',
        'Cookie': _sessionCookie ?? ApiConstants.cookie,
      };
      print('Sending user data update request with body: $body');
      final response = await _client.post(
        Uri.parse(ApiConstants.updateUserData), // Add to api_constants.dart
        headers: headers,
        body: body,
      );
      print('User data update response: status=${response.statusCode}, body=${response.body}');
      return jsonDecode(response.body);
    } catch (e) {
      print('User data update request failed: $e');
      return {'success': false, 'message': 'Network error: $e'};
    }
  }






  void dispose() {
    _client.close();
  }
}