// lib/services/secure_storage_service.dart
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../model/user_model.dart';

class SecureStorageService {
  final _storage = const FlutterSecureStorage();

  Future<void> saveUserData(UserModel user) async {
    print('Saving user data: ${user.toJson()}');
    await _storage.write(key: 'user_id', value: user.id);
    await _storage.write(key: 'name', value: user.name);
    await _storage.write(key: 'mobile', value: user.mobile);
    await _storage.write(key: 'token', value: user.token);
    await _storage.write(key: 'wallet', value: user.wallet);
    await _storage.write(key: 'gender', value: user.gender);
    await _storage.write(key: 'referral_code', value: user.referralCode);
    await _storage.write(key: 'user_type', value: user.userType);
    print('User data saved successfully');
  }

  Future<Map<String, String?>> getUserData() async {
    return {
      'user_id': await _storage.read(key: 'user_id'),
      'name': await _storage.read(key: 'name'),
      'mobile': await _storage.read(key: 'mobile'),
      'token': await _storage.read(key: 'token'),
      'wallet': await _storage.read(key: 'wallet'),
      'gender': await _storage.read(key: 'gender'),
      'referral_code': await _storage.read(key: 'referral_code'),
      'user_type': await _storage.read(key: 'user_type'),
    };
  }

  Future<void> clearUserData() async {
    await _storage.deleteAll();
  }
}