import 'dart:async';
import 'package:flutter/material.dart';
import '../frontend/Socket/socket_service.dart';
import '../constants/api_constants.dart';
import 'package:http/http.dart' as http;

enum ServerStatus { 
  connecting, 
  connected, 
  disconnected, 
  maintenance, 
  error 
}

enum ConnectivityType {
  api,    // For login/registration
  socket  // For real-time games
}

class ServerConnectivityService extends ChangeNotifier {
  static ServerConnectivityService? _instance;
  static ServerConnectivityService get instance => _instance ??= ServerConnectivityService._internal();
  
  ServerConnectivityService._internal();

  ServerStatus _apiStatus = ServerStatus.disconnected;
  ServerStatus _socketStatus = ServerStatus.disconnected;
  bool _isChecking = false;
  Timer? _healthCheckTimer;
  static const Duration _healthCheckInterval = Duration(minutes: 2);

  // Getters for different connectivity types
  ServerStatus get apiStatus => _apiStatus;
  ServerStatus get socketStatus => _socketStatus;
  bool get isApiConnected => _apiStatus == ServerStatus.connected;
  bool get isSocketConnected => _socketStatus == ServerStatus.connected;
  bool get isChecking => _isChecking;
  bool get isApiInMaintenance => _apiStatus == ServerStatus.maintenance;
  bool get isSocketInMaintenance => _socketStatus == ServerStatus.maintenance;

  /// Initialize connectivity check (no checks at startup)
  Future<void> initializeConnectivity() async {
    // No initialization at startup - API check only when user clicks login/register
    _updateApiStatus(ServerStatus.disconnected);
    _updateSocketStatus(ServerStatus.disconnected);
  }

  /// Check connectivity when user tries to login/register
  Future<bool> checkLoginConnectivity() async {
    if (_isChecking) return false;
    
    _isChecking = true;
    notifyListeners();
    
    try {
      // Step 1: Check Socket connectivity first
      await _checkSocketConnectivity();
      
      // Step 2: If Socket is connected, test actual login API
      if (isSocketConnected) {
        final apiWorks = await testLoginApi();
        if (!apiWorks) {
          _updateApiStatus(ServerStatus.disconnected);
        }
      }
      
      return canLogin;
    } finally {
      _isChecking = false;
      notifyListeners();
    }
  }



  /// Check API server connectivity
  Future<void> _checkApiConnectivity() async {
    try {
      // Try a simple HEAD request to the API base URL
      final response = await http.head(
        Uri.parse(ApiConstants.apiUrl),
        headers: {
          'Token': ApiConstants.token,
        },
      ).timeout(const Duration(seconds: 5));

      if (response.statusCode == 200 || response.statusCode == 404) {
        // 404 is okay - it means the server is reachable
        _updateApiStatus(ServerStatus.connected);
      } else {
        _updateApiStatus(ServerStatus.maintenance);
      }
    } catch (e) {
      debugPrint('[CONNECTIVITY] API check failed: $e');
      // If we can't reach the API at all, mark as disconnected
      _updateApiStatus(ServerStatus.disconnected);
    }
  }

  /// Check Socket server connectivity using global socket service
  Future<void> _checkSocketConnectivity() async {
    try {
      // Get the global socket service from Provider
      // Note: This requires the socket service to be available in the widget tree
      // For now, we'll create a temporary connection for checking
      final tempSocketService = SocketService(backendUrl: ApiConstants.socketUrl);
      
      // Try to connect with shorter timeout for better UX
      await tempSocketService.connect().timeout(
        const Duration(seconds: 5),
        onTimeout: () {
          throw TimeoutException('Socket connection timeout', const Duration(seconds: 5));
        },
      );
      
      // If connection successful, check if server is in maintenance
      if (tempSocketService.isConnected) {
        await _checkSocketHealth(tempSocketService);
      } else {
        _updateSocketStatus(ServerStatus.disconnected);
      }
      
      tempSocketService.disconnect();
      
    } on TimeoutException {
      _updateSocketStatus(ServerStatus.disconnected);
    } catch (e) {
      debugPrint('[CONNECTIVITY] Socket connection failed: $e');
      _updateSocketStatus(ServerStatus.disconnected);
    }
  }

  /// Check if socket server is in maintenance mode
  Future<void> _checkSocketHealth(SocketService socketService) async {
    try {
      // Send a health check ping
      socketService.sendMessage('health_check', {
        'timestamp': DateTime.now().millisecondsSinceEpoch,
        'client': 'mobile_app',
      });
      
      // Wait for response (you might need to implement this based on your server)
      await Future.delayed(const Duration(seconds: 2));
      
      // For now, assume server is healthy if connection is successful
      // You can implement actual health check logic here
      _updateSocketStatus(ServerStatus.connected);
      _startHealthCheckTimer();
      
    } catch (e) {
      debugPrint('[CONNECTIVITY] Socket health check failed: $e');
      _updateSocketStatus(ServerStatus.maintenance);
    }
  }



  /// Start periodic health check
  void _startHealthCheckTimer() {
    _healthCheckTimer?.cancel();
    _healthCheckTimer = Timer.periodic(_healthCheckInterval, (timer) {
      if (_socketStatus == ServerStatus.connected) {
        _checkSocketConnectivity();
      }
    });
  }

  /// Update API status and notify listeners
  void _updateApiStatus(ServerStatus newStatus) {
    if (_apiStatus != newStatus) {
      _apiStatus = newStatus;
      debugPrint('[CONNECTIVITY] API Status changed to: $newStatus');
      notifyListeners();
    }
  }

  /// Update Socket status and notify listeners
  void _updateSocketStatus(ServerStatus newStatus) {
    if (_socketStatus != newStatus) {
      _socketStatus = newStatus;
      debugPrint('[CONNECTIVITY] Socket Status changed to: $newStatus');
      notifyListeners();
    }
  }

  /// Manual retry
  Future<void> retryConnection() async {
    // Check both Socket and API for manual retry
    await _checkSocketConnectivity();
    if (isSocketConnected) {
      await _checkApiConnectivity();
    }
  }

  /// Get user-friendly status message for specific type
  String getStatusMessage(ConnectivityType type) {
    final status = type == ConnectivityType.api ? _apiStatus : _socketStatus;
    switch (status) {
      case ServerStatus.connecting:
        return 'Checking ${type.name} connection...';
      case ServerStatus.connected:
        return '${type.name.toUpperCase()} server is online';
      case ServerStatus.disconnected:
        return 'Unable to connect to ${type.name} server';
      case ServerStatus.maintenance:
        return '${type.name.toUpperCase()} server is under maintenance';
      case ServerStatus.error:
        return '${type.name.toUpperCase()} connection error occurred';
    }
  }

  /// Get appropriate action for status
  String getActionMessage(ConnectivityType type) {
    final status = type == ConnectivityType.api ? _apiStatus : _socketStatus;
    switch (status) {
      case ServerStatus.connecting:
        return 'Please wait...';
      case ServerStatus.connected:
        return 'You can now proceed';
      case ServerStatus.disconnected:
        return 'Please check your internet connection and try again';
      case ServerStatus.maintenance:
        return 'Please try again later';
      case ServerStatus.error:
        return 'Please try again or contact support';
    }
  }

  /// Check if login/registration should be allowed
  /// Login requires BOTH Socket AND API to be connected
  bool get canLogin => isSocketConnected && isApiConnected;

  /// Test actual login API functionality
  Future<bool> testLoginApi() async {
    try {
      // Try a simple POST request to the login endpoint
      final response = await http.post(
        Uri.parse(ApiConstants.Login),
        headers: {
          'Token': ApiConstants.token,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: {
          'mobile': 'test',
          'password': 'test',
        },
      ).timeout(const Duration(seconds: 3));

      // If we get any response (even error), the API is reachable
      return response.statusCode >= 200 && response.statusCode < 500;
    } catch (e) {
      debugPrint('[CONNECTIVITY] Login API test failed: $e');
      return false;
    }
  }

  /// Check if games should be allowed
  bool get canPlayGames => isSocketConnected;

  /// Dispose resources
  @override
  void dispose() {
    _healthCheckTimer?.cancel();
    super.dispose();
  }
} 