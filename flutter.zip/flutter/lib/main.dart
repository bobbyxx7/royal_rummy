// lib/main.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'frontend/Screens/Game_Screen/Game_Lobby/point_game/Services/CardHandProvider.dart';
import 'provider/auth_view_model.dart';
import 'provider/pointGameProvider.dart';
import 'provider/app_state_provider.dart';
import 'frontend/Socket/socket_service.dart';
import 'frontend/Screens/login_page.dart';
import 'frontend/Screens/register_page.dart';
import 'frontend/Screens/otp_verification_page.dart';
import 'frontend/Screens/dashboard_page.dart';
import 'constants/api_constants.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();


  // Precache images
  Future<void> precacheImages() async {
    final context = WidgetsBinding.instance.rootElement;
    if (context != null) {
      await precacheImage(const AssetImage('assets/login_background_image.png'), context);
      await precacheImage(const AssetImage('assets/login_logo.png'), context);
    }
  }

  // Initialize socket service (but don't connect yet)
  final socketService = SocketService(backendUrl: ApiConstants.socketUrl);
  print('Socket service initialized in main.dart (not connected yet)');

  await precacheImages();

  runApp(

    MultiProvider(
      providers: [
        ChangeNotifierProvider<SocketService>.value(value: socketService),
        ChangeNotifierProvider(create: (_) => AuthViewModel()),
        ChangeNotifierProvider(create: (_) => PointGameProvider()),
        // AppStateProvider depends on AuthViewModel and SocketService
        ChangeNotifierProxyProvider2<AuthViewModel, SocketService, AppStateProvider>(
          create: (context) => AppStateProvider(
            context.read<AuthViewModel>(),
            context.read<SocketService>(),
          ),
          update: (context, authViewModel, socketService, previous) => 
            previous ?? AppStateProvider(authViewModel, socketService),
        ),
        ChangeNotifierProvider(
          create: (context) => GameProvider(context.read<PointGameProvider>()),
        ),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final appStateProvider = Provider.of<AppStateProvider>(context, listen: false);
    appStateProvider.handleAppLifecycleChange(state.name);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Rummy Game',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.amber),
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      initialRoute: '/login',
      routes: {
        '/login': (context) => const LoginPage(),
        '/register': (context) => const RegisterPage(),
        '/dashboard': (context) => const DashboardPage(),
      },
    );
  }
}